#include <iostream>
using namespace std;

template <typename T>
bool compareValues(const T &x, const T &y)
{
    return x == y;
}

int main()
{
    int a = 1, b = 1;
    cout << compareValues<int>(1, 1) << endl;

    cout << compareValues<int>(1, 2) << endl;

    cout << compareValues<char>('a', 'a') << endl;
    cout << compareValues<char>('a', 'b') << endl;
    cout << compareValues<float>(1.01, 1.01) << endl;
}