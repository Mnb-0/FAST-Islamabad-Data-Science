#include <iostream>
using namespace std;

class ResizableArray
{
	int capacity;
	int *arr;
	int count;

public:
	ResizableArray(int capacity = 1)
	{
		this->capacity = capacity;
		arr = new int[capacity];
		this->count = 0;
	}

	~ResizableArray()
	{
		delete[] arr;
	}

	void add(int val)
	{
		if (count == capacity)
		{
			resize(capacity * 2);
		}

		arr[count++] = val;
	}

	bool remove(int index)
	{
		if (index < 0 || index >= count)
		{
			return false;
		}

		for (int i = index; i < count - 1; i++)
		{
			arr[i] = arr[i + 1];
		}
		count--;

		if (count > 0 && count <= capacity / 4)
		{
			shrink();
		}

		return true;
	}

	bool update(int index, int value)
	{
		if (index < 0 || index >= count)
		{
			return false;
		}

		arr[index] = value;
		return true;
	}

	int get(int index) const
	{
		if (index < 0 || index >= count)
		{
			return -1;
		}

		return arr[index];
	}

	int find(int val) const
	{
		for (int i = 0; i < count; i++)
		{
			if (arr[i] == val)
			{
				return i;
			}
		}
		return -1;
	}

	int size() const
	{
		return count;
	}

	int capacitySize() const
	{
		return capacity;
	}

	void reverse()
	{
		int left = 0;
		int right = count - 1;

		while (left < right)
		{

			int temp = arr[left];
			arr[left] = arr[right];
			arr[right] = temp;
			left++;
			right--;
		}
	}

	void resize(int newCapacity)
	{
		int *temp = new int[newCapacity];
		for (int i = 0; i < count; i++)
		{
			temp[i] = arr[i];
		}

		delete[] arr;
		arr = temp;
		capacity = newCapacity;
	}

	void shrink()
	{
		resize(capacity / 2);
	}
};

int main()
{
	ResizableArray arr;

	arr.add(10);
	arr.add(20);
	arr.add(30);
	arr.add(40);

	cout << "Array size: " << arr.size() << ", Capacity: " << arr.capacitySize() << endl;

	arr.remove(1);

	cout << "After removal, Array size: " << arr.size() << ", Capacity: " << arr.capacitySize() << endl;

	arr.add(50);
	arr.add(60);

	cout << "After adding, Array size: " << arr.size() << ", Capacity: " << arr.capacitySize() << endl;

	return 0;
}
