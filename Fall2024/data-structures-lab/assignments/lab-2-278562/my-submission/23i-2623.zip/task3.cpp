#include <iostream>
using namespace std;

class LibraryCatalog
{
    int *bookID;
    int size;
    int count;

 
    void insert(int bookId)
    {
        int i = count - 1;
        while (i >= 0 && bookID[i] > bookId)
        {
            bookID[i + 1] = bookID[i];
            i--;
        }
        bookID[i + 1] = bookId;
        count++;
    }

public:
    LibraryCatalog(int size = 10000)
    {
        this->size = size;
        bookID = new int[size];
        count = 0;
    }

    ~LibraryCatalog()
    {
        delete[] bookID;
    }


    void addBook(int bookId)
    {
        if (count == size)
        {
            cout << "Catalog is full. Cannot add more books." << endl;
            return;
        }
        insert(bookId);
    }

    int findBook(int bookId) const
    {
        int start = 0;
        int end = count - 1;
        while (start <= end)
        {
            int mid = (start + end) / 2;
            if (bookID[mid] == bookId)
                return mid;
            else if (bookID[mid] < bookId)
                start = mid + 1;
            else
                end = mid - 1;
        }
        return -1;
    }


    void printCatalog() const
    {
        for (int i = 0; i < count; i++)
        {
            cout << bookID[i] << " ";
        }
        cout << endl;
    }
};

int main()
{
    LibraryCatalog lib(5);
    lib.addBook(4);
    lib.addBook(1);
    lib.addBook(3);
    lib.addBook(2);
    lib.printCatalog();  // Should print books in ascending order
    lib.addBook(5);
    cout << lib.findBook(2) << endl;  // Should return the index of book 2
    cout << lib.findBook(20) << endl; // Should return -1 (not found)
    lib.printCatalog();
}
