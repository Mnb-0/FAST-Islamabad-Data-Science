// Muhammad Muneeb Lone | 23i-2623 | Assignment 1
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

// Helper Functions
string convertToHexa(int dec)
{
    if (dec == 0)
        return "0";

    string hexadec = "";
    while (dec > 0)
    {
        int remainder = dec % 16;
        if (remainder < 10)
        {
            hexadec = char('0' + remainder) + hexadec;
        }
        else
        {
            hexadec = char('A' + (remainder - 10)) + hexadec;
        }
        dec = dec / 16;
    }
    return hexadec;
}

int convertToDecimal(string hexadec)
{
    int dec = 0;
    int base = 1;
    int length = hexadec.length();

    for (int i = length - 1; i >= 0; i--)
    {
        if (hexadec[i] >= '0' && hexadec[i] <= '9')
        {
            dec += (hexadec[i] - '0') * base;
        }
        else if (hexadec[i] >= 'A' && hexadec[i] <= 'F')
        {
            dec += (hexadec[i] - 'A' + 10) * base;
        }
        else if (hexadec[i] >= 'a' && hexadec[i] <= 'f')
        {
            dec += (hexadec[i] - 'a' + 10) * base;
        }
        else if (hexadec[i] = ' ')
        {
            continue;
        }
        else
        {
            cout << "Invalid hexadec character: " << hexadec[i] << endl;
            return -1;
        }

        base = base * 16;
    }
    return dec;
}

// One Node = One Entry in the Cache
class Node
{
public:
    string address;
    int data;
    int dirtyBit;
    Node *next;

    Node(string address = "", int data = -1, int dirtyBit = 0) : address(address), data(data), dirtyBit(dirtyBit), next(NULL) {}
};

// Linked List Acting As Cache
class Cache
{
public:
    Node *head;

    Cache() // Initialize empty list
    {
        head = NULL;
    }

    void insertAtHead(string address, int data, int dirtyBit = 0) // Insert at the beginning of the list
    {
        Node *newNode = new Node(address, data, dirtyBit);
        if (head == NULL)
        {
            head = newNode;
            return;
        }
        // newNode->data = data;
        // newNode->address = address;
        // newNode->dirtyBit = dirtyBit;
        newNode->next = head;
        head = newNode;
    }

    void insertAtEnd(string address, int data = -1, int dirtyBit = 0) // Insert at the end of the list
    {
        Node *newNode = new Node(address, data, dirtyBit);
        if (head == NULL)
        {
            head = newNode;
        }
        else
        {
            Node *temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    bool checkCache(string address) // Load Operation
    {
        Node *temp = head;
        while (temp != NULL)
        {
            if (temp->address == address)
            {
                if (temp->dirtyBit == 1)
                {
                    cacheToFile();      // Write back to memory if dirty
                    temp->dirtyBit = 0; // Reset the dirty bit so it doesn't get written again
                }
                return 1; // Cache Hit
            }
            temp = temp->next;
        }
        insertAtEnd(address, -1); // Default data is -1
        return 0;                 // Cache Miss
    }

    void cacheToFile() // Store the cache into permanent memory (csv)
    {
        // Overwriting the file every time instead of creating a temp file and renaming
        fstream file;

        file.open("Memory.csv", ios::out);

        if (file.is_open())
        {
            // Writing Header lines in the file to maintain original format
            file << "," << endl;
            file << "Address (dec), Data (Hex)" << endl;
            file << "," << endl;

            Node *temp = head;
            while (temp != NULL) // Write entire list to file
            {
                // Convert data to hexadecimal before writing to the file
                string dataHex = convertToHexa(temp->data);
                file << temp->address << "," << dataHex << endl;
                temp = temp->next;
            }

            file.close();
        }
        else
        {

            cout << "Unable to open the file." << endl;
        }
    }

    void fileToCache() // Import the file into the cache
    {
        ifstream file;
        file.open("Memory.csv", ios::in);

        if (file.is_open())
        {
            string line;
            // Skip the first three lines(headers)
            getline(file, line);
            getline(file, line);
            getline(file, line);

            while (getline(file, line)) // Checks for non empty lines (till eof)
            {
                if (line.empty()) // Abnormal case check. File should never have empty line in the middle
                {
                    continue;
                }
                int commaPos = line.find(','); // Searching for the comma in csv line

                string address = line.substr(0, commaPos); // Using comma position to separate the data and address

                int data = convertToDecimal(line.substr(commaPos + 1));

                // Insert each new entry into the cache
                insertAtEnd(address, data);
            }

            file.close();
        }
        else
        {
            cout << "Unable to open the file." << endl;
        }
    }

    void initCache() // Cache Initializer
    {

        ifstream file;
        file.open("Memory.csv", ios::in);
        if (file.is_open())
        {
            string line;
            // Skip the first three lines
            getline(file, line);
            getline(file, line);
            getline(file, line);

            while (getline(file, line))
            {
                if (line.empty())
                {
                    continue;
                }

                int commaPos = line.find(',');

                string address = line.substr(0, commaPos);
                int data = convertToDecimal(line.substr(commaPos + 1));
                insertAtEnd(address, data);
            }

            file.close();
        }
        else
        {
            cout << "Unable to open the file." << endl;
        }
    }

    void writeThrough(string address, int data) // Store Operation 1
    {
        // Called in case of Cache Hit i.e address found
        Node *temp = head;
        while (temp != NULL)
        {
            if (temp->address == address) // Update address if found
            {
                temp->data = data; // Update cache immediately
                cacheToFile();     // Write to file immediately after
                break;
            }

            temp = temp->next;
        }
    }

    void writeBack(string address, int data) // Store Operation 2
    {

        Node *temp = head;
        while (temp != NULL)
        {
            if (temp->address == address)
            {
                temp->data = data;  // Update cache immediately
                temp->dirtyBit = 1; // Marked noded as dirty
                break;
            }

            temp = temp->next;
        }
    }

    void writeAllocate(string address, int data) // Store Operation 3
    {
        // called only in case of cache miss hence we can assume the address is not in the memory.csv so no checks needed
        // fileToCache();
        insertAtEnd(address, data);
        cacheToFile();
    }

    void writeAround(string address, int data) // Store Operation 4
    {
        fstream file;
        file.open("Memory.csv", ios::app); // Open the file in append mode because writing directly at the end of the file
                                           // Cache miss case so we know we need to append at end

        if (file.is_open())
        {
            file << address << "," << convertToHexa(data) << '\n';
            file.close();
        }
        else
        {
            cout << "Error: Unable to open the file." << endl;
            return;
        }
    }

    void printList() // Simple display function to help with checking operations
    {
        // cout << "FIX MAIN FUNCTION AND ADD COMMENTS AND REWRITE MAIN" << endl;
        Node *temp = head;

        // Print headers
        cout << left << setw(15) << "Address"
             << setw(10) << "Data"
             << setw(10) << "Dirty Bit" << endl;
        cout << "------------------------------------" << endl;

        // Print each node's data
        while (temp != NULL)
        {
            cout << left << setw(15) << temp->address // Left align, set width for address
                 << setw(10) << temp->data            // Set width for data
                 << setw(10) << temp->dirtyBit        // Set width for dirty bit
                 << endl;

            temp = temp->next;
        }
    }

    ~Cache() // Destructor
    {
        while (head != nullptr)
        {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main()
{
    int cacheHitPolicy, cacheMissPolicy;

    // User selects the cache hit and miss policies using numbers
    cout << "Select Cache Hit Policy:\n1. Write Through\n2. Write Back\nYour choice: ";
    cin >> cacheHitPolicy;

    cout << "Select Cache Miss Policy:\n1. Write Allocate\n2. Write Around\nYour choice: ";
    cin >> cacheMissPolicy;

    // Creating cache object and initializing with current file contents
    Cache cache;
    cache.initCache();

    // Continuous loop for testing
    string operation;
    string address;
    string dataHex;
    int addressDecimal, dataDecimal;

    while (true)
    {
        // Choose operation
        cout << "\nEnter operation (load/store/exit): ";
        cin >> operation;

        if (operation == "exit")
        {
            cout << "Exiting cache simulation.\n";
            break;
        }

        if (operation != "load" && operation != "store")
        {
            cout << "Invalid operation! Please enter 'load', 'store', or 'exit'.\n";
            continue;
        }

        // Get address from the user
        cout << "Enter address (decimal): ";
        cin >> addressDecimal;
        address = to_string(addressDecimal); // Convert address to string

        if (operation == "store")
        {
            cout << "Enter data (hexadecimal): ";
            cin >> dataHex;
            dataDecimal = convertToDecimal(dataHex); // Convert hex to decimal
        }

        // Perform the selected operation
        if (operation == "load")
        {
            cout << "Performing load operation...\n";
            bool cacheHit = cache.checkCache(address);

            if (cacheHit)
            {
                cout << "Cache Hit! Address " << address << " is present in the cache.\n";
            }
            else
            {
                cout << "Cache Miss! Address " << address << " not found. Appending to cache...\n";
            }
        }
        else if (operation == "store")
        {
            cout << "Performing store operation...\n";
            bool cacheHit = cache.checkCache(address);

            if (cacheHit)
            {
                cout << "Cache Hit! Address " << address << " is present in the cache.\n";

                if (cacheHitPolicy == 1) // Write Through
                {
                    cache.writeThrough(address, dataDecimal);
                    cout << "Write Through: Updated cache and memory with data " << dataHex << ".\n";
                }
                else if (cacheHitPolicy == 2) // Write Back
                {
                    cache.writeBack(address, dataDecimal);
                    cout << "Write Back: Updated cache and set dirty bit for address " << address << ".\n";
                }
                else
                {
                    cout << "Invalid cache hit policy!\n";
                }
            }
            else
            {
                cout << "Cache Miss! Address " << address << " not found.\n";

                if (cacheMissPolicy == 1) // Write Allocate
                {
                    cache.writeAllocate(address, dataDecimal);
                    cout << "Write Allocate: Loaded data from memory to cache and updated cache with data " << dataHex << ".\n";
                }
                else if (cacheMissPolicy == 2) // Write Around
                {
                    cache.writeAround(address, dataDecimal);
                    cout << "Write Around: Updated memory directly with data " << dataHex << ".\n";
                }
                else
                {
                    cout << "Invalid cache miss policy!\n";
                }
            }
        }

        // Show current cache status for debugging purposes
        cache.printList();
    }

    return 0;
}