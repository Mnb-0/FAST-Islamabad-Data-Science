// Muhammad Muneeb Lone | 23i-2623 | Assignment 1
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
using namespace std;

void openHtmlFile(const string &filePath)
{
#ifdef _WIN32
    string command = "start " + filePath;
#elif __linux__
    string command = "xdg-open " + filePath;
#elif __APPLE__
    string command = "open " + filePath;
#else
    cerr << "Unsupported operating system" << endl;
    return;
#endif
    system(command.c_str());
}

class Node
{
public:
    string url;
    unsigned int visitCount;
    Node *next;
    Node *back;

    Node(const string &u = "") : url(u), visitCount(0), next(nullptr), back(nullptr) {}

    void incrementVisitCount()
    {
        visitCount++;
    }
};

class BrowserHistory
{
public:
    Node *head;
    Node *current;

    BrowserHistory() : head(nullptr), current(nullptr) {}

    void insertAtHead(const string &url)
    {
        Node *newNode = new Node(url);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            newNode->next = head;
            head->back = newNode;
            head = newNode;
        }
        current = newNode;
    }

    void insertAtEnd(const string &url)
    {
        Node *newNode = new Node(url);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            Node *temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->back = temp;
        }
        current = newNode;
    }

    void visit(const string &url)
    {
        Node *newNode = new Node(url);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            newNode->next = head;
            head->back = newNode;
            head = newNode;
        }
        current = newNode;
        deleteFrwrdHistory();
        createHTML(url);
        openHtmlFile(url);
    }

    void deleteFrwrdHistory()
    {
        // list is empty
        if (head == nullptr)
        {
            return;
        }

        Node *temp = current->next;
        while (temp != nullptr)
        {
            Node *nextNode = temp->next;
            delete temp;
            temp = nextNode;
        }
        current->next = nullptr;
    }

    void fileToList()
    {
        fstream file;
        file.open("fb.html", ios::in);
        if (!file)
        {
            cout << "Error opening file\n";
            return;
        }

        string line;
        bool inTitle = false; // check if we are inside <title>

        while (getline(file, line))
        {
            if (line.find("<title>") != string::npos)
            {
                inTitle = true; // title found
                continue;
            }

            // check for closing </title>
            if (line.find("</title>") != string::npos)
            {
                inTitle = false; // reset flag
                continue;
            }

            // inside title is url
            if (inTitle && !line.empty())
            {
                insertAtEnd(line);
            }
        }

        file.close();
    }

    void listToFile()
    {
        fstream file("fb.html", ios::out | ios::trunc); // Use ios::trunc to clear file content
        if (!file.is_open())
        {
            cout << "Error opening file fb.html for writing" << endl;
            return;
        }

        file << "<html>\n";
        file << "    <title>\n";

        Node *temp = head;
        while (temp != nullptr)
        {
            file << "        " << temp->url << endl;
            temp = temp->next;
        }

        file << "    </title>\n";
        file << "</html>\n";
        file.close();
    }

    string urlCheck(const string &url)
    {
        string temp = "";
        // Remove spaces to make the url valid
        for (int i = 0; i < url.length(); i++)
        {
            if (url[i] == ' ')
            {
                continue;
            }
            else
            {
                temp += url[i];
            }
        }
        return temp;
    }

    void printList()
    {
        if (head == nullptr)
        {
            cout << "List is empty\n";
            return;
        }
        Node *temp = head;
        while (temp != nullptr)
        {
            cout << "URL: " << temp->url << ", Visit Count: " << temp->visitCount << endl;
            temp = temp->next;
        }
    }

    string moveBackward(unsigned int steps)
    {
        int i = 0;
        while (i < steps && current != nullptr)
        {
            current = current->back;
            i++;
        }
        if (current != nullptr)
        {
            createHTML(current->url);
            openHtmlFile(current->url);
            return current->url;
        }
        cout << "Cannot move further back.\n";
        return "";
    }

    string moveForward(unsigned int steps)
    {
        int i = 0;
        while (i < steps && current != nullptr)
        {
            current = current->next;
            i++;
        }
        if (current != nullptr)
        {
            createHTML(current->url);
            openHtmlFile(current->url);
            return current->url;
        }
        cout << "Cannot move further forward.\n";
        return "";
    }

    void openFrequent(unsigned int k)
    {
        if (head == nullptr)
        {
            cout << "History is empty.\n";
            return;
        }

        Node *temp = head;
        int size = 0;
        while (temp != nullptr)
        {
            size++;
            temp = temp->next;
        }

        Node **arr = new Node *[size];
        temp = head;
        int i = 0;
        while (temp != nullptr)
        {
            arr[i++] = temp;
            temp = temp->next;
        }

        bubbleSort(arr, size); // Sort all nodes

        for (int z = 0; z < min(k, (unsigned int)size); z++)
        {
            createHTML(arr[z]->url);
            openHtmlFile(arr[z]->url);
        }

        delete[] arr;
    }

    void bubbleSort(Node **arr, int k)
    {
        bool swapped;

        for (int j = 0; j < k - 1; j++)
        {
            swapped = false;

            for (int a = 0; a < k - 1 - j; a++)
            {
                if (arr[a]->visitCount < arr[a + 1]->visitCount)
                {
                    Node *temp = arr[a];
                    arr[a] = arr[a + 1];
                    arr[a + 1] = temp;

                    swapped = true;
                }
            }

            if (!swapped)
            {
                break;
            }
        }
    }

    void createHTML(const string &fileName)
    {
        ofstream file(fileName);
        if (!file.is_open())
        {
            cout << "Error creating file: " << fileName << endl;
            return;
        }

        file.close();
        cout << "HTML file created successfully: " << fileName << endl;
    }
};

int main()
{

    BrowserHistory browserHistory;

    // initialize browser history
    browserHistory.fileToList();

    // Visit some URLs
    browserHistory.insertAtEnd("example1");
    browserHistory.insertAtEnd("example2");
    browserHistory.insertAtEnd("example3");
    browserHistory.listToFile();

    // Move backward and forward in history
    cout << "Current URL after moving back: " << browserHistory.moveBackward(1) << endl;
    cout << "Current URL after moving forward: " << browserHistory.moveForward(1) << endl;

    // freq test
    browserHistory.visit("example1");
    browserHistory.visit("example2");
    browserHistory.visit("example2");
    browserHistory.visit("example3");

    // Open top 2 urls
    cout << "Opening top 2 most frequently visited URLs:\n";
    browserHistory.openFrequent(2);

    return 0;
}