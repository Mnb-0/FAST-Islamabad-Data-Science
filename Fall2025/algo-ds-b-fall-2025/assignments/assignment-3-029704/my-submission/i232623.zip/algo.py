import sys
import heapq
import time
import copy
import json
import random
import tracemalloc
from math import inf

INF = float('inf')

class GraphSolver:

    def __init__(self, vertices, edges, is_directed=True):
        self.V = vertices
        self.E = len(edges)
        self.is_directed = is_directed

        self.adj_list = {i: [] for i in range(1, vertices + 1)}
        self.edge_list = []
        self.adj_matrix = [[INF] * (vertices + 1) for _ in range(vertices + 1)]
        
        for i in range(1, vertices + 1):
            self.adj_matrix[i][i] = 0.0

        self._build_graph(edges)

    def _build_graph(self, edges):
        for u, v, w in edges:
            if 1 <= u <= self.V and 1 <= v <= self.V:
                self.adj_list[u].append((v, w))
                self.edge_list.append((u, v, w))
                self.adj_matrix[u][v] = w
                
                if not self.is_directed:
                    self.adj_list[v].append((u, w))
                    self.edge_list.append((v, u, w))
                    self.adj_matrix[v][u] = w

    def dijkstra(self, start_node):
        # Reject negative weights early
        for u in self.adj_list:
            for v, w in self.adj_list[u]:
                if w < 0:
                    raise ValueError("Dijkstra cannot run on graphs with negative edge weights.")

        tracemalloc.start()
        t0 = time.perf_counter()
        relaxations = 0

        distances = {i: INF for i in range(1, self.V + 1)}
        distances[start_node] = 0.0
        pq = [(0.0, start_node)]

        while pq:
            current_dist, u = heapq.heappop(pq)
            
            if current_dist > distances[u]:
                continue
                
            for v, weight in self.adj_list[u]:
                if distances[u] + weight < distances[v]:
                    distances[v] = distances[u] + weight
                    heapq.heappush(pq, (distances[v], v))
                    relaxations += 1

        time_ms = (time.perf_counter() - t0) * 1000.0
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        metrics = {"time_ms": round(time_ms, 6), "relaxations": relaxations, "peak_mem_kb": round(peak/1024, 3)}
        return distances, metrics

    def bellman_ford(self, start_node):
        tracemalloc.start()
        t0 = time.perf_counter()
        relaxations = 0

        distances = {i: INF for i in range(1, self.V + 1)}
        distances[start_node] = 0.0

        for _ in range(self.V - 1):
            updated = False
            for u, v, w in self.edge_list:
                if distances[u] != INF and distances[u] + w < distances[v]:
                    distances[v] = distances[u] + w
                    updated = True
                    relaxations += 1
            if not updated:
                break

        negative_cycle = False
        for u, v, w in self.edge_list:
            if distances[u] != INF and distances[u] + w < distances[v]:
                negative_cycle = True
                break

        time_ms = (time.perf_counter() - t0) * 1000.0
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        metrics = {"time_ms": round(time_ms, 6), "relaxations": relaxations, "peak_mem_kb": round(peak/1024, 3)}
        
        if negative_cycle:
            return None, {**metrics, "negative_cycle": True}
            
        return distances, metrics

    def floyd_warshall(self):
        tracemalloc.start()
        t0 = time.perf_counter()
        updates = 0

        dist = copy.deepcopy(self.adj_matrix)

        for k in range(1, self.V + 1):
            for i in range(1, self.V + 1):
                if dist[i][k] == INF:
                    continue
                for j in range(1, self.V + 1):
                    if dist[k][j] == INF:
                        continue
                    newd = dist[i][k] + dist[k][j]
                    if newd < dist[i][j]:
                        dist[i][j] = newd
                        updates += 1

        negative_cycle = any(dist[i][i] < 0 for i in range(1, self.V + 1))

        time_ms = (time.perf_counter() - t0) * 1000.0
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        metrics = {"time_ms": round(time_ms, 6), "relaxations": updates, "peak_mem_kb": round(peak/1024, 3)}
        
        if negative_cycle:
            return None, {**metrics, "negative_cycle": True}
            
        return dist, metrics

    def johnson(self):
        temp_edges = self.edge_list[:]
        for i in range(1, self.V + 1):
            temp_edges.append((0, i, 0))

        tracemalloc.start()
        t0 = time.perf_counter()
        relaxations_bf = 0

        # Bellman-Ford phase
        h = {i: INF for i in range(0, self.V + 1)}
        h[0] = 0.0
        
        for _ in range(self.V):
            updated = False
            for u, v, w in temp_edges:
                if h[u] != INF and h[u] + w < h[v]:
                    h[v] = h[u] + w
                    updated = True
                    relaxations_bf += 1
            if not updated:
                break

        for u, v, w in temp_edges:
            if h[u] != INF and h[u] + w < h[v]:
                time_ms = (time.perf_counter() - t0) * 1000.0
                _, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                return None, {"time_ms": round(time_ms, 6), "relaxations": relaxations_bf, "peak_mem_kb": round(peak/1024, 3), "negative_cycle": True}

        # Reweight phase
        original_adj = self.adj_list
        reweighted_adj = {i: [] for i in range(1, self.V + 1)}
        
        for u in original_adj:
            for v, w in original_adj[u]:
                if h[u] == INF or h[v] == INF:
                    new_w = INF
                else:
                    new_w = w + h[u] - h[v]
                reweighted_adj[u].append((v, new_w))

        # Dijkstra phase
        self.adj_list = reweighted_adj
        total_relaxations_dij = 0
        result_matrix = [[INF] * (self.V + 1) for _ in range(self.V + 1)]
        
        for u in range(1, self.V + 1):
            result_matrix[u][u] = 0.0
            try:
                d_res, d_metrics = self.dijkstra(u)
            except Exception:
                d_res, d_metrics = ({i: INF for i in range(1, self.V + 1)}, {"time_ms": 0, "relaxations": 0})
            
            total_relaxations_dij += d_metrics.get("relaxations", 0)
            
            for v, dist in d_res.items():
                if dist != INF and h[u] != INF and h[v] != INF:
                    real_dist = dist - h[u] + h[v]
                    result_matrix[u][v] = real_dist
                elif dist != INF:
                    result_matrix[u][v] = INF

        self.adj_list = original_adj

        time_ms = (time.perf_counter() - t0) * 1000.0
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        metrics = {
            "time_ms": round(time_ms, 6),
            "relaxations": relaxations_bf + total_relaxations_dij,
            "peak_mem_kb": round(peak/1024, 3)
        }
        return result_matrix, metrics

# ---------- Utilities ----------

def make_random_graph(n, p=0.1, weight_range=(1, 10), allow_negative=False, seed=None, directed=True):
    rng = random.Random(seed)
    edges = []
    for u in range(1, n+1):
        for v in range(1, n+1):
            if u == v: continue
            if rng.random() <= p:
                w = rng.uniform(*weight_range)
                if allow_negative and rng.random() < 0.2:
                    w = -abs(w)
                edges.append((u, v, round(w, 3)))
    return edges

def warmup():
    """Runs a dummy graph to warm up the Python interpreter and JIT."""
    edges = [(1, 2, 1), (2, 3, 1), (3, 1, 1)]
    s = GraphSolver(3, edges)
    s.dijkstra(1)
    s.bellman_ford(1)
    s.floyd_warshall()
    s.johnson()

# ---------- Runner ----------

def run_experiment(name, V, edges, source=1):
    print(f"\n{'='*20} Test Case: {name} {'='*20}")
    print(f"Vertices: {V}, Edges: {len(edges)}")
    solver = GraphSolver(V, edges, is_directed=True)
    summary = {"name": name, "V": V, "E": len(edges), "algorithms": {}}

    # Dijkstra
    try:
        d_res, d_metrics = solver.dijkstra(source)
        print_solution(d_res, f"Dijkstra (Source={source})")
        print(f"Time: {d_metrics['time_ms']:.6f} ms  Relaxations: {d_metrics['relaxations']}")
        summary["algorithms"]["Dijkstra"] = d_metrics
    except Exception as e:
        print(f"\n--- Dijkstra Failed: {e} ---")
        summary["algorithms"]["Dijkstra"] = {"time_ms": None, "error": str(e)}

    # Bellman-Ford
    bf_res, bf_metrics = solver.bellman_ford(source)
    if bf_res is None:
        print("Bellman-Ford: Negative weight cycle detected.")
        summary["algorithms"]["Bellman-Ford"] = bf_metrics
    else:
        print_solution(bf_res, f"Bellman-Ford (Source={source})")
        print(f"Time: {bf_metrics['time_ms']:.6f} ms  Relaxations: {bf_metrics['relaxations']}")
        summary["algorithms"]["Bellman-Ford"] = bf_metrics

    # Floyd-Warshall
    fw_res, fw_metrics = solver.floyd_warshall()
    if fw_res is None:
        print("Floyd-Warshall: Negative weight cycle detected.")
        summary["algorithms"]["Floyd-Warshall"] = fw_metrics
    else:
        print_solution(fw_res, "Floyd-Warshall", is_matrix=True, vertices=V)
        print(f"Time: {fw_metrics['time_ms']:.6f} ms")
        summary["algorithms"]["Floyd-Warshall"] = fw_metrics

    # Johnson
    j_res, j_metrics = solver.johnson()
    if j_res is None:
        print("Johnson: Negative weight cycle detected.")
        summary["algorithms"]["Johnson"] = j_metrics
    else:
        print_solution(j_res, "Johnson's Algorithm", is_matrix=True, vertices=V)
        print(f"Time: {j_metrics['time_ms']:.6f} ms")
        summary["algorithms"]["Johnson"] = j_metrics

    return summary

def print_solution(dist_map, algorithm_name, is_matrix=False, vertices=0):
    print(f"\n--- {algorithm_name} Results ---")
    if dist_map is None:
        print("No solution found.")
        return
    if is_matrix:
        print("Matrix output suppressed for brevity in logs (parsed by JSON).")
    else:
        print("Vertex output suppressed for brevity.")

def main():
    # Warmup to prevent "Cold Start" timing anomalies
    warmup()
    
    testcases = []
    # 1: PDF Example
    testcases.append(("PDF Example", 5, [(1,2,2),(1,3,4),(2,3,1),(2,4,7),(3,5,3),(4,5,1),(5,4,2)], 1))
    
    # 2: Negative Weights
    testcases.append(("Negative Weights (Valid)", 4, [(1,2,4),(1,3,3),(2,4,-2)], 1))
    
    # 3: Negative Cycle
    testcases.append(("Negative Cycle Detection", 3, [(1,2,1),(2,3,-5),(3,1,2)], 1))
    
    # 4: Sparse (10-50 nodes) per assignment
    sparse = make_random_graph(50, p=0.1, weight_range=(1,10), seed=42)
    testcases.append(("Sparse Graph (V=50)", 50, sparse, 1))
    
    # 5: Dense (100 nodes) per assignment
    dense = make_random_graph(100, p=0.5, weight_range=(1,10), seed=99)
    testcases.append(("Dense Graph (V=100)", 100, dense, 1))
    
    # 6: Mixed (Negatives)
    mixed = make_random_graph(20, p=0.2, weight_range=(1,10), allow_negative=True, seed=123)
    testcases.append(("Mixed Graph (Negatives)", 20, mixed, 1))

    summary_results = []
    for name, V, edges, src in testcases:
        summary_results.append(run_experiment(name, V, edges, source=src))

    print("\n===JSON-RESULTS-START===")
    print(json.dumps({"tests": summary_results}, indent=2))
    print("===JSON-RESULTS-END===")

if __name__ == "__main__":
    main()