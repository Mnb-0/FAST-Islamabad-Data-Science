import os
import re
import sys
import subprocess
import json
from fpdf import FPDF
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

def run_algo_script(script_path="algo.py", timeout=300):
    if not os.path.exists(script_path):
        raise FileNotFoundError(f"{script_path} not found.")
    cmd = [sys.executable, script_path]
    completed = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    return completed.stdout.decode(errors="replace")

def extract_json_summary(output_text):
    m = re.search(r"===JSON-RESULTS-START===\s*(\{.*?\})\s*===JSON-RESULTS-END===", output_text, re.S)
    if m:
        return json.loads(m.group(1))
    return None

def generate_charts(parsed, filename="perf_chart.png"):
    tests = parsed["tests"]
    # Filter out the tiny examples for the chart, focus on Sparse/Dense/Mixed
    relevant_tests = [t for t in tests if "Graph" in t["name"] and "PDF" not in t["name"]]
    
    if not relevant_tests: 
        relevant_tests = tests

    test_names = [t["name"] for t in relevant_tests]
    algs = ["Dijkstra", "Bellman-Ford", "Floyd-Warshall", "Johnson"]
    
    data = {alg: [] for alg in algs}
    
    for t in relevant_tests:
        t_algs = t.get("algorithms", {})
        for alg in algs:
            metrics = t_algs.get(alg, {})
            val = metrics.get("time_ms")
            if val is None: val = 0
            data[alg].append(val)

    x = np.arange(len(test_names))
    width = 0.2
    
    plt.figure(figsize=(10, 6))
    for i, alg in enumerate(algs):
        plt.bar(x + i*width, data[alg], width, label=alg)

    plt.ylabel('Time (ms)')
    plt.title('Algorithm Performance Comparison')
    plt.xticks(x + width*1.5, test_names, rotation=15, ha='right')
    plt.legend()
    plt.grid(axis='y', linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(filename, dpi=300)
    plt.close()
    return filename

class AssignmentReport(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 14)
        self.cell(0, 10, 'Assignment 3: Shortest Path Analysis', 0, 1, 'C')
        self.ln(5)

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.set_fill_color(200, 220, 255)
        self.cell(0, 10, title, 0, 1, 'L', True)
        self.ln(4)

    def chapter_body(self, text):
        self.set_font('Times', '', 11)
        self.multi_cell(0, 6, text)
        self.ln()

    def add_bullet(self, text):
        self.set_font('Times', '', 11)
        self.cell(5)
        self.cell(5, 6, chr(149), 0, 0)
        self.multi_cell(0, 6, text)

    def create_assignment_table(self, parsed):
        # Algorithm | Graph Type | Time | Works w/ Neg | Complexity
        # We pick specific test cases to populate "Time"
        tests = parsed["tests"]
        
        # Helper to find time for a specific graph type
        def get_time(alg, partial_name):
            for t in tests:
                if partial_name in t["name"]:
                    metrics = t["algorithms"].get(alg, {})
                    val = metrics.get("time_ms")
                    return f"{val:.4f}" if val else "N/A"
            return "-"

        w = [35, 35, 25, 45, 50]
        self.set_font('Arial', 'B', 9)
        self.set_fill_color(240, 240, 240)
        headers = ["Algorithm", "Graph Type", "Time (ms)", "Works w/ Neg Weights", "Complexity"]
        for i, h in enumerate(headers):
            self.cell(w[i], 10, h, 1, 0, 'C', True)
        self.ln()

        # Data map matching the Assignment PDF Requirement
        data = [
            ["Dijkstra", "Sparse (V=50)", get_time("Dijkstra", "Sparse"), "No", "O(E + V log V)"],
            ["Bellman-Ford", "Mixed (Neg)", get_time("Bellman-Ford", "Mixed"), "Yes", "O(VE)"],
            ["Floyd-Warshall", "Dense (V=100)", get_time("Floyd-Warshall", "Dense"), "Yes", "O(V^3)"],
            ["Johnson", "Sparse (V=50)", get_time("Johnson", "Sparse"), "Yes", "O(V^2 log V + VE)"]
        ]

        self.set_font('Times', '', 9)
        for row in data:
            self.cell(w[0], 8, row[0], 1)
            self.cell(w[1], 8, row[1], 1)
            self.cell(w[2], 8, row[2], 1)
            self.cell(w[3], 8, row[3], 1)
            self.cell(w[4], 8, row[4], 1)
            self.ln()
        self.ln(5)

    def create_qna_section(self):
        self.chapter_title("7. Questions for Report")
        
        qna = [
            ("1. What are the key differences between single-source and all-pairs shortest path algorithms?",
             "Single-Source (SSSP) calculates paths from one specific node to all others (e.g., Dijkstra). All-Pairs (APSP) calculates paths between every possible pair of nodes (e.g., Floyd-Warshall). APSP is computationally more expensive (O(V^3)) compared to SSSP."),
            
            ("2. Why does Dijkstra's algorithm fail with negative edge weights?",
             "Dijkstra relies on a greedy invariant: once a node is 'visited', its distance is finalized. Negative edges violate this because a later path could reduce the cost to an already finalized node. In the case of negative cycles, it causes infinite loops."),
            
            ("3. How does Johnson's algorithm combine Bellman-Ford and Dijkstra to improve efficiency?",
             "Johnson's uses Bellman-Ford once to compute a potential function h(v) to reweight edges to be non-negative. It then runs the faster Dijkstra algorithm V times. This is faster than running Bellman-Ford V times on sparse graphs."),
            
            ("4. Provide a complexity analysis of all algorithms.",
             "Dijkstra: O(E + V log V)\nBellman-Ford: O(VE)\nFloyd-Warshall: O(V^3)\nJohnson: O(V^2 log V + VE)"),
            
            ("5. Based on experimental data, which algorithm is most suitable for each graph type?",
             "Sparse Graphs: Johnson's (APSP) or Dijkstra (SSSP).\nDense Graphs: Floyd-Warshall (APSP).\nNegative Weights: Bellman-Ford (SSSP).\nNegative Cycles: Bellman-Ford (Detection).")
        ]

        for q, a in qna:
            self.set_font('Arial', 'B', 10)
            self.multi_cell(0, 6, q)
            self.set_font('Times', '', 10)
            self.multi_cell(0, 6, a)
            self.ln(3)

def main():
    out = run_algo_script()
    parsed = extract_json_summary(out)
    
    if not parsed:
        print("Failed to parse JSON output.")
        return

    chart_file = generate_charts(parsed)

    pdf = AssignmentReport()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # 1. Objective
    pdf.chapter_title("1. Objective & Scope")
    pdf.chapter_body("This report compares Dijkstra, Bellman-Ford, Floyd-Warshall, and Johnson's algorithms on sparse, dense, and mixed graphs.")

    # 2. Summary Table (The one requested in the PDF)
    pdf.chapter_title("2. Comparative Analysis Table")
    pdf.create_assignment_table(parsed)

    # 3. Experimental Analysis
    pdf.chapter_title("3. Experimental Analysis")
    if chart_file and os.path.exists(chart_file):
        pdf.image(chart_file, x=15, w=180)
        pdf.ln(5)
    pdf.chapter_body("Observations:\n1. Dijkstra is fastest on non-negative sparse graphs.\n2. Floyd-Warshall degrades significantly on dense graphs (V=100).\n3. Johnson's algorithm effectively bridges the gap for sparse APSP.")

    # 4. Q&A
    pdf.create_qna_section()

    pdf.chapter_title("Appendix: Test Case Results")
    pdf.set_font('Courier', '', 8)
    for t in parsed["tests"]:
        pdf.cell(0, 5, f"Test: {t['name']} (V={t['V']}, E={t['E']})", 0, 1)
        for alg, m in t["algorithms"].items():
            t_ms = f"{m.get('time_ms', 'N/A')}"
            if m.get("time_ms"): t_ms = f"{m['time_ms']:.4f}"
            pdf.cell(0, 4, f"  - {alg}: Time={t_ms} ms", 0, 1)
        pdf.ln(2)

    pdf.output("Assignment3_Final_Report.pdf")
    print("Report generated: Assignment3_Final_Report.pdf")

if __name__ == "__main__":
    main()