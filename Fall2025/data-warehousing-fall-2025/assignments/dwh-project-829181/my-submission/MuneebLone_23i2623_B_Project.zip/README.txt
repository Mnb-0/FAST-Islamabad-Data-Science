Walmart Near-Real-Time Data Warehouse Prototype
This project simulates a near-real-time data warehouse. It pulls in a fast-arriving stream of sales transactions, joins them with large on-disk master files, and loads the final cleaned dataset into MySQL. The highlight is a custom HYBRIDJOIN algorithm designed to handle this kind of stream-to-disk join efficiently (please check the report for the reference paper).
A full GUI has been added so you no longer have to run the project entirely through the terminal. The GUI wraps all steps, manages credentials, and executes the full pipeline with one click. Manual execution is still supported.
Project Assumptions
Price Ambiguity: The product master file includes store-level pricing. The streamed transactions do not indicate store ID.


Resolution Method: The system resolves this using a last-one-wins approach during indexing. Not financially perfect, but keeps ETL consistent for academic use.


Credentials: The GUI and Python scripts ask for MySQL credentials. Press Enter to default to root/meow. You can either set your MySQL password to meow or type your real password into the GUI.


Requirements
MySQL Server (8.0 or newer) – used as the main database. Workbench recommended for convenience.
 Download: https://dev.mysql.com/downloads/mysql/


Python 3.10 or newer – required for the project and type hints in scripts. Ensure Add Python to PATH is checked.
 Download: https://www.python.org/downloads/


Project Files (11 total) – place all files in one folder, e.g., C:\Near_Real_Time_Data_Warehouse

 Files required:


customer_master_data.csv


product_master_data.csv


transactional_data.csv


Create-DW.sql


populate_dimensions.py


build_index.py


hybrid_join.py


doubly_linked_list.py


Run-Queries.sql


sql_queries.py


gui_runner.py


Step-by-Step Setup
Step 1: Set (or confirm) MySQL Password
 Change your root password to meow for zero typing:
 ALTER USER 'root'@'localhost' IDENTIFIED BY 'meow';
 Or enter your real password in the GUI later.
Step 2: Create the Database Schema (DDL)
 GUI automatically executes Create-DW.sql.
 Manual: Open Create-DW.sql in Workbench, copy and execute it. Refresh schema list. Schema walmart should appear.
Step 3: Install Required Python Package
 python -m pip install mysql-connector-python
Step 4: Run the ETL Pipeline
Option A: GUI Runner (Recommended)
Open terminal and navigate to project folder: cd C:\Near_Real_Time_Data_Warehouse


Run: python gui_runner.py


GUI tabs: ETL Pipeline Runner, Database Setup (DDL), Data Analysis Queries


Enter MySQL credentials; click RUN FULL PROJECT PIPELINE


The pipeline runs Create-DW.sql, populate_dimensions.py, build_index.py, hybrid_join.py in order.


When it says "PIPELINE COMPLETED SUCCESSFULLY!" you’re done.


Option B: Manual Terminal Execution
 cd C:\Near_Real_Time_Data_Warehouse
 python populate_dimensions.py
 python build_index.py
 python hybrid_join.py
 Final step may take several minutes.
Step 5: Run Analytical Queries
GUI:
Go to Data Analysis Queries tab


Run Q_VIEW: CREATE v_SalesAnalysis


Select other queries from dropdown and click Run Query


Manual:
Open Run-Queries.sql in Workbench


Execute CREATE OR REPLACE VIEW v_SalesAnalysis block first


Run other analytical queries


Troubleshooting
python not recognized: Reinstall Python and enable Add to PATH


ModuleNotFoundError: mysql.connector – install dependency: python -m pip install mysql-connector-python


Access denied for user 'root'@'localhost': Your password isn’t meow; either run Step 1 or enter actual password in GUI


Database 'walmart' does not exist: Run Create-DW.sql or use GUI


Failed to populate DimDate: Need MySQL 8.0 or newer


File not found (.csv): Ensure all CSVs and Python files are in the same directory


Stopped hybrid_join.py mid-run: Safe to restart; inserts use INSERT IGNORE to avoid duplicates


