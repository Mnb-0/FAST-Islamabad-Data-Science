set foreign_key_checks = 0;
create database Q1;
use Q1;
drop database Q1;

-- Q1
CREATE TABLE DimPatient (
    pid INT AUTO_INCREMENT PRIMARY KEY,
    pName VARCHAR(64),
    age INT,
    gender CHAR,
    ageGroup VARCHAR(64),
    risk VARCHAR(64),
    blood VARCHAR(4),
    city VARCHAR(128),
    region VARCHAR(128),
    country VARCHAR(128)
);

insert into DimPatient(pName,age,gender,ageGroup,risk,blood,city,region,country)
values ( "Taha", 21, "M", "Adult", "Low", "A+", "Isb", "Fed","PK"),
("Kabeer", 21, "M", "Adult", "Medium", "A-", "Gjr", "Pjb", "PK"),
( "Muneeb", 21, "M", "Adult", "High", "A", "Rwp", "Pjb", "PK");

CREATE TABLE DimHospital (
    hid INT AUTO_INCREMENT PRIMARY KEY,
    hName VARCHAR(128),
    bedCap INT,
    typeP VARCHAR(64),
    city VARCHAR(128),
    region VARCHAR(128),
    country VARCHAR(128),
    estabYear YEAR
);


insert into DimHospital(hName,bedCap,typeP,city,country,estabYear)
values ("Shifa", 21, "Private", "Isb","PK",1990),
("RMC", 21, "Public","Gjr", "PK",2000),
("AKU", 21, "Private","Rwp", "PK",2010);

CREATE TABLE DimDoctor (
    did INT AUTO_INCREMENT PRIMARY KEY,
    dName VARCHAR(64),
    spec VARCHAR(64),
    certLevel VARCHAR(64),
    dep VARCHAR(64),
    yearsExp INT,
    hid INT REFERENCES DimHospital (hid)
);

insert into DimDoctor(dName,spec,certLevel,dep,yearsExp,hid)
values ( "Yahya",  "Brain", "Senior", "Neurology", 30,0),
("Mustafa", "Heart", "Professor", "Cardiology", 30,2);

CREATE TABLE DimTime (
    tid INT AUTO_INCREMENT PRIMARY KEY,
    dDate DATE,
    dName VARCHAR(32),
    dNum INT,
    wNum INT,
    mName VARCHAR(32),
    mNum INT,
    qName VARCHAR(32),
    qNum INT,
    yNum INT
);
help date;
insert into DimTime(dDate,dName,dNum,wNum,mName,mNum,qName,qNum,yNum)
values('2026-01-01', "Thursday", 4, 1,"Jan",1,"Q1",1,2026),
('2026-12-31', "Thursday", 4, 5,"Dec",12,"Q4",4,2026);

insert into DimTime(dDate,dName,dNum,wNum,mName,mNum,qName,qNum,yNum)
values ('2024-01-01', "Thursday", 4, 5,"Jan",12,"Q1",1,2024),
('2024-12-31', "Thursday", 4, 5,"Dec",12,"Q4",4,2024);

CREATE TABLE DimTreatment (
    rid INT AUTO_INCREMENT PRIMARY KEY,
    rName VARCHAR(64),
    pCode INT,
    sCat VARCHAR(64),
    dep VARCHAR(64),
    cLevel VARCHAR(64),
    stdDuration INT
);

insert into DimTreatment(rName,pCode,sCat,dep,cLevel,stdDuration)
values("Checkup", 0, "Consultation", "Orthopedic","Simple",60),
("Transplant", 1, "Surgery", "Cardiology","Complex",120);

CREATE TABLE TreatFact (
    fid INT AUTO_INCREMENT PRIMARY KEY,
    pid INT REFERENCES DimPatient (pid),
    did INT REFERENCES DimDoctor (did),
    hid INT REFERENCES DimHospital (hid),
    rid INT REFERENCES DimTreatment (rid),
    tid INT REFERENCES DimTime (tid),
    treatCost INT,
    actDurationMinutes INT,
    successRate INT,
    insClaimAmnt INT,
    satisfactionScore INT
);

insert into TreatFact(pid,did,hid,rid,tid,treatCost,actDurationMinutes,successRate,insClaimAmnt,satisfactionScore)
values
(1,1,1,1,1,1000,67,100,1000,5),
(2,2,2,2,2,100000,6767,60,99999,5);

-- Q2

SELECT 
    f.fid, t.tid, t.qName, SUM(f.treatcost)
FROM
    treatfact f
        JOIN
    DimTime t
WHERE
    f.tid = t.tid
GROUP BY t.qName WITH ROLLUP;

-- Part B

SELECT 
    f.fid, t.tid, t.qname, SUM(f.treatcost)
FROM
    treatfact f
        JOIN
    dimtime t
WHERE
    f.tid = t.tid
GROUP BY qname;

-- Part C 

SELECT 
    SUM(f.treatCost),
    SUM(f.actDurationMinutes),
    AVG(f.successRate),
    d.dname,
    r.rname,
    t.mName
FROM
    treatfact f,
    DimHospital h,
    DimDoctor d,
    DimTreatment r,
    DimTime t
WHERE
    f.hid = h.hid AND d.hid = h.hid
        AND f.rid = r.rid
        AND t.tid = f.tid
        AND hname = 'Shifa'
GROUP BY d.dname , r.rname , t.mName;


SELECT 
    SUM(f.treatCost),
    SUM(f.actDurationMinutes),
    AVG(f.successRate),
    p.city,
    r.scat
FROM
    treatfact f,
    DimHospital h,
    DimDoctor d,
    DimTreatment r,
    DimTime t,
    DimPatient p
WHERE
    f.hid = h.hid AND d.hid = h.hid
        AND f.rid = r.rid
        AND t.tid = f.tid
        AND f.pid = p.pid
        AND d.dep = 'Cardiology'
        AND t.qNum = 2
        AND t.yNum = 2024
        AND p.city IN ('Lhr' , 'Khi', 'Isb')
        AND r.sCat IN ('Surgery' , 'Consultation')
GROUP BY p.city , r.scat;

-- Q3
CREATE TABLE cHosp (
    hid INT AUTO_INCREMENT PRIMARY KEY,
    city VARCHAR(128),
    pCount INT
);

CREATE TABLE cTreat (
    rid INT AUTO_INCREMENT PRIMARY KEY,
    sCat VARCHAR(128)
);

CREATE TABLE cTime (
    tid INT AUTO_INCREMENT PRIMARY KEY,
    quarter VARCHAR(2)
);

CREATE TABLE cFact (
    fid INT AUTO_INCREMENT PRIMARY KEY,
    rid INT REFERENCES cTreat (rid),
    tid INT REFERENCES cTime (tid),
    hid INT REFERENCES cHosp (hid),
    treatCost INT,
    successRate INT
);

-- Base Cuboid
-- using ids for ease, doesnt really matter in this context you could change names

SELECT 
    f.fid AS fid,
    r.rid AS rid,
    t.tid AS tid,
    h.hid AS hid,
    f.treatCost,
    h.pcount
FROM
    cFact f,
    cTreat r,
    cTime t,
    cHosp h
WHERE
    f.rid = r.rid AND f.tid = t.tid
        AND f.hid = h.hid;

-- 2D Cuboids

SELECT 
    NULL AS fid,
    NULL AS rid,
    t.tid AS tid,
    NULL AS hid,
    SUM(f.treatCost)
FROM
    cFact f,
    cTime t
WHERE
    f.tid = t.tid
GROUP BY tid;

SELECT 
    NULL AS fid,
    r.rid AS rid,
    NULL AS tid,
    NULL AS hid,
    SUM(f.treatCost)
FROM
    cFact f,
    cTreat r
WHERE
    f.rid = r.rid
GROUP BY rid;

SELECT 
    NULL AS fid,
    NULL AS rid,
    NULL AS tid,
    h.hid AS hid,
    SUM(f.treatCost)
FROM
    cFact f,
    cHosp h
WHERE
    f.hid = h.hid
GROUP BY hid;



-- 1D Cuboids

SELECT 
    NULL AS fid,
    r.rid AS rid,
    t.tid AS tid,
    NULL AS hid,
    SUM(f.treatCost)
FROM
    cFact f,
    cTreat r,
    cTime t
WHERE
    f.rid = r.rid AND f.tid = t.tid
GROUP BY rid , tid;

SELECT 
    NULL AS fid,
    NULL AS rid,
    t.tid AS tid,
    h.hid AS hid,
    SUM(f.treatCost)
FROM
    cFact f,
    cTime t,
    cHosp h
WHERE
    f.tid = t.tid AND f.hid = h.hid
GROUP BY tid , hid;

SELECT 
    NULL AS fid,
    r.rid AS rid,
    NULL AS tid,
    h.hid AS hid,
    SUM(f.treatCost)
FROM
    cFact f,
    cTreat r,
    cHosp h
WHERE
    f.rid = r.rid AND f.hid = h.hid
GROUP BY rid , hid;

-- Apex Cuboid

SELECT 
    NULL AS fid,
    NULL AS rid,
    NULL AS tid,
    NULL AS hid,
    SUM(f.treatCost),
    SUM(h.pcount),
    AVG(f.successRate)
FROM
    cFact f,
    cTreat r,
    cTime t,
    cHosp h
WHERE
    f.rid = r.rid AND f.tid = t.tid
        AND f.hid = h.hid
GROUP BY fid , rid , tid , hid;


-- Q4
-- Part A 
CREATE TABLE doctor_dim_scd2 (
    did INT AUTO_INCREMENT PRIMARY KEY,
    dName VARCHAR(64),
    spec VARCHAR(64),
    certLevel VARCHAR(64),
    dep VARCHAR(64),
    yearsExp INT,
    hospital VARCHAR(128),
    effective_date DATE,
    expiry_date DATE,
    is_current BOOLEAN,
    version_number INT
);

insert into doctor_dim_scd2(dName,spec,certLevel,dep,yearsExp,hospital, effective_date,expiry_date,is_current,version_number)
values ( "Yahya",  "Brain", "Senior", "Neurology", 30,"Shifa",current_date(),null, True, 1),
("Mustafa", "Heart", "Professor", "Cardiology", 30,"AKU",current_date(),null, True, 1),
("Ahmed", "Heart", "Senior","Cardiology",40,"RMC", current_date(),null, True, 1),
("Fatima", "Kidney", "Senior", "Orthopedics", 20, "AKU", current_date(),null, True, 1),
("Hassan", "Lungs", "Senior", "General", 10, "RMC",current_date(),null, True, 1);


SELECT 
    *
FROM
    doctor_dim_scd2;

UPDATE doctor_dim_scd2 
SET 
    expiry_date = CURRENT_DATE(),
    is_current = FALSE
WHERE
    dName = 'Ahmed';

insert into doctor_dim_scd2(dName,spec,certLevel,dep,yearsExp,hospital, effective_date,expiry_date,is_current,version_number)
values ("Ahmed", "Heart", "Senior","Cardiology",40,"AKU", current_date(),null, True, 2);

UPDATE doctor_dim_scd2 
SET 
    expiry_date = CURRENT_DATE(),
    is_current = FALSE
WHERE
    dName = 'Fatima';

insert into doctor_dim_scd2(dName,spec,certLevel,dep,yearsExp,hospital, effective_date,expiry_date,is_current,version_number)
values ("Fatima", "Kidney", "Consultant", "Orthopedics", 20, "AKU", current_date(),null, True, 2);

UPDATE doctor_dim_scd2 
SET 
    expiry_date = CURRENT_DATE(),
    is_current = FALSE
WHERE
    dName = 'Hassan';

insert into doctor_dim_scd2(dName,spec,certLevel,dep,yearsExp,hospital, effective_date,expiry_date,is_current,version_number)
values ("Hassan", "Lungs", "Senior", "Cardiology", 10, "RMC",current_date(),null, True, 1);

SELECT 
    *
FROM
    doctor_dim_scd2
WHERE
    is_current = TRUE;

SELECT 
    *
FROM
    doctor_dim_scd2
WHERE
    effective_date >= '2024-06-01';

SELECT 
    *
FROM
    doctor_dim_scd2
WHERE
    dname = 'Ahmed';

SELECT 
    *
FROM
    doctor_dim_scd2
WHERE
    expiry_date != NULL
        AND effective_date >= '2024-01-01'
        AND effective_date <= '2024-12-31';

-- Q5

CREATE TABLE hospitals_spatial (
    hid INT AUTO_INCREMENT PRIMARY KEY,
    hname VARCHAR(64),
    location POINT NOT NULL,
    serviceRad INT,
    totalBeds INT,
    availableBeds INT,
    SPATIAL INDEX ( location )
);

CREATE TABLE emergency_calls (
    cid INT AUTO_INCREMENT PRIMARY KEY,
    patientLoc POINT NOT NULL,
    severity VARCHAR(64),
    callTime TIMESTAMP,
    SPATIAL INDEX ( patientLoc )
);

insert into hospitals_spatial(hname,location,serviceRad ,totalBeds ,availableBeds)
value ("Shifa", geomfromtext(POINT(1321, 123)),20,10,10),
("Aku", geomfromtext(POINT(1521, 2134)),50,15,10),
("RMC", geomfromtext(POINT(5321, 5453)),150,60,10);
-- Can you tell I have no idea how lat and long works

SELECT 
    *
FROM
    hospitals_spatial
WHERE
    ST_CONTAINS(location, (31.5204 , 74.3587));

SELECT 
    h.hname, DISTANCE(h.location, c.patientlocation)
FROM
    hospitals_spatial h,
    emergency_calls c
ORDER BY ascending
LIMIT 3;

SELECT 
    c.patientloc, h.hname
FROM
    hospitals_spatial h,
    emergency_calls c
WHERE
    ST_CONTAINS(h.location + serviceRad,
            c.patientlocation);

SELECT 
    MBRCONTAINS(location)
FROM
    hospitals_spatial
GROUP BY location;-- I didnt add a city column, too less time left

SELECT 
    MBROVERLAPS(h.location, c.patientLoc)
FROM
    hospitals_spatial h,
    emergency_calls c;

SELECT 
    MBRDISJOINT(h.location, c.patientloc)
FROM
    hospitals_spatial h,
    emergency_calls c;


-- Q6

CREATE TABLE gender (
    gid INT AUTO_INCREMENT PRIMARY KEY,
    male VARCHAR(128),
    female VARCHAR(128)
);

CREATE TABLE risk_category (
    rid INT AUTO_INCREMENT PRIMARY KEY,
    low VARCHAR(128),
    mediumm VARCHAR(128),
    high VARCHAR(128)
);

CREATE TABLE age_group (
    aid INT AUTO_INCREMENT PRIMARY KEY,
    child VARCHAR(128),
    teen VARCHAR(128),
    adult VARCHAR(128),
    senior VARCHAR(128)
);

insert into gender(male,female) -- 1 represents yes for one entry, 0 is for the following entry and so on
values ('10110', '01001'); -- cant be male and female at the same time so inversed


insert into risk_category(low,mediumm,high)
values('10001','01100','00010');

insert into age_group(child,teen,adult,senior)
values('10000','01000','00100','00100','00001');

-- idk how to apply bitmap operations on strings

select * from patients where highrisk & 1 == 1 or senior & 1 == 1;

select * from patients where female & 1 == 1 and adult & 1 == 1

select * from patients where children & 1 == 0 and lowrisk &  == 0;


-- :)




