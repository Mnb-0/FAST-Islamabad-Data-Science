document.addEventListener("DOMContentLoaded", function() {

    const part2Data = [10, 25, 8, 42, 15, 30, 19];
    const barChartData = [80, 120, 60, 150, 200, 100, 180];
    const scatterPlotData = [
        {x: 50, y: 20}, {x: 70, y: 90}, {x: 110, y: 50},
        {x: 150, y: 80}, {x: 190, y: 30}, {x: 230, y: 110},
        {x: 270, y: 40}, {x: 310, y: 130}, {x: 350, y: 65}
    ];

    runPart1_DOMManipulation();
    runPart2_DataBinding(part2Data);
    runPart3_ManualSVG();
    runParts4_5_7_BarChart(barChartData);
    runParts6_7_ScatterPlot(scatterPlotData);

});

function runPart1_DOMManipulation() {
    d3.select("h2")
      .style("color", "darkblue");

    const part1Section = d3.select("#part1-dom");

    part1Section.append("p")
        .text("This is the first paragraph, added with D3.")
        .style("color", "green");

    part1Section.append("p")
        .text("This is the second paragraph, demonstrating chaining.")
        .style("color", "purple")
        .style("font-weight", "bold");

    part1Section.append("p")
        .text("This is the third paragraph.")
        .style("color", "orange");
}

function runPart2_DataBinding(data) {
    const threshold = 20;

    d3.select("#container")
      .selectAll("p")
      .data(data)
      .enter()
      .append("p")
      .text(d => `Data value: ${d}`)
      .style("color", d => d > threshold ? "darkred" : "gray")
      .style("border-left", d => d > threshold ? "4px solid darkred" : "4px solid gray");
}

function runPart3_ManualSVG() {
    const svg = d3.select("#part3-svg")
      .append("svg")
      .attr("width", 500)
      .attr("height", 100);

    svg.append("rect")
       .attr("x", 10)
       .attr("y", 10)
       .attr("width", 100)
       .attr("height", 50)
       .attr("fill", "blue");

    svg.append("circle")
       .attr("cx", 150)
       .attr("cy", 35)
       .attr("r", 25)
       .attr("fill", "red");

    svg.append("line")
       .attr("x1", 200)
       .attr("y1", 10)
       .attr("x2", 250)
       .attr("y2", 60)
       .attr("stroke", "black")
       .attr("stroke-width", 2);
}

function runParts4_5_7_BarChart(data) {
    const margin = { top: 20, right: 20, bottom: 20, left: 40 };
    const width = 500 - margin.left - margin.right;
    const height = 250 - margin.top - margin.bottom;

    const svg = d3.select("#part4-barchart")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom);

    const g = svg.append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

    const xScale = d3.scaleBand()
      .domain(d3.range(data.length))
      .range([0, width])
      .padding(0.1);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data)])
      .range([height, 0]);

    g.selectAll("rect")
      .data(data)
      .enter()
      .append("rect")
        .attr("x", (d, i) => xScale(i))
        .attr("width", xScale.bandwidth())
        .attr("fill", "steelblue")
        .attr("y", height)
        .attr("height", 0)
        .transition()
        .duration(1000)
        .delay((d, i) => i * 100)
        .attr("y", d => yScale(d))
        .attr("height", d => height - yScale(d));

    g.selectAll("text.bar-label")
      .data(data)
      .enter()
      .append("text")
        .attr("class", "bar-label")
        .text(d => d)
        .attr("x", (d, i) => xScale(i) + xScale.bandwidth() / 2)
        .attr("y", height)
        .transition()
        .duration(1000)
        .delay((d, i) => i * 100)
        .attr("y", d => yScale(d) - 5);
}

function runParts6_7_ScatterPlot(data) {
    const margin = { top: 30, right: 30, bottom: 30, left: 30 };
    const width = 500 - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    const svg = d3.select("#part6-scatterplot")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

    const xSc = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.x)])
      .range([0, width]);

    const ySc = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.y)])
      .range([height, 0]);

    const colorScale = d3.scaleSequential()
      .domain([0, d3.max(data, d => d.y)])
      .interpolator(d3.interpolateViridis);

    svg.selectAll("circle")
      .data(data)
      .enter()
      .append("circle")
        .attr("cx", d => xSc(d.x))
        .attr("cy", d => ySc(d.y))
        .attr("r", 5)
        .style("fill", d => colorScale(d.y));

    svg.selectAll("text.scatter-label")
      .data(data)
      .enter()
      .append("text")
        .attr("class", "scatter-label")
        .text(d => `(${d.x}, ${d.y})`)
        .attr("x", d => xSc(d.x) + 8)
        .attr("y", d => ySc(d.y) + 4);
}
