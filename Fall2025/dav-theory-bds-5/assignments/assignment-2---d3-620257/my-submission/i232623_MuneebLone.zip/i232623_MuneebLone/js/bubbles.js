// js/bubbles.js
import { fuelColorScale, showTooltip, hideTooltip, getDimensions } from './utils.js';
import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

let svg, simulation;
let nodes = [];
let clickCallback;
let width, height; // Store dimensions globally for the tick function

export function initBubbles(containerId, rawData, onFuelClick)
{
    const container = d3.select(containerId);
    container.selectAll("*").remove(); 
    
    // 1. Get Dimensions
    const dims = getDimensions(containerId.substring(1));
    width = dims.width;
    height = dims.height;
    clickCallback = onFuelClick;

    svg = container.append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .style("overflow", "hidden"); // Hide anything that tries to slip out

    // 2. Data Prep
    const fuelGroups = d3.rollup(rawData, v => v.length, d => d.primary_fuel);
    const rScale = d3.scaleSqrt().domain([0, d3.max(Array.from(fuelGroups.values()))]).range([15, 60]);

    nodes = Array.from(fuelGroups, ([fuel, count]) => ({
        id: fuel,
        count: count,
        r: rScale(count), // Store radius for collision logic
        x: width / 2 + (Math.random() - 0.5) * 50,
        y: height / 2 + (Math.random() - 0.5) * 50
    }));

    // 3. FORCE SIMULATION
    simulation = d3.forceSimulation(nodes)
        .force("charge", d3.forceManyBody().strength(-30)) // Repel
        .force("center", d3.forceCenter(width / 2, height / 2).strength(0.8)) // Pull to center
        .force("collide", d3.forceCollide().radius(d => d.r + 2).iterations(2));

    // 4. Render Nodes
    const circles = svg.selectAll(".fuel-node")
        .data(nodes)
        .join("circle")
        .attr("class", "fuel-node")
        .attr("r", d => d.r)
        .attr("fill", d => fuelColorScale(d.id))
        .attr("stroke", "#fff")
        .attr("stroke-width", 2)
        .attr("cursor", "grab")
        .call(d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended))
        .on("click", (e, d) => clickCallback(d.id))
        .on("mouseover", (e, d) => showTooltip(e, `<b>${d.id}</b><br>Plants: ${d.count}`))
        .on("mouseout", hideTooltip);

    // 5. The "Walls" Logic
    simulation.on("tick", () => 
    {
        circles
            .attr("cx", d => 
            {
                // Clamp X between radius and width-radius
                return d.x = Math.max(d.r, Math.min(width - d.r, d.x));
            })
            .attr("cy", d => 
            {
                // Clamp Y between radius and height-radius
                return d.y = Math.max(d.r, Math.min(height - d.r, d.y));
            });
    });
}

// --- Drag Event Handlers ---

function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
    d3.select(this).attr("cursor", "grabbing");
}

function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
}

function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
    d3.select(this).attr("cursor", "grab");
}

export function updateBubblesFilter(filteredData, selectedFuels)
{
    const availableFuels = new Set(filteredData.map(d => d.primary_fuel));

    svg.selectAll(".fuel-node")
        .transition().duration(300)
        .attr("opacity", d => {
            if (!availableFuels.has(d.id)) return 0.1;
            if (selectedFuels.size > 0 && !selectedFuels.has(d.id)) return 0.2;
            return 1;
        })
        .attr("stroke", d => selectedFuels.has(d.id) ? "#fff" : "none")
        .attr("stroke-width", d => selectedFuels.has(d.id) ? 3 : 0);
}