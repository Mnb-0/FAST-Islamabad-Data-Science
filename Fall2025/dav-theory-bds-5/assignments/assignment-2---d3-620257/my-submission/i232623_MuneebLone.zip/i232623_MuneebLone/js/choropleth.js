// js/choropleth.js
import { showTooltip, hideTooltip, getDimensions } from './utils.js';

let svg, pathGenerator, gMap, colorScale;
let currentYearDataMap = new Map();

// Minimal mapping for standard GeoJSON differences
// (e.g. Data says "United States", Map says "United States of America")
const nameMapping = {
    "United States of America": "United States",
    "United Kingdom": "United Kingdom", // Usually matches, but kept for safety
    "Russian Federation": "Russia",
    "Dem. Rep. Congo": "Congo, Dem. Rep.",
    "Congo": "Congo, Rep."
};

export async function initChoropleth(containerId)
{
    const container = d3.select(containerId);
    container.selectAll("*").remove();
    const { width, height } = getDimensions(containerId.substring(1));

    svg = container.append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .style("background", "#2d2d2d");

    const projection = d3.geoNaturalEarth1().scale(width / 6).translate([width / 2, height / 2]);
    pathGenerator = d3.geoPath().projection(projection);
    colorScale = d3.scaleSequential(d3.interpolateViridis).domain([30, 85]);

    try 
    {
        const worldData = await d3.json("https://unpkg.com/world-atlas@2.0.2/countries-110m.json");
        const countries = topojson.feature(worldData, worldData.objects.countries);

        gMap = svg.append("g");
        gMap.selectAll("path")
            .data(countries.features)
            .join("path")
            .attr("class", "country-path")
            .attr("d", pathGenerator)
            .attr("fill", "#444")
            .attr("stroke", "#222")
            .on("mouseover", handleMouseOver)
            .on("mouseout", hideTooltip);
    } 
    catch (e) 
    {
        console.error("Map failed to load.", e);
    }
}

export function updateChoropleth(year, gapminderData)
{
    if (!gMap) return;
    currentYearDataMap.clear();
    
    // Create lookup map
    gapminderData.forEach(d => {
        currentYearDataMap.set(d.country, d);
    });

    gMap.selectAll(".country-path")
        .transition().duration(200)
        .attr("fill", d => {
            const countryName = d.properties.name;
            
            // 1. Exact Match
            let data = currentYearDataMap.get(countryName);
            
            // 2. Mapped Match (if exact fails)
            if(!data && nameMapping[countryName]) {
                data = currentYearDataMap.get(nameMapping[countryName]);
            }

            return data ? colorScale(data.life_exp) : "#444";
        });
}

function handleMouseOver(e, d)
{
    const countryName = d.properties.name;
    let data = currentYearDataMap.get(countryName);
    
    if(!data && nameMapping[countryName]) {
        data = currentYearDataMap.get(nameMapping[countryName]);
    }

    showTooltip(e, data ? `<b>${countryName}</b><br>Life Exp: ${Math.round(data.life_exp)}` : countryName);
}