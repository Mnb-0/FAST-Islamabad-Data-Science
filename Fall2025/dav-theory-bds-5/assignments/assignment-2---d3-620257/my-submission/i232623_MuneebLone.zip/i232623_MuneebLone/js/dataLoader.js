// js/dataLoader.js
import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

export async function loadData()
{
    const powerPlantURL = "./data/global_power_plant_database.csv";
    const gapminderURL = "./data/gapminder_combined.json"; 

    try
    {
        const [powerData, gapminderData] = await Promise.all([
            d3.csv(powerPlantURL, parsePowerPlant),
            d3.json(gapminderURL)
        ]);

        console.log("Data Loaded.");
        console.log("- Power Plants:", powerData.length);
        console.log("- Gapminder Rows:", gapminderData.length);

        // Data is now clean (contains 'continent' and valid 'country' names), 
        // so we don't need manual injection loops here.

        const countryAggregates = aggregateByCountry(powerData);

        return {
            powerData: powerData,
            countryAggregates: countryAggregates,
            gapminderData: gapminderData
        };
    }
    catch (error)
    {
        console.error("Critical Error loading data:", error);
        alert("Failed to load data. See console.");
    }
}

function parsePowerPlant(d)
{
    return {
        // Use full name for consistency with Map/Gapminder
        country: d.country_long, 
        name: d.name,
        capacity_mw: +d.capacity_mw || 0,
        latitude: +d.latitude,
        longitude: +d.longitude,
        primary_fuel: d.primary_fuel,
        commissioning_year: d.commissioning_year ? +d.commissioning_year : null
    };
}

function aggregateByCountry(data)
{
    const rolledUp = d3.rollup(
        data,
        v => ({
            total_capacity: d3.sum(v, d => d.capacity_mw),
            count: v.length,
            lat: d3.mean(v, d => d.latitude),
            lon: d3.mean(v, d => d.longitude)
        }),
        d => d.country
    );

    return Array.from(rolledUp, ([key, value]) => ({
        country: key,
        total_capacity: value.total_capacity,
        count: value.count,
        latitude: value.lat,
        longitude: value.lon
    }));
}