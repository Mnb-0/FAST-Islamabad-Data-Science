// js/hierarchy.js
import { getDimensions, fuelColorScale } from './utils.js';
import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

let svg, g, pie, arc;
let hoverCallback;
let currentView = "continent"; // 'continent' or 'country'
let rawDataRef = [];
let radius;

export function initHierarchy(containerId, rawGapminder, onHover)
{
    hoverCallback = onHover;
    rawDataRef = rawGapminder;
    
    const container = d3.select(containerId);
    container.selectAll("*").remove();
    const { width, height } = getDimensions(containerId.substring(1));
    radius = Math.min(width, height) / 2 - 20;

    svg = container.append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .append("g")
        .attr("transform", `translate(${width / 2},${height / 2})`);

    // Setup Layouts
    pie = d3.pie().value(d => d.count).sort((a,b) => b.count - a.count);
    arc = d3.arc().innerRadius(radius * 0.5).outerRadius(radius);

    // Initial Render: Continents
    updateChart(getContinentData(), "continent");
}

function getContinentData() {
    // Unique Countries per Continent
    const unique = new Map();
    rawDataRef.forEach(d => {
        if (!unique.has(d.country)) unique.set(d.country, d.continent);
    });

    const rolled = d3.rollup(
        Array.from(unique.values()), 
        v => v.length, 
        d => d
    );
    return Array.from(rolled, ([key, value]) => ({ label: key, count: value, type: 'continent' }));
}

function getCountryData(continent) {
    // Unique Countries within specific Continent
    const countries = new Set();
    rawDataRef.forEach(d => {
        if (d.continent === continent) countries.add(d.country);
    });

    // For visualization, we just give them equal weight or generic weight since "count of countries" is 1
    return Array.from(countries).map(c => ({ label: c, count: 1, type: 'country', parent: continent }));
}

function updateChart(data, viewLevel) {
    currentView = viewLevel;
    
    // DATA JOIN
    const path = svg.selectAll("path")
        .data(pie(data), d => d.data.label);

    const t = svg.transition().duration(750);

    // ENTER
    path.join(
        enter => enter.append("path")
            .attr("fill", d => {
                if(viewLevel === 'continent') return fuelColorScale(d.data.label);
                // Randomish color for countries, but keeping hue similar to continent would be complex
                // simple ordinal scale for countries:
                return d3.schemeTableau10[d.index % 10]; 
            })
            .attr("d", arc)
            .each(function(d) { this._current = d; }) // Store initial angles
            .attr("opacity", 0)
            .call(enter => enter.transition(t).attr("opacity", 1)),
        
        update => update.transition(t)
            .attrTween("d", function(d) {
                const i = d3.interpolate(this._current, d);
                this._current = i(0);
                return t => arc(i(t));
            }),

        exit => exit.transition(t).attr("opacity", 0).remove()
    )
    .on("mouseover", (e, d) => {
        d3.select(e.target).attr("stroke", "#fff").attr("stroke-width", 2);
        // Only trigger scatter filtering if we are at continent level
        if (d.data.type === 'continent') hoverCallback(d.data.label);
    })
    .on("mouseout", (e) => {
        d3.select(e.target).attr("stroke", "none");
        hoverCallback(null);
    })
    .on("click", (e, d) => {
        if (currentView === 'continent') {
            // DRILL DOWN
            const countryData = getCountryData(d.data.label);
            updateChart(countryData, "country");
            addBackButton(d.data.label);
        }
    });

    // Add Labels (Simplified for clutter)
    svg.selectAll("text").remove(); // Clear old labels
    if (data.length < 30) { // Only show labels if not too crowded
        svg.selectAll("text")
            .data(pie(data))
            .join("text")
            .attr("transform", d => `translate(${arc.centroid(d)})`)
            .attr("text-anchor", "middle")
            .attr("font-size", "9px")
            .attr("fill", "white")
            .attr("pointer-events", "none")
            .text(d => d.data.label.substring(0, 10)); // Truncate
    }
}

function addBackButton(continentName) {
    // Add a center circle to go back
    const centerGroup = svg.append("g").attr("class", "back-button").attr("cursor", "pointer");
    
    centerGroup.append("circle")
        .attr("r", radius * 0.4)
        .attr("fill", "#444")
        .attr("opacity", 0)
        .transition().duration(500).attr("opacity", 1);
        
    centerGroup.append("text")
        .attr("text-anchor", "middle")
        .attr("dy", "0.3em")
        .attr("fill", "white")
        .text("BACK")
        .attr("font-weight", "bold");
        
    centerGroup.on("click", () => {
        // Go back to Continent View
        updateChart(getContinentData(), "continent");
        svg.selectAll(".back-button").remove();
    });
}