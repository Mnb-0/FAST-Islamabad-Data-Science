// js/main.js
import { loadData } from './dataLoader.js';
import { initMap, updateMapFilter } from './map.js';
import { initBubbles, updateBubblesFilter } from './bubbles.js';
import { initTimeline } from './timeline.js';
import { initScatter, updateScatter } from './scatter.js';
import { initChoropleth, updateChoropleth } from './choropleth.js';
import { initHierarchy } from './hierarchy.js';
import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

// GLOBAL STATE
const state = {
    powerData: [],
    filters: { yearRange: [1900, 2025], selectedFuels: new Set() },
    gapminder: [],
    gapminderByYear: null,
    currentYear: 1800,
    minYear: 1800,
    maxYear: 2020,
    isPlaying: false,
    timer: null
};

async function init()
{
    console.log("Initializing Dashboard...");
    const data = await loadData();
    if (!data) return;

    state.powerData = data.powerData;
    state.gapminder = data.gapminderData;

    // --- Task 1 Init ---
    // Initialize Map with both aggregate and raw data
    initMap("#map-container", data.countryAggregates, state.powerData);
    
    // Initialize Bubbles
    initBubbles("#bubbles-container", state.powerData, handleFuelClick);
    
    // Initialize Timeline
    initTimeline("#timeline-container", state.powerData, handleTimeBrush);

    // --- Task 2 Init ---
    state.gapminderByYear = d3.group(state.gapminder, d => d.year);
    state.minYear = d3.min(state.gapminder, d => d.year);
    state.maxYear = d3.max(state.gapminder, d => d.year);
    state.currentYear = state.minYear;

    initScatter("#scatter-container", state.gapminder);
    await initChoropleth("#choropleth-container");
    
    initHierarchy("#hierarchy-container", state.gapminder, handleContinentHover);
    
    setupControls();
    updateTask2(state.currentYear);
    console.log("Dashboard Ready.");
}

// --- Interaction Handlers ---

function handleTimeBrush(range) {
    state.filters.yearRange = range;
    triggerUpdates();
}

function handleFuelClick(fuelType) {
    if (state.filters.selectedFuels.has(fuelType)) state.filters.selectedFuels.delete(fuelType);
    else state.filters.selectedFuels.add(fuelType);
    triggerUpdates();
}

function handleContinentHover(continent) {
    // Req 2.3: Lower opacity of bubbles not in continent
    d3.selectAll(".country-bubble")
        .attr("opacity", d => {
            if (!continent) return 0.8; 
            return d.continent === continent ? 1 : 0.1;
        });
}

function triggerUpdates() {
    // 1. Filter the RAW data based on Time Range and Fuel Selection
    const filteredData = state.powerData.filter(d => {
        const year = d.commissioning_year;
        // Strict Year Filter
        if (!year || year < state.filters.yearRange[0] || year > state.filters.yearRange[1]) return false;
        
        // Fuel Filter (if any selected)
        if (state.filters.selectedFuels.size > 0 && !state.filters.selectedFuels.has(d.primary_fuel)) return false;
        
        return true;
    });

    // 2. Update Map
    updateMapFilter(filteredData);

    // 3. Update Bubbles (CRITICAL FIX: Passing filteredData AND selectedFuels)
    updateBubblesFilter(filteredData, state.filters.selectedFuels);
}

// --- Animation Controls ---
function setupControls() {
    // Clean up existing controls if re-running
    d3.select("#slider-container").selectAll("*").remove();

    const slider = d3.select("#slider-container").append("input")
        .attr("type", "range")
        .attr("min", state.minYear).attr("max", state.maxYear)
        .attr("value", state.minYear).attr("step", 1)
        .style("width", "300px")
        .on("input", function() {
            stopAnimation();
            state.currentYear = +this.value;
            updateTask2(state.currentYear);
        });

    d3.select("#play-btn").on("click", () => {
        if (state.isPlaying) stopAnimation();
        else startAnimation();
    });
}

function startAnimation() {
    state.isPlaying = true;
    d3.select("#play-btn").text("Pause");
    state.timer = d3.interval(() => {
        state.currentYear++;
        if (state.currentYear > state.maxYear) state.currentYear = state.minYear;
        
        // Update Slider UI
        d3.select("input[type=range]").property("value", state.currentYear);
        
        // Update Charts
        updateTask2(state.currentYear);
    }, 200);
}

function stopAnimation() {
    state.isPlaying = false;
    d3.select("#play-btn").text("Play");
    if (state.timer) state.timer.stop();
}

function updateTask2(year) {
    d3.select("#year-label").text(year);
    const yearData = state.gapminderByYear.get(year) || [];
    updateScatter(year); 
    updateChoropleth(year, yearData);
}

init();