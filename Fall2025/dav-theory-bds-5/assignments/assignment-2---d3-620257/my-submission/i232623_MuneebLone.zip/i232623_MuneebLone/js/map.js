// js/map.js
import { fuelColorScale, showTooltip, hideTooltip, getDimensions } from './utils.js';
import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

let svg, gMap, gAggregated, gIndividual;
let pathGenerator, projection;
let isDetailedView = false;
let width, height;

// Store references
let rawDataRef = [];

export async function initMap(containerId, aggregatedData, rawData)
{
    const container = d3.select(containerId);
    container.selectAll("*").remove(); 
    const dims = getDimensions(containerId.substring(1));
    width = dims.width;
    height = dims.height;

    // 1. Define Projection LOCALLY (Matches the map layer)
    projection = d3.geoNaturalEarth1()
        .scale(width / 5.5)
        .translate([width / 2, height / 2]);

    rawDataRef = rawData;

    svg = container.append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .style("background", "#1e3f5a");

    pathGenerator = d3.geoPath().projection(projection);

    gMap = svg.append("g").attr("class", "map-layer");
    gAggregated = svg.append("g").attr("class", "aggregated-layer");
    gIndividual = svg.append("g").attr("class", "individual-layer");

    // Load Topology
    try {
        const worldData = await d3.json("https://unpkg.com/world-atlas@2.0.2/countries-110m.json");
        const countries = topojson.feature(worldData, worldData.objects.countries);
        gMap.selectAll("path").data(countries.features).join("path")
            .attr("d", pathGenerator).attr("fill", "#444").attr("stroke", "#666").attr("stroke-width", 0.5);
    } catch (e) { console.error(e); }

    const zoom = d3.zoom().scaleExtent([1, 10]).on("zoom", handleZoom);
    svg.call(zoom);

    renderAggregated(aggregatedData);
}

function handleZoom(e)
{
    const t = e.transform;
    gMap.attr("transform", t);
    gAggregated.attr("transform", t);
    gIndividual.attr("transform", t);

    // Semantic Zoom Logic
    if (t.k > 4) 
    {
        if (!isDetailedView) 
        {
            isDetailedView = true;
            gAggregated.transition().duration(300).style("opacity", 0);
        }
        
        // FIX: Calculate coordinates ON THE FLY using the local projection.
        // We filter out points that are off-screen to keep performance high.
        const visiblePoints = rawDataRef.filter(d => {
            const coords = projection([d.longitude, d.latitude]);
            if (!coords) return false;
            
            // Apply the zoom transform to the coordinates to see if they are in the box
            const [tx, ty] = t.apply(coords);
            return tx >= 0 && tx <= width && ty >= 0 && ty <= height;
        });
        
        renderIndividual(visiblePoints);
    } 
    else 
    {
        if (isDetailedView) 
        {
            isDetailedView = false;
            gAggregated.transition().duration(300).style("opacity", 1);
            gIndividual.selectAll("circle").remove();
        }
    }
}

function renderAggregated(data)
{
    const rScale = d3.scaleSqrt()
        .domain([0, d3.max(data, d => d.total_capacity) || 1000]) 
        .range([2, 25]);

    gAggregated.selectAll("circle")
        .data(data, d => d.country) 
        .join(
            enter => enter.append("circle")
                .attr("cx", d => projection([d.longitude, d.latitude])[0])
                .attr("cy", d => projection([d.longitude, d.latitude])[1])
                .attr("r", 0)
                .attr("fill", "rgba(200, 50, 50, 0.8)")
                .attr("stroke", "white")
                .call(enter => enter.transition().duration(500).attr("r", d => rScale(d.total_capacity))),
            update => update.call(update => update.transition().duration(500)
                .attr("r", d => rScale(d.total_capacity))), 
            exit => exit.transition().duration(500).attr("r", 0).remove()
        )
        .on("mouseover", (e, d) => showTooltip(e, `<b>${d.country}</b><br>Plants: ${d.count}<br>Capacity: ${Math.round(d.total_capacity)} MW`))
        .on("mouseout", hideTooltip);
}

function renderIndividual(data)
{
    const k = d3.zoomTransform(svg.node()).k;
    
    // NOTE: We do not use a key function (d => d.name) here for performance reasons 
    // when panning rapidly with 1000s of nodes.
    gIndividual.selectAll("circle")
        .data(data)
        .join("circle")
        // FIX: Calculate position using projection
        .attr("cx", d => projection([d.longitude, d.latitude])[0])
        .attr("cy", d => projection([d.longitude, d.latitude])[1])
        .attr("r", 4 / k) // Dots get smaller as you zoom in deeper
        .attr("fill", d => fuelColorScale(d.primary_fuel))
        .attr("opacity", 0.8)
        .on("mouseover", (e, d) => showTooltip(e, `<b>${d.name}</b><br>Fuel: ${d.primary_fuel}`))
        .on("mouseout", hideTooltip);
}

// Logic to handle external filters (from timeline/fuel buttons)
export function updateMapFilter(filteredData)
{
    rawDataRef = filteredData;

    // Recalculate Aggregates
    const rolledUp = d3.rollup(filteredData,
        v => ({
            total_capacity: d3.sum(v, d => d.capacity_mw),
            count: v.length,
            lat: d3.mean(v, d => d.latitude),
            lon: d3.mean(v, d => d.longitude)
        }),
        d => d.country
    );

    const newAggregates = Array.from(rolledUp, ([key, value]) => ({
        country: key, ...value
    }));

    renderAggregated(newAggregates);

    // If already zoomed in, re-render individual dots immediately
    if (isDetailedView) 
    {
        const t = d3.zoomTransform(svg.node());
        handleZoom({ transform: t }); 
    }
}