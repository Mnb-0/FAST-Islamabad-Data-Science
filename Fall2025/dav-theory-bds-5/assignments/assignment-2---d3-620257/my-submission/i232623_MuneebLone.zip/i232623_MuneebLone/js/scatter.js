// js/scatter.js
import { showTooltip, hideTooltip, getDimensions } from './utils.js';

let svg, x, y, r, color;
let dataMap;
let gDots;
const margin = { top: 20, right: 20, bottom: 40, left: 60 };

export function initScatter(containerId, rawGapminder)
{
    const container = d3.select(containerId);
    container.selectAll("*").remove();
    const { width, height } = getDimensions(containerId.substring(1));
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    dataMap = d3.group(rawGapminder, d => d.year);

    svg = container.append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Log Scale with Safety Domain
    x = d3.scaleLog()
        .domain([200, 100000]) 
        .range([0, innerWidth])
        .nice();

    y = d3.scaleLinear()
        .domain([10, 90])
        .range([innerHeight, 0]);

    r = d3.scaleSqrt()
        .domain([0, 1400000000])
        .range([2, 40]);

    color = d3.scaleOrdinal(d3.schemeTableau10);

    svg.append("g")
        .attr("transform", `translate(0,${innerHeight})`)
        .call(d3.axisBottom(x).ticks(5, ","));

    svg.append("g").call(d3.axisLeft(y));

    // Labels
    svg.append("text")
        .attr("x", innerWidth / 2)
        .attr("y", innerHeight + 35)
        .attr("text-anchor", "middle")
        .text("GDP per Capita (Log)");

    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -innerHeight / 2)
        .attr("y", -40)
        .attr("text-anchor", "middle")
        .text("Life Expectancy");

    gDots = svg.append("g");
}

export function updateScatter(year)
{
    const yearData = dataMap.get(year) || [];

    const dots = gDots.selectAll("circle")
        .data(yearData, d => d.country);

    dots.join(
        enter => enter.append("circle")
            .attr("class", "country-bubble")
            // FIX: Handle 0 or null GDP which breaks Log Scales
            .attr("cx", d => x(Math.max(d.gdp, 1) || 200)) 
            .attr("cy", d => y(d.life_exp || 50))
            .attr("r", 0) 
            .attr("fill", d => color(d.continent))
            .attr("stroke", "#333")
            .attr("stroke-width", 0.5)
            .attr("opacity", 0.8)
            .on("mouseover", (e, d) => showTooltip(e, `<b>${d.country}</b><br>GDP: $${Math.round(d.gdp)}<br>Life Exp: ${d.life_exp}`))
            .on("mouseout", hideTooltip)
            .call(enter => enter.transition().duration(200).attr("r", d => r(d.pop))),
        
        update => update.call(update => update.transition().duration(200).ease(d3.easeLinear)
            .attr("cx", d => x(Math.max(d.gdp, 1) || 200)) // FIX here too
            .attr("cy", d => y(d.life_exp))
            .attr("r", d => r(d.pop))
        ),

        exit => exit.call(exit => exit.transition().duration(200).attr("r", 0).remove())
    );
}