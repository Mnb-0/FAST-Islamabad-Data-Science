// js/timeline.js
import { fuelColorScale, getDimensions } from './utils.js';
import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm";

let svg, brushComponent, x, y, area;
let onBrushCallback;

export function initTimeline(containerId, rawData, onBrush)
{
    onBrushCallback = onBrush;
    const container = d3.select(containerId);
    container.selectAll("*").remove();

    const { width, height } = getDimensions(containerId.substring(1));
    const margin = { top: 10, right: 20, bottom: 30, left: 50 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    svg = container.append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    // Extended range to cover new generated data
    const validData = rawData.filter(d => d.commissioning_year >= 1900 && d.commissioning_year <= 2025);
    
    const rolledUp = d3.rollup(
        validData,
        v => d3.sum(v, d => d.capacity_mw),
        d => d.commissioning_year,
        d => d.primary_fuel
    );

    const fuels = fuelColorScale.domain();
    const years = Array.from(rolledUp.keys()).sort((a, b) => a - b);
    
    const stackedData = years.map(year => {
        const row = { year: year };
        const fuelMap = rolledUp.get(year);
        fuels.forEach(fuel => row[fuel] = fuelMap.get(fuel) || 0);
        return row;
    });

    x = d3.scaleLinear().domain([1900, 2025]).range([0, innerWidth]);
    
    const maxVal = d3.max(stackedData, d => fuels.reduce((acc, k) => acc + d[k], 0)) || 1000;
    y = d3.scaleLinear().domain([0, maxVal]).range([innerHeight, 0]);

    area = d3.area()
        .x(d => x(d.data.year))
        .y0(d => y(d[0]))
        .y1(d => y(d[1]));

    const stack = d3.stack().keys(fuels);
    const layers = stack(stackedData);

    svg.selectAll("path")
        .data(layers)
        .join("path")
        .attr("d", area)
        .attr("fill", d => fuelColorScale(d.key))
        .attr("opacity", 0.9);

    svg.append("g")
        .attr("transform", `translate(0,${innerHeight})`)
        .call(d3.axisBottom(x).tickFormat(d3.format("d")));

    svg.append("g")
        .call(d3.axisLeft(y).ticks(5).tickFormat(d => d / 1000 + "GW"));

    brushComponent = d3.brushX()
        .extent([[0, 0], [innerWidth, innerHeight]])
        .on("brush end", (e) => {
            if (!e.selection) {
                if (e.type === "end") onBrushCallback([1900, 2025]);
                return;
            }
            const [x0, x1] = e.selection.map(x.invert);
            onBrushCallback([Math.round(x0), Math.round(x1)]);
        });

    svg.append("g").attr("class", "brush").call(brushComponent);
}