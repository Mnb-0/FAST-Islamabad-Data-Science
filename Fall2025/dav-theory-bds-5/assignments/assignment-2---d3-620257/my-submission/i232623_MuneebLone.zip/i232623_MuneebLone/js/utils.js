// js/utils.js

// A shared color scale for Fuel Types to ensure consistency across Map, Bubbles, and Timeline.
export const fuelColorScale = d3.scaleOrdinal()
    .domain(["Hydro", "Solar", "Wind", "Nuclear", "Gas", "Coal", "Oil", "Biomass", "Waste", "Geothermal"])
    // Using a distinct scheme
    .range(d3.schemeTableau10);

// Generic Tooltip Manager
// Move the tooltip div to the mouse coordinates
export function showTooltip(event, htmlContent)
{
    const tooltip = d3.select("#tooltip");
    
    tooltip
        .html(htmlContent)
        .classed("hidden", false)
        .style("left", (event.pageX + 15) + "px")
        .style("top", (event.pageY - 28) + "px");
}

export function hideTooltip()
{
    d3.select("#tooltip").classed("hidden", true);
}

// Helper to get dimensions of a container for responsiveness
export function getDimensions(containerId)
{
    const element = document.getElementById(containerId);
    return {
        width: element.clientWidth,
        height: element.clientHeight
    };
}