import pandas as pd
import json

# Configuration: Map your downloaded filenames here
FILES = {
    "gdp": "data/gdp.csv",   # Replace with your actual filename for Income
    "lex": "data/lex.csv",   # Replace with your actual filename for Life Exp
    "pop": "data/pop.csv"    # Replace with your actual filename for Population
}

def clean_gapminder(file_path, metric_name):
    """Reads a wide Gapminder CSV and melts it to long format."""
    try:
        df = pd.read_csv(file_path)
        # Gapminder CSVs usually have 'geo' or 'country' as the first column
        id_col = df.columns[0] 
        
        # Melt columns 1800-2100 into rows
        df_long = df.melt(id_vars=[id_col], var_name="year", value_name=metric_name)
        
        # Clean data
        df_long.rename(columns={id_col: "country"}, inplace=True)
        df_long["year"] = pd.to_numeric(df_long["year"], errors="coerce")
        df_long[metric_name] = pd.to_numeric(df_long[metric_name], errors="coerce")
        
        return df_long.dropna()
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return None

print("Processing Gapminder Data...")

# 1. Load and Clean all 3 datasets
df_gdp = clean_gapminder(FILES["gdp"], "gdp")
df_lex = clean_gapminder(FILES["lex"], "life_exp")
df_pop = clean_gapminder(FILES["pop"], "pop")

if df_gdp is not None and df_lex is not None and df_pop is not None:
    # 2. Merge them into one DataFrame
    # Outer join ensures we keep data even if a year is missing in one file
    merged = pd.merge(df_gdp, df_lex, on=["country", "year"], how="inner")
    merged = pd.merge(merged, df_pop, on=["country", "year"], how="inner")

    # 3. Add Continent (Optional: Simple mapping for color)
    # For a real assignment, you might need a separate country-continent mapping file.
    # We will let D3 handle missing continents or map them later.
    
    # 4. Filter relevant years (Task 2 doesn't need 1800-2100 usually, but we keep it)
    merged = merged[(merged["year"] >= 1800) & (merged["year"] <= 2025)]
    
    # 5. Save to JSON
    output_file = "data/gapminder_combined.json"
    merged.to_json(output_file, orient="records")
    
    print(f"Success! Created {output_file} with {len(merged)} records.")
    print("Columns:", list(merged.columns))
else:
    print("Failed to process files. Please check filenames.")