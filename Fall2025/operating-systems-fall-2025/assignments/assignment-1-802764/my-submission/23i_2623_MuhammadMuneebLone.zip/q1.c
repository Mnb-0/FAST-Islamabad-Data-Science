#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        fprintf(stderr, "Usage: %s <boss_health> <num_minions>\n", argv[0]);
        return 1;
    }

    // Server announces itself
    printf("SERVER-READY\n");
    fflush(stdout);

    pid_t boss = fork();
    if (boss < 0)
    {
        perror("Boss fork failed");
        exit(EXIT_FAILURE);
    }
    else if (boss == 0)
    {
        // Child: Boss
        printf("BOSS-SPAWN\n");
        fflush(stdout);

        int hp = atoi(argv[1]);
        int num_minions = atoi(argv[2]);

        if (hp % 2 == 0)
        {
            // Even HP → spawn minions sequentially
            for (int i = 1; i <= num_minions; i++)
            {
                pid_t minion = fork();
                if (minion < 0)
                {
                    perror("Minion fork failed");
                    // Try to reap any already spawned children before dying
                    while (wait(NULL) > 0)
                    {
                    }
                    _exit(1);
                }
                else if (minion == 0)
                {
                    // Minion process
                    printf("MINION-%d\n", i);
                    fflush(stdout);
                    _exit(0);
                }
                else
                {
                    // Boss waits for each minion before spawning next
                    if (wait(NULL) < 0)
                    {
                        perror("Boss wait failed");
                        _exit(1);
                    }
                }
            }
        }
        // Boss done
        _exit(0);
    }
    else
    {
        // Parent: Server waits for boss
        if (wait(NULL) < 0)
        {
            perror("Server wait failed");
            exit(1);
        }

        // Compute total processes created
        int hp = atoi(argv[1]);
        int num_minions = atoi(argv[2]);
        int total = 1 + 1; // server + boss
        if (hp % 2 == 0)
        {
            total += num_minions;
        }
        printf("TOTAL-PROCESSES: %d\n", total);
        fflush(stdout);
        if (total > 255)
        {
            total = 255; // exit status limited
        }
        return total;
    }
}