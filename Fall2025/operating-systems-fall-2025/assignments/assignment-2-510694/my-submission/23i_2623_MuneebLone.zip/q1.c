#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <pthread.h>
#include <arpa/inet.h>

#define CHUNK_SIZE 3
#define MAX_MSG_LEN 1024

typedef struct
{
    int seq;
    int shift;
    char chunk[CHUNK_SIZE + 1];
} ChunkArgs;

// read exactly n bytes
ssize_t read_n(int fd, void *buf, size_t n)
{
    size_t remaining = n;
    char *dest = (char *)buf;
    while (remaining > 0)
    {
        ssize_t bytes_read = read(fd, dest, remaining);
        if (bytes_read < 0)
        {
            if (errno == EINTR)
                continue;
            return -1;
        }
        if (bytes_read == 0)
            return (ssize_t)(n - remaining); // EOF: return bytes actually read
        dest += bytes_read;
        remaining -= bytes_read;
    }
    return (ssize_t)n;
}

// write exactly n bytes
ssize_t write_n(int fd, const void *buffer, size_t count)
{
    size_t remaining = count;
    const char *write_ptr = (const char *)buffer;
    while (remaining > 0)
    {
        ssize_t bytes_written = write(fd, write_ptr, remaining);
        if (bytes_written < 0)
        {
            if (errno == EINTR)
                continue;
            return -1;
        }
        write_ptr += bytes_written;
        remaining -= (size_t)bytes_written;
    }
    return (ssize_t)count;
}

// Caesar encrypt
void caesar_encrypt(char *text, int shift)
{
    for (int i = 0; text[i]; i++)
    {
        char c = text[i];
        if (c >= 'A' && c <= 'Z')
            text[i] = (char)(((c - 'A' + shift) % 26) + 'A');
        else if (c >= 'a' && c <= 'z')
            text[i] = (char)(((c - 'a' + shift) % 26) + 'a');
    }
}

// Caesar decrypt
void caesar_decrypt(char *text, int shift)
{
    for (int i = 0; text[i]; i++)
    {
        char c = text[i];
        if (c >= 'A' && c <= 'Z')
            text[i] = (char)(((c - 'A' - shift + 26) % 26) + 'A');
        else if (c >= 'a' && c <= 'z')
            text[i] = (char)(((c - 'a' - shift + 26) % 26) + 'a');
    }
}

// thread for encrypting one chunk in-place
void *encrypt_worker(void *arg)
{
    ChunkArgs *a = (ChunkArgs *)arg;
    caesar_encrypt(a->chunk, a->shift);
    return NULL;
}

// thread for decrypting one chunk in-place
void *decrypt_worker(void *arg)
{
    ChunkArgs *a = (ChunkArgs *)arg;
    caesar_decrypt(a->chunk, a->shift);
    return NULL;
}

// split message into chunks (length tracked so no padding needed)
int build_chunks_from_plain(const char *msg, ChunkArgs **out_chunks)
{
    size_t mlen = strlen(msg);
    int num = (mlen + CHUNK_SIZE - 1) / CHUNK_SIZE;
    ChunkArgs *chunks = calloc(num, sizeof(ChunkArgs));
    if (!chunks)
        return -1;
    for (int i = 0; i < num; ++i)
    {
        size_t off = i * CHUNK_SIZE;
        size_t copy_len = (off + CHUNK_SIZE <= mlen) ? CHUNK_SIZE : (mlen - off);
        memset(chunks[i].chunk, 0, CHUNK_SIZE + 1);
        memcpy(chunks[i].chunk, msg + off, copy_len);
        chunks[i].seq = i;
    }
    *out_chunks = chunks;
    return num;
}

// assemble chunks into a single string (concatenate in order)
void assemble_from_chunks(ChunkArgs *chunks, int num, char *out_buf, size_t out_size)
{
    size_t pos = 0;
    for (int i = 0; i < num; ++i)
    {
        size_t clen = strlen(chunks[i].chunk);
        if (pos + clen >= out_size)
            break;
        memcpy(out_buf + pos, chunks[i].chunk, clen);
        pos += clen;
    }
    out_buf[pos] = '\0';
}

// alpha_to_bravo[1] is write end, bravo_to_alpha[0] is read end
int alpha_send_and_receive(int alpha_to_bravo_w, int bravo_to_alpha_r, int initial_n)
{
    char inbuf[MAX_MSG_LEN];
    while (1)
    {
        printf("\n[Alpha Command] Enter plaintext (0 to quit): ");
        if (!fgets(inbuf, sizeof(inbuf), stdin))
            return 0;
        size_t len = strlen(inbuf);
        if (len > 0 && inbuf[len - 1] == '\n')
            inbuf[len - 1] = '\0';

        // terminate on "0"
        if (strcmp(inbuf, "0") == 0)
        {
            uint32_t payload_len = htonl(1);
            if (write_n(alpha_to_bravo_w, &payload_len, sizeof(payload_len)) < 0)
                return -1;
            if (write_n(alpha_to_bravo_w, "0", 1) < 0)
                return -1;
            return 0;
        }

        // build chunks and assign shifting sequence
        ChunkArgs *chunks = NULL;
        int num_chunks = build_chunks_from_plain(inbuf, &chunks);
        if (num_chunks <= 0)
        {
            free(chunks);
            return -1;
        }

        int n = initial_n;
        for (int i = 0; i < num_chunks; ++i)
        {
            chunks[i].shift = n;
            n += 2;
        }

        // spawn encrypt threads
        pthread_t *tids = malloc(sizeof(pthread_t) * num_chunks);
        if (!tids) // check malloc
        {
            free(chunks);
            return -1;
        }
        for (int i = 0; i < num_chunks; ++i)
        {
            if (pthread_create(&tids[i], NULL, encrypt_worker, &chunks[i]) != 0)
            {
                // handle error by joining those already created
                for (int j = 0; j < i; ++j)
                    pthread_join(tids[j], NULL);
                free(tids);
                free(chunks);
                return -1;
            }
        }
        for (int i = 0; i < num_chunks; ++i)
            pthread_join(tids[i], NULL);

        // assemble encrypted message and send framed
        char encrypted[MAX_MSG_LEN];
        assemble_from_chunks(chunks, num_chunks, encrypted, sizeof(encrypted));

        printf("[Alpha Command] Encrypted text: %s\n", encrypted);

        uint32_t payload_len = htonl((uint32_t)strlen(encrypted));
        if (write_n(alpha_to_bravo_w, &payload_len, sizeof(payload_len)) < 0)
        {
            free(tids);
            free(chunks);
            return -1;
        }
        if (write_n(alpha_to_bravo_w, encrypted, strlen(encrypted)) < 0)
        {
            free(tids);
            free(chunks);
            return -1;
        }

        free(tids);
        free(chunks);

        // wait for reply from bravo
        uint32_t netlen;
        if (read_n(bravo_to_alpha_r, &netlen, sizeof(netlen)) != sizeof(netlen))
        {
            fprintf(stderr, "[Alpha] failed to read reply length\n");
            return -1;
        }
        uint32_t reply_len = ntohl(netlen);
        if (reply_len == 0)
            continue; // ignore 0-length frames (empty message)
        if (reply_len > MAX_MSG_LEN - 1)
        {
            fprintf(stderr, "[Alpha] reply too large\n");
            // drain or error
            char discard[64];
            size_t left = reply_len;
            while (left)
            {
                ssize_t r = read(bravo_to_alpha_r, discard, (left > sizeof(discard)) ? sizeof(discard) : left);
                if (r <= 0)
                    break;
                left -= r;
            }
            continue;
        }
        char reply_buf[MAX_MSG_LEN];
        if (read_n(bravo_to_alpha_r, reply_buf, reply_len) != (ssize_t)reply_len)
        {
            fprintf(stderr, "[Alpha] failed to read reply payload\n");
            return -1;
        }
        reply_buf[reply_len] = '\0';

        // termination from Bravo
        if (reply_len == 1 && reply_buf[0] == '0')
        {
            printf("[Alpha Command] Bravo terminated communication.\n");
            return 0;
        }

        // decrypt reply using same chunking & n progression
        ChunkArgs *rchunks = NULL;
        int rnum = build_chunks_from_plain(reply_buf, &rchunks);
        if (rnum <= 0)
        {
            free(rchunks);
            return -1;
        }
        n = initial_n;
        pthread_t *rtids = malloc(sizeof(pthread_t) * rnum);

        if (!rtids)
        {
            free(rchunks);
            return -1;
        }
        for (int i = 0; i < rnum; ++i)
        {
            rchunks[i].shift = n;
            n += 2;
            if (pthread_create(&rtids[i], NULL, decrypt_worker, &rchunks[i]) != 0)
            {
                // join threads created so far
                for (int j = 0; j < i; ++j)
                    pthread_join(rtids[j], NULL);
                free(rtids);
                free(rchunks);
                return -1; // send error forward
            }
        }

        for (int i = 0; i < rnum; ++i)
            pthread_join(rtids[i], NULL);

        char plaintext[MAX_MSG_LEN];
        assemble_from_chunks(rchunks, rnum, plaintext, sizeof(plaintext));
        printf("[Alpha Command] Bravo replied: %s\n", plaintext);

        free(rtids);
        free(rchunks);
    }
    // unreachable
    return 0;
}

// Bravo: listen and reply
int bravo_listen_and_reply(int alpha_to_bravo_r, int bravo_to_alpha_w, int initial_n)
{
    while (1)
    {
        uint32_t netlen;
        ssize_t rn = read_n(alpha_to_bravo_r, &netlen, sizeof(netlen));
        if (rn == 0)
        {
            // EOF on pipe: peer closed
            return 0;
        }
        if (rn != sizeof(netlen))
        {
            fprintf(stderr, "[Bravo] failed to read length header\n");
            return -1;
        }
        uint32_t msg_len = ntohl(netlen);
        if (msg_len == 0)
            continue;
        if (msg_len > MAX_MSG_LEN - 1)
        {
            // drain and skip
            char tmp[64];
            size_t left = msg_len;
            while (left)
            {
                ssize_t r = read(alpha_to_bravo_r, tmp, (left > sizeof(tmp)) ? sizeof(tmp) : left);
                if (r <= 0)
                    break;
                left -= r;
            }
            continue;
        }
        char buf[MAX_MSG_LEN];
        if (read_n(alpha_to_bravo_r, buf, msg_len) != (ssize_t)msg_len)
        {
            fprintf(stderr, "[Bravo] failed to read payload\n");
            return -1;
        }
        buf[msg_len] = '\0';

        // termination
        if (msg_len == 1 && buf[0] == '0')
        {
            // echo termination back and exit
            uint32_t tlen = htonl(1);
            write_n(bravo_to_alpha_w, &tlen, sizeof(tlen));
            write_n(bravo_to_alpha_w, "0", 1);
            return 0;
        }

        // decrypt incoming message
        ChunkArgs *chunks = NULL;
        int num_chunks = build_chunks_from_plain(buf, &chunks);
        if (num_chunks <= 0)
        {
            free(chunks);
            return -1;
        }
        int n = initial_n;
        pthread_t *tids = malloc(sizeof(pthread_t) * num_chunks);

        if (!tids)
        {
            free(chunks);
            return -1;
        }
        for (int i = 0; i < num_chunks; ++i)
        {
            chunks[i].shift = n;
            n += 2;
            if (pthread_create(&tids[i], NULL, decrypt_worker, &chunks[i]) != 0)
            {
                for (int j = 0; j < i; ++j)
                    pthread_join(tids[j], NULL);
                free(tids);
                free(chunks);
                return -1;
            }
        }

        for (int i = 0; i < num_chunks; ++i)
            pthread_join(tids[i], NULL);

        char plaintext[MAX_MSG_LEN];
        assemble_from_chunks(chunks, num_chunks, plaintext, sizeof(plaintext));
        printf("[Bravo Command] Decrypted: %s\n", plaintext);

        // echo plain text
        const char *reply_plain = plaintext;

        // encrypt reply
        ChunkArgs *rchunks = NULL;
        int rnum = build_chunks_from_plain(reply_plain, &rchunks);
        if (rnum <= 0)
        {
            free(rchunks);
            free(chunks);
            free(tids);
            return -1;
        }
        n = initial_n;
        pthread_t *rtids = malloc(sizeof(pthread_t) * rnum);

        if (!rtids)
        {
            free(rchunks);
            free(chunks);
            free(tids);
            return -1;
        }
        for (int i = 0; i < rnum; ++i)
        {
            rchunks[i].shift = n;
            n += 2;
            if (pthread_create(&rtids[i], NULL, encrypt_worker, &rchunks[i]) != 0)
            {
                for (int j = 0; j < i; ++j)
                    pthread_join(rtids[j], NULL);
                free(rtids);
                free(rchunks);
                free(chunks);
                free(tids);
                return -1;
            }
        }

        for (int i = 0; i < rnum; ++i)
            pthread_join(rtids[i], NULL);

        char encrypted_reply[MAX_MSG_LEN];
        assemble_from_chunks(rchunks, rnum, encrypted_reply, sizeof(encrypted_reply));

        // send framed reply
        uint32_t out_len = htonl((uint32_t)strlen(encrypted_reply));
        write_n(bravo_to_alpha_w, &out_len, sizeof(out_len));
        write_n(bravo_to_alpha_w, encrypted_reply, strlen(encrypted_reply));

        free(chunks);
        free(tids);
        free(rchunks);
        free(rtids);
    }
    return 0;
}

int main()
{
    int alpha_to_bravo[2];
    int bravo_to_alpha[2];
    if (pipe(alpha_to_bravo) < 0 || pipe(bravo_to_alpha) < 0)
    {
        perror("pipe");
        return 1;
    }

    int initial_n = 2;

    pid_t pid = fork();
    if (pid < 0)
    {
        perror("fork");
        return 1;
    }

    if (pid == 0)
    {
        // Child -> Bravo
        close(alpha_to_bravo[1]); // close write end
        close(bravo_to_alpha[0]); // close read end
        int ret = bravo_listen_and_reply(alpha_to_bravo[0], bravo_to_alpha[1], initial_n);
        close(alpha_to_bravo[0]);
        close(bravo_to_alpha[1]);
        if (ret == 0)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    else
    {
        // Parent -> Alpha
        close(alpha_to_bravo[0]); // close read end
        close(bravo_to_alpha[1]); // close write end
        int ret = alpha_send_and_receive(alpha_to_bravo[1], bravo_to_alpha[0], initial_n);
        close(alpha_to_bravo[1]);
        close(bravo_to_alpha[0]);
        if (ret == 0)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}