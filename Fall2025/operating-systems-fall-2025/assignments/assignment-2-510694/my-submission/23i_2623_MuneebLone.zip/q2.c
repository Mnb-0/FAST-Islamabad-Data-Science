#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define BUF_SIZE 1024

// reverses the string (in-place)
void reverse_string(char *str)
{
    int len = strlen(str);
    int i = 0, j = len - 1;
    while (i < j)
    {
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

// swaps vowels for *
void mask_vowels(char *str)
{
    for (int i = 0; str[i]; i++)
    {
        char lower = (char)tolower(str[i]);
        if (lower == 'a' || lower == 'e' || lower == 'i' || lower == 'o' || lower == 'u')
        {
            str[i] = '*';
        }
    }
}

// rotates letters by 1 (a->b, z->a)
void rotate_chars(char *str)
{
    for (int i = 0; str[i]; i++)
    {
        if (str[i] >= 'a' && str[i] < 'z')
        {
            str[i] = (char)(str[i] + 1);
        }
        else if (str[i] == 'z')
        {
            str[i] = 'a'; // wrap around
        }
        else if (str[i] >= 'A' && str[i] < 'Z')
        {
            str[i] = (char)(str[i] + 1);
        }
        else if (str[i] == 'Z')
        {
            str[i] = 'A'; // wrap around
        }
    }
}

// simple checksum
int calculate_checksum(const char *str)
{
    int sum = 0;
    for (int i = 0; str[i]; i++)
    {
        sum += str[i];
    }
    return sum % 255;
}

int main(void)
{
    char buffer[BUF_SIZE];
    ssize_t nbytes;

    // pipe for each connection
    int p_main_to_a1[2];  // Main -> A1
    int p_a1_to_a2[2];    // A1   -> A2
    int p_a2_to_a3[2];    // A2   -> A3
    int p_a3_to_a1[2];    // A3   -> A1
    int p_a1_to_a4[2];    // A1   -> A4
    int p_a4_to_omega[2]; // A4   -> Omega
    int p_omega_to_a4[2]; // Omega -> A4

    // create all the pipes at once
    if (pipe(p_main_to_a1) < 0 || pipe(p_a1_to_a2) < 0 || pipe(p_a2_to_a3) < 0 ||
        pipe(p_a3_to_a1) < 0 || pipe(p_a1_to_a4) < 0 || pipe(p_a4_to_omega) < 0 ||
        pipe(p_omega_to_a4) < 0)
    {
        perror("pipe creation failed");
        exit(1);
    }

    pid_t pid1, pid2, pid3, pid4;

    // --- Agent 1 (Reverser) ---
    if ((pid1 = fork()) < 0)
    {
        perror("fork Agent 1 failed");
        exit(1);
    }
    if (pid1 == 0)
    {
        // close all pipes that aren't needed
        close(p_main_to_a1[1]);
        close(p_a1_to_a2[0]);
        close(p_a2_to_a3[0]);
        close(p_a2_to_a3[1]);
        close(p_a3_to_a1[1]);
        close(p_a1_to_a4[0]);
        close(p_a4_to_omega[0]);
        close(p_a4_to_omega[1]);
        close(p_omega_to_a4[0]);
        close(p_omega_to_a4[1]);

        // read from main
        nbytes = read(p_main_to_a1[0], buffer, BUF_SIZE);
        if (nbytes > 0)
        {
            buffer[nbytes] = '\0';
            printf("got '%s'\n", buffer);
            reverse_string(buffer);
            printf("reversed, sending '%s'\n", buffer);
            write(p_a1_to_a2[1], buffer, strlen(buffer));
        }
        close(p_main_to_a1[0]);
        close(p_a1_to_a2[1]);

        // get msg back from agent 3
        nbytes = read(p_a3_to_a1[0], buffer, BUF_SIZE);
        if (nbytes > 0)
        {
            buffer[nbytes] = '\0';
            printf("got from A3 '%s'\n", buffer);
            // add my pid
            sprintf(buffer + strlen(buffer), "[PID:%d]", getpid());
            write(p_a1_to_a4[1], buffer, strlen(buffer));
        }
        close(p_a3_to_a1[0]);
        close(p_a1_to_a4[1]);

        exit(0);
    }

    // --- Agent 2 (Vowel guy) ---
    if ((pid2 = fork()) < 0)
    {
        perror("fork Agent 2 failed");
        exit(1);
    }
    if (pid2 == 0)
    {
        // close all pipes that aren't needed
        close(p_main_to_a1[0]);
        close(p_main_to_a1[1]);
        close(p_a1_to_a2[1]);
        close(p_a2_to_a3[0]);
        close(p_a3_to_a1[0]);
        close(p_a3_to_a1[1]);
        close(p_a1_to_a4[0]);
        close(p_a1_to_a4[1]);
        close(p_a4_to_omega[0]);
        close(p_a4_to_omega[1]);
        close(p_omega_to_a4[0]);
        close(p_omega_to_a4[1]);

        nbytes = read(p_a1_to_a2[0], buffer, BUF_SIZE);
        if (nbytes > 0)
        {
            buffer[nbytes] = '\0';
            printf("got '%s'\n", buffer);
            mask_vowels(buffer);
            write(p_a2_to_a3[1], buffer, strlen(buffer));
        }
        close(p_a1_to_a2[0]);
        close(p_a2_to_a3[1]);

        exit(0);
    }

    // --- Agent 3 (Rotator) ---
    if ((pid3 = fork()) < 0)
    {
        perror("fork Agent 3 failed");
        exit(1);
    }
    if (pid3 == 0)
    {
        close(p_main_to_a1[0]);
        close(p_main_to_a1[1]);
        close(p_a1_to_a2[0]);
        close(p_a1_to_a2[1]);
        close(p_a2_to_a3[1]);
        close(p_a3_to_a1[0]);
        close(p_a1_to_a4[0]);
        close(p_a1_to_a4[1]);
        close(p_a4_to_omega[0]);
        close(p_a4_to_omega[1]);
        close(p_omega_to_a4[0]);
        close(p_omega_to_a4[1]);

        nbytes = read(p_a2_to_a3[0], buffer, BUF_SIZE);
        if (nbytes > 0)
        {
            buffer[nbytes] = '\0';
            printf("got '%s'\n", buffer);
            rotate_chars(buffer);
            write(p_a3_to_a1[1], buffer, strlen(buffer));
        }
        close(p_a2_to_a3[0]);
        close(p_a3_to_a1[1]);

        exit(0);
    }

    // --- Agent 4 (Checksum / Dispatch) ---
    if ((pid4 = fork()) < 0)
    {
        perror("fork Agent 4 failed");
        exit(1);
    }
    if (pid4 == 0)
    {
        close(p_main_to_a1[0]);
        close(p_main_to_a1[1]);
        close(p_a1_to_a2[0]);
        close(p_a1_to_a2[1]);
        close(p_a2_to_a3[0]);
        close(p_a2_to_a3[1]);
        close(p_a3_to_a1[0]);
        close(p_a3_to_a1[1]);
        close(p_a1_to_a4[1]);
        close(p_a4_to_omega[0]);
        close(p_omega_to_a4[1]);

        nbytes = read(p_a1_to_a4[0], buffer, BUF_SIZE);
        if (nbytes > 0)
        {
            buffer[nbytes] = '\0';
            printf("got '%s'\n", buffer);
            int chk = calculate_checksum(buffer);
            // add the checksum
            sprintf(buffer + strlen(buffer), "[CHK:%d]", chk);
            write(p_a4_to_omega[1], buffer, strlen(buffer));
        }
        close(p_a1_to_a4[0]);
        close(p_a4_to_omega[1]);

        // wait for Omega to send an ACK back
        nbytes = read(p_omega_to_a4[0], buffer, BUF_SIZE);
        if (nbytes > 0)
        {
            buffer[nbytes] = '\0';
            printf("\n[Agent 4] Acknowledgment from Omega: %s\n", buffer);
        }
        close(p_omega_to_a4[0]);

        exit(0);
    }

    // --- Parent (Alpha AND Omega) ---

    close(p_main_to_a1[0]);
    close(p_a1_to_a2[0]);
    close(p_a1_to_a2[1]);
    close(p_a2_to_a3[0]);
    close(p_a2_to_a3[1]);
    close(p_a3_to_a1[0]);
    close(p_a3_to_a1[1]);
    close(p_a1_to_a4[0]);
    close(p_a1_to_a4[1]);
    close(p_a4_to_omega[1]);
    close(p_omega_to_a4[0]);

    // 1. Act as Alpha (get user input)
    printf("Enter plaintext message: ");
    if (fgets(buffer, BUF_SIZE, stdin) == NULL)
    {
        perror("fgets");
        exit(1);
    }
    // get rid of the newline from fgets
    buffer[strcspn(buffer, "\n")] = '\0';

    // send initial msg to agent 1
    write(p_main_to_a1[1], buffer, strlen(buffer));
    close(p_main_to_a1[1]); 

    // 2. Act as Omega (receive final msg)
    nbytes = read(p_a4_to_omega[0], buffer, BUF_SIZE);
    if (nbytes > 0)
    {
        buffer[nbytes] = '\0';
        printf("): received %s\n", buffer);
        printf("\nFinal Encrypted Transmission to Omega: %s\n", buffer);

        // send the ACK back to A4
        char ack_msg[100];
        int chk_val = 0;
        char *chk_str = strstr(buffer, "[CHK:"); // find the checksum string
        if (chk_str)
        {
            sscanf(chk_str, "[CHK:%d]", &chk_val); // parse the int value
        }
        sprintf(ack_msg, "ACK: Checksum %d verified.", chk_val);
        write(p_omega_to_a4[1], ack_msg, strlen(ack_msg));
    }
    close(p_a4_to_omega[0]);
    close(p_omega_to_a4[1]);

    // cleanup and wait for children
    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);
    waitpid(pid3, NULL, 0);
    waitpid(pid4, NULL, 0);
    printf("[Main] All agents have terminated.\n");

    return 0;
}