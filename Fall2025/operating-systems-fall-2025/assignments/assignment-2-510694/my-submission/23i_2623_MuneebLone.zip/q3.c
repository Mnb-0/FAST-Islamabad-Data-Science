#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_NAME_LEN 64
#define MAX_CARGO 20

typedef struct
{
    char name[MAX_NAME_LEN];
    double weight;
    double cost_per_kg;
    double total_cost;
} CargoItem;

typedef struct
{
    int num_items;
    CargoItem items[MAX_CARGO];
} CargoManifest;

// sort helper function to sort cargo by total_cost (descending)
int compare_cargo(const void *a, const void *b)
{
    CargoItem *itemA = (CargoItem *)a;
    CargoItem *itemB = (CargoItem *)b;

    // for descending order, compare B to A
    if (itemB->total_cost > itemA->total_cost)
        return 1;
    if (itemB->total_cost < itemA->total_cost)
        return -1;
    return 0;
}

// p2: insurance Calculation
void process_2_insurance(int read_fd, int write_fd)
{
    double total_cost, insured_total, insurance;

    // read total_cost from Process 1
    if (read(read_fd, &total_cost, sizeof(total_cost)) < 0)
    {
        perror("[P2] Read failed");
        exit(1);
    }

    insurance = total_cost * 0.05;
    insured_total = total_cost + insurance;

    printf("[P2 Insurance] Received Total: %.2f\n", total_cost);
    printf("[P2 Insurance] 5%% Insurance: %.2f\n", insurance);
    printf("[P2 Insurance] Forwarding Insured Total: %.2f\n", insured_total);

    // write insured_total to Process 3
    if (write(write_fd, &insured_total, sizeof(insured_total)) < 0)
    {
        perror("[P2] Write failed");
        exit(1);
    }

    close(read_fd);
    close(write_fd);
}

// p3: Interplanetary Tariff Check
void process_3_tariff(int read_fd, int write_fd)
{
    double insured_total, final_adjusted_total, tariff;

    // read insured_total from Process 2
    if (read(read_fd, &insured_total, sizeof(insured_total)) < 0)
    {
        perror("[P3] Read failed");
        exit(1);
    }

    printf("[P3 Tariff] Received Insured Total: %.2f\n", insured_total);

    // apply tariff/fee logic
    if (insured_total > 500.0)
    {
        tariff = insured_total * 0.12;
        final_adjusted_total = insured_total + tariff;
        printf("[P3 Tariff] Applying 12%% Tariff: %.2f\n", tariff);
    }
    else
    {
        tariff = 30.0;
        final_adjusted_total = insured_total + tariff;
        printf("[P3 Tariff] Applying 30-credit Service Fee.\n");
    }

    printf("[P3 Tariff] Forwarding Final Total: %.2f\n", final_adjusted_total);

    // final_adjusted_total to Process 4
    if (write(write_fd, &final_adjusted_total, sizeof(final_adjusted_total)) < 0)
    {
        perror("[P3] Write failed");
        exit(1);
    }

    close(read_fd);
    close(write_fd);
}

// P4: Final Cargo Report

void process_4_report(int read_fd_p3, int read_fd_p1)
{
    double final_total;
    CargoManifest manifest;

    // read the final total from Process 3
    if (read(read_fd_p3, &final_total, sizeof(final_total)) < 0)
    {
        perror("[P4] Read from P3 failed");
        exit(1);
    }

    // read the cargo manifest from Process 1
    if (read(read_fd_p1, &manifest, sizeof(manifest)) < 0)
    {
        perror("[P4] Read from P1 failed");
        exit(1);
    }

    // sort cargo items by total_cost (descending)
    qsort(manifest.items, manifest.num_items, sizeof(CargoItem), compare_cargo);

    // display the final report
    printf("\n\n--- [P4] Interplanetary Cargo Report ---\n");
    printf("===================================================\n");
    printf("Sorted Cargo Items (Highest Cost First):\n");
    printf("---------------------------------------------------\n");
    printf("%-20s | %-10s | %-10s | %-10s\n", "Name", "Weight(kg)", "Cost/kg", "Total Cost");
    printf("---------------------------------------------------\n");

    for (int i = 0; i < manifest.num_items; i++)
    {
        CargoItem item = manifest.items[i];
        printf("%-20s | %-10.2f | %-10.2f | %-10.2f\n",
               item.name, item.weight, item.cost_per_kg, item.total_cost);
    }

    printf("===================================================\n");
    printf("FINAL ADJUSTED TOTAL (incl. Insurance & Tariffs): %.2f\n", final_total);
    printf("===================================================\n");

    close(read_fd_p1);
    close(read_fd_p3);
}

int main()
{
    int p1_to_p2[2];
    int p2_to_p3[2];
    int p3_to_p4[2];
    int p1_to_p4[2];

    pid_t pid2, pid3, pid4;

    if (pipe(p1_to_p2) < 0 || pipe(p2_to_p3) < 0 || pipe(p3_to_p4) < 0 || pipe(p1_to_p4) < 0)
    {
        perror("Pipe creation failed");
        exit(1);
    }

    // p2 creation
    if ((pid2 = fork()) < 0)
    {
        perror("Fork P2 failed");
        exit(1);
    }
    if (pid2 == 0)
    {
        // P2 child
        close(p1_to_p2[1]); // close write end
        close(p2_to_p3[0]); // close read end

        // close unused pipes
        close(p3_to_p4[0]);
        close(p3_to_p4[1]);
        close(p1_to_p4[0]);
        close(p1_to_p4[1]);

        process_2_insurance(p1_to_p2[0], p2_to_p3[1]);
        exit(0);
    }

    // P3 creation
    if ((pid3 = fork()) < 0)
    {
        perror("Fork P3 failed");
        exit(1);
    }
    if (pid3 == 0)
    {
        // P3 child
        close(p2_to_p3[1]); // Close write end
        close(p3_to_p4[0]); // Close read end
        // Close unused pipes
        close(p1_to_p2[0]);
        close(p1_to_p2[1]);
        close(p1_to_p4[0]);
        close(p1_to_p4[1]);

        process_3_tariff(p2_to_p3[0], p3_to_p4[1]);
        exit(0);
    }

    // P4 creation
    if ((pid4 = fork()) < 0)
    {
        perror("Fork P4 failed");
        exit(1);
    }
    if (pid4 == 0)
    {
        // P4 child
        close(p3_to_p4[1]); // Close write end
        close(p1_to_p4[1]); // Close write end
        // Close unused pipes
        close(p1_to_p2[0]);
        close(p1_to_p2[1]);
        close(p2_to_p3[0]);
        close(p2_to_p3[1]);

        process_4_report(p3_to_p4[0], p1_to_p4[0]);
        exit(0);
    }

    // P1 Parent
    // Close all unused read ends
    close(p1_to_p2[0]);
    close(p2_to_p3[0]);
    close(p2_to_p3[1]); // P1 doesn't talk to P3
    close(p3_to_p4[0]);
    close(p3_to_p4[1]); // P1 doesn't talk to P4 (except p1_to_p4)
    close(p1_to_p4[0]);

    CargoManifest manifest;
    double overall_total_cost = 0;

    printf("[P1 Cargo Entry] How many cargo items (max %d)? ", MAX_CARGO);
    scanf("%d", &manifest.num_items);
    if (manifest.num_items > MAX_CARGO)
        manifest.num_items = MAX_CARGO;

    printf("\n--- [P1] Enter Cargo Details ---\n");
    for (int i = 0; i < manifest.num_items; i++)
    {
        CargoItem *item = &manifest.items[i];
        printf("Item %d Name: ", i + 1);
        scanf("%s", item->name);
        printf("Item %d Weight (kg): ", i + 1);
        scanf("%lf", &item->weight);
        printf("Item %d Cost/kg: ", i + 1);
        scanf("%lf", &item->cost_per_kg);

        item->total_cost = item->weight * item->cost_per_kg;
        overall_total_cost += item->total_cost;
        printf(" -> Item Total: %.2f\n", item->total_cost);
    }

    printf("\n--- [P1] Cargo Entry Summary ---\n");
    for (int i = 0; i < manifest.num_items; i++)
    {
        printf("Item: %-20s | Total Cost: %.2f\n",
               manifest.items[i].name, manifest.items[i].total_cost);
    }
    printf("--- Overall Cargo Total: %.2f ---\n", overall_total_cost);

    // send total cost to Process 2
    if (write(p1_to_p2[1], &overall_total_cost, sizeof(overall_total_cost)) < 0)
    {
        perror("[P1] Write to P2 failed");
    }

    // send the full manifest to Process 4
    if (write(p1_to_p4[1], &manifest, sizeof(manifest)) < 0)
    {
        perror("[P1] Write to P4 failed");
    }

    // close remaining pipes
    close(p1_to_p2[1]);
    close(p1_to_p4[1]);

    // wait for all children to finish
    waitpid(pid2, NULL, 0);
    waitpid(pid3, NULL, 0);
    waitpid(pid4, NULL, 0);

    printf("\n[P1 Cargo Entry] All processes complete. Shipment processed.\n");

    return 0;
}