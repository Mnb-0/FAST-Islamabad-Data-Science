/* src/common.h */
#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include <errno.h>

// ncurses grid size
#define GRID_H 25
#define GRID_W 60

// max cars to show in queue
#define VISUAL_QUEUE_LEN 5

// vehicle types (for namewise referencing)
typedef enum
{
    TYPE_AMBULANCE,
    TYPE_FIRETRUCK,
    TYPE_BUS,
    TYPE_CAR,
    TYPE_BIKE,
    TYPE_TRACTOR
} VehicleType;

// directions (for traffic flow)
typedef enum
{
    DIR_N,
    DIR_S,
    DIR_E,
    DIR_W
} Direction;

// traffic light states
typedef enum
{
    L_RED,
    L_GREEN
} LightState;

// main shared memory struct
// this is the map that everyone reads from and writes to
typedef struct
{
    // light states-> v = vertical (north/south), h = horizontal (east/west)
    LightState light_f10_v;
    LightState light_f10_h;
    LightState light_f11_v;
    LightState light_f11_h;

    // flags for when emergency vehicles are coming
    int f10_emerg;
    int f11_emerg;

    // global log buffer for the bottom of the screen
    char sys_msg[64];

    // counters for cars waiting at red lights
    // 0=N, 1=S, 2=E, 3=W
    int wait_cnt_f10[4];
    int wait_cnt_f11[4];

    // this holds the chars like 'A' or 'C' for the graphics
    // [4] is the directions and each direction has 5 spots in queue
    char v_queue_f10[4][VISUAL_QUEUE_LEN]; 
    char v_queue_f11[4][VISUAL_QUEUE_LEN];

    // parking logs (shows rejections etc)
    char log_park_f10[32];
    char log_park_f11[32];
} SimData;

// struct for sending messages through pipes
typedef struct
{
    int type; // 1 = emergency, 2 = coord
    int prio;
    Direction dir;
} PipeMsg;

#endif