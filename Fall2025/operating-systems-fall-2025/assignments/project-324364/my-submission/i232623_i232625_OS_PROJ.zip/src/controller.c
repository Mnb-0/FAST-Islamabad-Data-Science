/* src/controller.c */
#include "controller.h"
#include <string.h>

// helper to set lights easily
void switch_lights(SimData *d, int f10, LightState v, LightState h)
{
    if (f10)
    {
        d->light_f10_v = v;
        d->light_f10_h = h;
    }
    else
    {
        d->light_f11_v = v;
        d->light_f11_h = h;
    }
}

void logic_f10(int r_pipe, int w_pipe, SimData *d)
{
    PipeMsg m;
    // make pipe non blocking
    int fl = fcntl(r_pipe, F_GETFL, 0);
    fcntl(r_pipe, F_SETFL, fl | O_NONBLOCK); // OR to combine previous settings and nonblocking (dont sleep if pipe empty)

    while (1)
    {
        // see if we got a msg
        if (read(r_pipe, &m, sizeof(PipeMsg)) > 0)
        {
            // printf("debug: F10 got msg type %d\n", m.type);
            if (m.type == 1) // emergency
            {
                d->f10_emerg = 1;

                snprintf(d->sys_msg, 64, ">> F10: AMBULANCE DETECTED. CLEARING.");

                // force green vertical
                switch_lights(d, 1, L_GREEN, L_RED);

                // tell F11 to watch out
                PipeMsg coord = {2, 100, DIR_N};
                write(w_pipe, &coord, sizeof(PipeMsg));

                sleep(5);
                d->f10_emerg = 0;

                snprintf(d->sys_msg, 64, ">> F10: SITUATION CLEAR. RESETTING.");
            }
        }

        // normal cycle if no emergency
        if (!d->f10_emerg)
        {
            switch_lights(d, 1, L_GREEN, L_RED);
            sleep(2);
            switch_lights(d, 1, L_RED, L_GREEN);
            sleep(2);
        }
    }
}

void logic_f11(int r_pipe, int r_coord, SimData *d)
{
    PipeMsg m;
    // setup non blocking on both pipes
    int f1 = fcntl(r_pipe, F_GETFL, 0);
    fcntl(r_pipe, F_SETFL, f1 | O_NONBLOCK);

    int f2 = fcntl(r_coord, F_GETFL, 0);
    fcntl(r_coord, F_SETFL, f2 | O_NONBLOCK);

    while (1)
    {
        if (read(r_pipe, &m, sizeof(PipeMsg)) > 0)
        {
            if (m.type == 1) // emergency
            {
                d->f11_emerg = 1;

                snprintf(d->sys_msg, 64, ">> F11: AMBULANCE DETECTED. CLEARING.");

                // force green vertical for local emergency
                switch_lights(d, 0, L_GREEN, L_RED);

                sleep(5);
                d->f11_emerg = 0;

                snprintf(d->sys_msg, 64, ">> F11: SITUATION CLEAR. RESETTING.");
            }
        }

        // check for coordinate msg from F10
        if (read(r_coord, &m, sizeof(PipeMsg)) > 0)
        {
            d->f11_emerg = 1;

            snprintf(d->sys_msg, 64, ">> F11: STOPPING FOR F10. CLEARING.");

            // clear intersection
            switch_lights(d, 0, L_GREEN, L_RED);
            sleep(5);
            d->f11_emerg = 0;

            snprintf(d->sys_msg, 64, ">> F11: SITUATION CLEAR. RESETTING.");
        }

        if (!d->f11_emerg)
        {
            // offset cycle from F10 so they dont conflict
            switch_lights(d, 0, L_RED, L_GREEN);
            sleep(2);
            switch_lights(d, 0, L_GREEN, L_RED);
            sleep(2);
        }
    }
}