/* src/controller.h */
#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "common.h"

// process functions for the two intersections
void logic_f10(int r_pipe, int w_pipe_f11, SimData *data);
void logic_f11(int r_pipe, int r_pipe_f10, SimData *data);

#endif