/* src/graphics.c */
#include "graphics.h"
#include "parking.h"
#include <ncurses.h>
#include <string.h>

// keep the lock so threads don't fight over the screen
pthread_mutex_t graphics_lock = PTHREAD_MUTEX_INITIALIZER;

void setup_graphics()
{
    initscr();     // start ncurses mode
    cbreak();      // disable line buffering
    noecho();      // don't show user typing
    curs_set(0);   // hide the blinking cursor
    start_color(); // enable color mode

    // setup our color palette
    // pair_id, foreground, background
    init_pair(1, COLOR_RED, COLOR_BLACK);    // emergency / red light / full
    init_pair(2, COLOR_GREEN, COLOR_BLACK);  // open / green light
    init_pair(3, COLOR_CYAN, COLOR_BLACK);   // borders / ui
    init_pair(4, COLOR_YELLOW, COLOR_BLACK); // cars
    init_pair(5, COLOR_WHITE, COLOR_BLACK);  // normal text
}

// helper to draw a pretty box with ncurses lines
void nc_box(int r, int c, int h, int w)
{
    attron(COLOR_PAIR(3)); // use cyan for borders

    // draw horizontal lines
    mvhline(r, c, 0, w);
    mvhline(r + h - 1, c, 0, w);

    // draw vertical lines
    mvvline(r, c, 0, h);
    mvvline(r, c + w - 1, 0, h);

    // draw corners (ACS = Alternative Character Set)
    mvaddch(r, c, ACS_ULCORNER);
    mvaddch(r, c + w - 1, ACS_URCORNER);
    mvaddch(r + h - 1, c, ACS_LLCORNER);
    mvaddch(r + h - 1, c + w - 1, ACS_LRCORNER);

    attroff(COLOR_PAIR(3));
}

// helper to draw the progress bars
void draw_bar_nc(int r, int c, char *lbl, int cur, int max)
{
    // print label
    mvprintw(r, c, "%-6s: [", lbl); //move to specified (row,col) and print lbl

    // print the bar content
    for (int i = 0; i < 10; i++)
    {
        if (i < cur)
        {
            attron(COLOR_PAIR(4)); // yellow blocks
            addch('#');            // or ACS_BLOCK for solid look
            attroff(COLOR_PAIR(4));
        }
        else
        {
            addch(' ');
        }
    }
    printw("]");
}

// compress queue for display
void compress_q_nc(char *src, char *dst, int max)
{
    int k = 0;
    for (int i = 0; i < max; i++)
    {
        if (src[i] != 0)
            dst[k++] = src[i];
    }
    dst[k] = '\0';
}

void draw_scene(SimData *d, int p0, int q0, int p1, int q1)
{
    pthread_mutex_lock(&graphics_lock);

    erase(); // clear the ncurses virtual buffer

    attron(A_BOLD);
    mvprintw(0, 15, "=== Chandni Chowk Simulator ===");
    attroff(A_BOLD);

    // --- F10 PARKING BOX ---
    nc_box(1, 0, 6, 29);

    // Status Header
    if (d->f10_emerg)
    {
        attron(COLOR_PAIR(1) | A_BLINK); // Blinking Red
        mvprintw(1, 2, " F10 [ EMERGENCY ] ");
        attroff(COLOR_PAIR(1) | A_BLINK);
    }
    else
    {
        attron(COLOR_PAIR(2));
        mvprintw(1, 2, " F10 [  NORMAL   ] ");
        attroff(COLOR_PAIR(2));
    }

    draw_bar_nc(2, 2, "Spots", p0, 10);
    draw_bar_nc(3, 2, "Wait", q0, 5);
    mvprintw(4, 2, "Log: %.18s", d->log_park_f10);
    mvprintw(5, 2, "Rej Count: %d", count_rejected(0));

    // --- F11 PARKING BOX ---
    nc_box(1, 31, 6, 29);

    if (d->f11_emerg)
    {
        attron(COLOR_PAIR(1) | A_BLINK);
        mvprintw(1, 33, " F11 [ EMERGENCY ] ");
        attroff(COLOR_PAIR(1) | A_BLINK);
    }
    else
    {
        attron(COLOR_PAIR(2));
        mvprintw(1, 33, " F11 [  NORMAL   ] ");
        attroff(COLOR_PAIR(2));
    }

    draw_bar_nc(2, 33, "Spots", p1, 10);
    draw_bar_nc(3, 33, "Wait", q1, 5);
    mvprintw(4, 33, "Log: %.18s", d->log_park_f11);
    mvprintw(5, 33, "Rej Count: %d", count_rejected(1));

    // --- TRAFFIC INTERSECTION ---
    nc_box(7, 0, 14, 60);

    // draw roads (white)
    // Horizontal
    mvhline(12, 1, '-', 58);
    mvhline(16, 1, '-', 58);
    // Vertical F10
    mvvline(8, 20, '|', 12);
    mvvline(8, 30, '|', 12);
    // Vertical F11
    mvvline(8, 45, '|', 12);
    mvvline(8, 55, '|', 12);

    // --- LIGHTS F10 ---
    // Vertical
    if (d->light_f10_v == L_GREEN)
        attron(COLOR_PAIR(2) | A_BOLD);
    else
        attron(COLOR_PAIR(1));
    mvprintw(11, 25, "O");
    mvprintw(17, 25, "O");
    attroff(COLOR_PAIR(1) | COLOR_PAIR(2) | A_BOLD);

    // Horizontal
    if (d->light_f10_h == L_GREEN)
        attron(COLOR_PAIR(2) | A_BOLD);
    else
        attron(COLOR_PAIR(1));
    mvprintw(14, 18, "O");
    mvprintw(14, 32, "O");
    attroff(COLOR_PAIR(1) | COLOR_PAIR(2) | A_BOLD);

    mvprintw(14, 24, "F10");

    // --- LIGHTS F11 ---
    // Vertical
    if (d->light_f11_v == L_GREEN)
        attron(COLOR_PAIR(2) | A_BOLD);
    else
        attron(COLOR_PAIR(1));
    mvprintw(11, 50, "O");
    mvprintw(17, 50, "O");
    attroff(COLOR_PAIR(1) | COLOR_PAIR(2) | A_BOLD);

    // Horizontal
    if (d->light_f11_h == L_GREEN)
        attron(COLOR_PAIR(2) | A_BOLD);
    else
        attron(COLOR_PAIR(1));
    mvprintw(14, 43, "O");
    mvprintw(14, 57, "O");
    attroff(COLOR_PAIR(1) | COLOR_PAIR(2) | A_BOLD);

    mvprintw(14, 49, "F11");

    // --- VISUAL QUEUES ---
    attron(COLOR_PAIR(4)); // Cars are Yellow
    char qb[VISUAL_QUEUE_LEN + 1];

    // F10
    compress_q_nc(d->v_queue_f10[DIR_N], qb, VISUAL_QUEUE_LEN);
    for (int i = 0; i < strlen(qb); i++)
        mvaddch(10 - i, 25, qb[i]);

    compress_q_nc(d->v_queue_f10[DIR_S], qb, VISUAL_QUEUE_LEN);
    for (int i = 0; i < strlen(qb); i++)
        mvaddch(18 + i, 25, qb[i]);

    compress_q_nc(d->v_queue_f10[DIR_W], qb, VISUAL_QUEUE_LEN);
    for (int i = 0; i < strlen(qb); i++)
        mvaddch(14, 17 - i, qb[i]);

    compress_q_nc(d->v_queue_f10[DIR_E], qb, VISUAL_QUEUE_LEN);
    for (int i = 0; i < strlen(qb); i++)
        mvaddch(14, 33 + i, qb[i]);

    // F11
    compress_q_nc(d->v_queue_f11[DIR_N], qb, VISUAL_QUEUE_LEN);
    for (int i = 0; i < strlen(qb); i++)
        mvaddch(10 - i, 50, qb[i]);

    compress_q_nc(d->v_queue_f11[DIR_S], qb, VISUAL_QUEUE_LEN);
    for (int i = 0; i < strlen(qb); i++)
        mvaddch(18 + i, 50, qb[i]);
    attroff(COLOR_PAIR(4));

    // --- SYSTEM LOG ---
    nc_box(21, 0, 4, 60);
    attron(COLOR_PAIR(3));
    mvprintw(22, 2, "SYSTEM LOG:");
    attroff(COLOR_PAIR(3));
    mvprintw(23, 2, "%.56s", d->sys_msg);

    refresh(); // Apply changes to actual screen
    pthread_mutex_unlock(&graphics_lock);
}