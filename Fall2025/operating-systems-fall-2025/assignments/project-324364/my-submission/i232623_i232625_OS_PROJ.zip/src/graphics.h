/* src/graphics.h */
#ifndef GRAPHICS_H
#define GRAPHICS_H
#include "common.h"

void setup_graphics();
// p = parked count, q = queue count
void draw_scene(SimData *data, int p0, int q0, int p1, int q1);

#endif