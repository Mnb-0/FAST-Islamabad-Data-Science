/* src/main.c */
#include "common.h"
#include "vehicle.h"
#include "controller.h"
#include "parking.h"
#include "graphics.h"
#include <signal.h>

SimData *g_data;
pid_t pid1, pid2;

// global counter so the signal handler knows how many we made
int g_total_cars = 0;

// pipes for IPC
int p_main_f10[2];
int p_main_f11[2];
int p_f10_f11[2];

// helper to print final stats
void print_report()
{
    printf("\n\n");
    printf("--- FINAL SIMULATION STATS ---\n");

    // get stats from parking.c
    int h0 = get_history_success(0);
    int r0 = count_rejected(0);
    int p0 = get_history_pass(0);

    int h1 = get_history_success(1);
    int r1 = count_rejected(1);
    int p1 = get_history_pass(1);

    int total_processed = h0 + r0 + p0 + h1 + r1 + p1;

    // cars that exist but haven't finished logic yet
    int in_flight = g_total_cars - total_processed;

    printf("Input Data:\n");
    printf("  Total Generated:  %d\n\n", g_total_cars);

    printf("F10 (Node A):\n");
    printf("  Parked (All):     %d\n", h0);
    printf("  Rejected:         %d\n", r0);
    printf("  Pass Through:     %d\n", p0);

    printf("F11 (Node B):\n");
    printf("  Parked (All):     %d\n", h1);
    printf("  Rejected:         %d\n", r1);
    printf("  Pass Through:     %d\n", p1);

    printf("------------------------------\n");
    printf("Balance Sheet:\n");
    printf("  Total Processed:  %d\n", total_processed);
    printf("  Still Active:     %d\n", in_flight);
    printf("  Calculated Sum:   %d\n", total_processed + in_flight);

    if ((total_processed + in_flight) == g_total_cars)
        printf("  Status:           MATCHED\n");
    else
        printf("  Status:           DISCREPANCY\n");

    printf("------------------------------\n");
}

// handle ctrl+c to kill processes
void handle_sig(int signum)
{
    printf("\nstopping sim...\n");

    // kill the kids
    if (pid1 > 0)
        kill(pid1, SIGKILL);
    if (pid2 > 0)
        kill(pid2, SIGKILL);

    endwin(); // end ncurses mode

    // print the report before dying
    print_report();

    // clean up memory
    if (g_data != MAP_FAILED && g_data != NULL)
    {
        munmap(g_data, sizeof(SimData));
    }

    printf("\nstopping sim...\n");
    close_parking();
    exit(0);
}

int main(int argc, char *argv[])
{
    int delay = 500000; // default speed (0.5s)
    int limit = 0;      // 0 = Infinite

    // check args
    if (argc > 1)
        delay = atoi(argv[1]);
    if (argc > 2)
        limit = atoi(argv[2]);

    srand(time(NULL));
    signal(SIGINT, handle_sig);

    // setting up shared mem here
    g_data = mmap(NULL, sizeof(SimData), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (g_data == MAP_FAILED)
    {
        perror("mmap broke");
        exit(1);
    }
    memset(g_data, 0, sizeof(SimData));

    // make pipes
    if (pipe(p_main_f10) == -1 || pipe(p_main_f11) == -1 || pipe(p_f10_f11) == -1)
    {
        perror("pipes failed");
        exit(1);
    }

    setup_parking();
    setup_graphics();

    // fork first controller (F10)
    if ((pid1 = fork()) == 0)
    {
        close(p_main_f10[1]);
        close(p_main_f11[0]);
        close(p_main_f11[1]);
        logic_f10(p_main_f10[0], p_f10_f11[1], g_data);
        exit(0);
    }

    // fork second controller (F11)
    if ((pid2 = fork()) == 0)
    {
        close(p_main_f11[1]);
        close(p_main_f10[0]);
        close(p_main_f10[1]);
        logic_f11(p_main_f11[0], p_f10_f11[0], g_data);
        exit(0);
    }

    // main loop
    while (1)
    {
        // configurable Limit Check
        if (limit > 0 && g_total_cars >= limit)
        {
            // small sleep to let last few threads finish up
            sleep(2);
            handle_sig(0); // clean exit
        }

        draw_scene(g_data, count_parked(0), count_queue(0), count_parked(1), count_queue(1));

        pthread_t t;
        CarThreadArgs *args = malloc(sizeof(CarThreadArgs));
        if (!args)
            continue;

        args->id = g_total_cars++; // increment the global
        args->sim_data = g_data;
        args->start_time = time(NULL);

        // intersection ID
        args->inter_id = rand() % 2; // 0 = F10, 1 = F11
        
        // generate a random vehicle

        int r = rand() % 100;

        // adjust ifs to change probabilities
        if (r < 5)
        {
            args->type = TYPE_FIRETRUCK;
        }
        else if (r < 15)
        {
            args->type = TYPE_AMBULANCE;
        }
        else if (r < 30)
        {
            args->type = TYPE_BUS;
        }
        else if (r < 70)
        {
            args->type = TYPE_CAR;
        }
        else if (r < 85)
        {
            args->type = TYPE_BIKE;
        }
        else
        {
            args->type = TYPE_TRACTOR;
        }

        args->from = rand() % 4;
        args->to = rand() % 4;
        if (args->inter_id == 0)
        {
            args->fd_pipe = p_main_f10[1];
        }
        else
        {
            args->fd_pipe = p_main_f11[1];
        }

        if (pthread_create(&t, NULL, car_logic, args) != 0)
            free(args);
        else
            pthread_detach(t);

        usleep(delay);
    }
    return 0;
}