/* src/parking.c */
#include "parking.h"

// semaphores for spots and waiting queue
sem_t s_spots[2];
sem_t s_queue[2];

// counters
int cnt_parked[2] = {0, 0};     // current occupancy
int cnt_q[2] = {0, 0};          // current line
int cnt_rej[2] = {0, 0};        // total rejections
int cnt_history_ok[2] = {0, 0}; // total happy customers (cumulative)
int cnt_pass[2] = {0, 0};       // total who just drove by

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void setup_parking()
{
    // F10 semaphores
    sem_init(&s_spots[0], 0, 10);
    sem_init(&s_queue[0], 0, 5);

    // F11 semaphores
    sem_init(&s_spots[1], 0, 10);
    sem_init(&s_queue[1], 0, 5);
}

void close_parking()
{
    sem_destroy(&s_spots[0]);
    sem_destroy(&s_queue[0]);
    sem_destroy(&s_spots[1]);
    sem_destroy(&s_queue[1]);
}

void record_pass_through(int lot)
{
    if (lot < 0 || lot > 1)
        return;

    pthread_mutex_lock(&lock);
    cnt_pass[lot]++;
    pthread_mutex_unlock(&lock);
}

int try_park(int vid, int lot)
{
    if (lot < 0 || lot > 1)
        return 0;

    // try to grab a wait ticket (trywait for nonblocking)
    if (sem_trywait(&s_queue[lot]) == 0)
    {
        // get ticket
        pthread_mutex_lock(&lock);
        cnt_q[lot]++;
        pthread_mutex_unlock(&lock);

        // wait for spot
        sem_wait(&s_spots[lot]);

        // got spot, free queue spot
        sem_post(&s_queue[lot]);

        pthread_mutex_lock(&lock);
        cnt_q[lot]--;
        cnt_parked[lot]++;
        cnt_history_ok[lot]++; // mark as a success in history
        pthread_mutex_unlock(&lock);

        return 1; // success
    }

    // queue was full
    pthread_mutex_lock(&lock);
    cnt_rej[lot]++;
    pthread_mutex_unlock(&lock);

    return 0; // failed
}

void exit_parking(int vid, int lot)
{
    if (lot < 0 || lot > 1)
        return;

    pthread_mutex_lock(&lock);
    cnt_parked[lot]--;
    pthread_mutex_unlock(&lock);

    // free up the spot
    sem_post(&s_spots[lot]);
}

// getters
int count_parked(int lot) { return cnt_parked[lot]; }
int count_queue(int lot) { return cnt_q[lot]; }
int count_rejected(int lot) { return cnt_rej[lot]; }
int get_history_success(int lot) { return cnt_history_ok[lot]; }
int get_history_pass(int lot) { return cnt_pass[lot]; }