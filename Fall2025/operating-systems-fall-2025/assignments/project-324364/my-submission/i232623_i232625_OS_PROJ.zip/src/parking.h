/* src/parking.h */
#ifndef PARKING_H
#define PARKING_H
#include "common.h"

// setup functions
void setup_parking();
void close_parking();

// logic for trying to park
// returns 1 if parked, 0 if rejected
int try_park(int vid, int lot_num);
void exit_parking(int vid, int lot_num);

// record a car that didn't want to park
void record_pass_through(int lot_num);

// getters for graphics
int count_parked(int lot_num);
int count_queue(int lot_num);
int count_rejected(int lot_num);

// new getters for the audit report
int get_history_success(int lot_num);
int get_history_pass(int lot_num);

#endif