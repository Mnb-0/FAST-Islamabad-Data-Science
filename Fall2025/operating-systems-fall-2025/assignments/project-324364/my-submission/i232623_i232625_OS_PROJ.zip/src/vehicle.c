/* src/vehicle.c */
#include "vehicle.h"
#include "parking.h"

// get char for vehicle type
char get_symbol(VehicleType t)
{
    switch (t)
    {
    case TYPE_AMBULANCE:
        return 'A';
    case TYPE_FIRETRUCK:
        return 'F';
    case TYPE_BUS:
        return 'B';
    case TYPE_CAR:
        return 'C';
    case TYPE_BIKE:
        return 'M';
    case TYPE_TRACTOR:
        return 'T';
    default:
        return '?';
    }
}

pthread_mutex_t q_lock = PTHREAD_MUTEX_INITIALIZER;

void *car_logic(void *args)
{
    CarThreadArgs *v = (CarThreadArgs *)args;

    // check if emergency
    if (v->type == TYPE_AMBULANCE || v->type == TYPE_FIRETRUCK)
    {
        // send pipe msg
        PipeMsg m = {1, 100, v->from};
        write(v->fd_pipe, &m, sizeof(PipeMsg));

        // emergency vehicles count as pass-throughs
        record_pass_through(v->inter_id);
    }
    else
    {
        // check if we want to park
        int parking = 0;
        int r = rand() % 100;

        if (v->type == TYPE_BUS && r < 10)
            parking = 1;
        else if (v->type != TYPE_BUS && r < 40)
            parking = 1;

        if (parking)
        {
            char *log = (v->inter_id == 0) ? v->sim_data->log_park_f10 : v->sim_data->log_park_f11;

            if (try_park(v->id, v->inter_id))
            {
                sprintf(log, "C-%d: Tkt OK", v->id);
                sleep(2);
                exit_parking(v->id, v->inter_id);
                sprintf(log, "C-%d: Parked", v->id);
            }
            else
            {
                sprintf(log, "C-%d: Rej(Full)", v->id);
            }
        }
        else
        {
            // just driving by, record it
            record_pass_through(v->inter_id);
        }
    }

    // handle intersection crossing
    char *q_ptr;
    if (v->inter_id == 0)
        q_ptr = v->sim_data->v_queue_f10[v->from];
    else
        q_ptr = v->sim_data->v_queue_f11[v->from];

    // put symbol in visual queue
    int slot = -1;
    char sym = get_symbol(v->type);

    pthread_mutex_lock(&q_lock);
    for (int i = 0; i < VISUAL_QUEUE_LEN; i++)
    {
        if (q_ptr[i] == 0)
        {
            q_ptr[i] = sym;
            slot = i;
            break;
        }
    }
    pthread_mutex_unlock(&q_lock);

    int wait = 1;
    while (wait)
    {
        LightState st;
        if (v->inter_id == 0)
        {
            st = (v->from == DIR_N || v->from == DIR_S) ? v->sim_data->light_f10_v : v->sim_data->light_f10_h;
        }
        else
        {
            st = (v->from == DIR_N || v->from == DIR_S) ? v->sim_data->light_f11_v : v->sim_data->light_f11_h;
        }

        if (st == L_GREEN)
            wait = 0;
        else
            usleep(100000);
    }

    if (slot != -1)
    {
        pthread_mutex_lock(&q_lock);
        q_ptr[slot] = 0;
        pthread_mutex_unlock(&q_lock);
    }

    usleep(400000);

    free(v);
    return NULL;
}