/* src/vehicle.h */
#ifndef VEHICLE_H
#define VEHICLE_H
#include "common.h"

// holds all the info for a single car thread
typedef struct
{
    int id;
    VehicleType type;
    int priority;
    Direction from; // origin
    Direction to;   // dest
    time_t start_time;

    SimData *sim_data; // pointer to shared memory
    int fd_pipe;       // pipe to talk to controller

    int inter_id; // 0 is F10, 1 is F11
} CarThreadArgs;

// the main function that runs for each car
void *car_logic(void *args);

#endif