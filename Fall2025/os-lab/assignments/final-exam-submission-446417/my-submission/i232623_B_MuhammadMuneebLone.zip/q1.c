#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

char subworkerNote[] = "Subworker note for Worker ii";

int runningTotal = 0;

int sumMatrix(int **arr)
{
    int size = 2;
    int sum = 0;
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            sum += arr[i][j];
        }
    }
    return sum;
}

int main(int argc, char *argv[])
{
    if (argc <= 0)
    {
        perror("Not enough arguments");
        exit(EXIT_FAILURE);
    }

    int n = atoi(argv[1]);
    if (n < 1)
    {
        perror("Invalid argument");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < n; i++)
    {
        if (i % 2 != 0)
        {
            pid_t pid = fork();
            if (pid < 0)
            {
                perror("Fork failed");
                exit(EXIT_FAILURE);
            }
            else if (pid == 0)
            {
                printf("Mazdoor ID: %d\n", i);

                printf("Mazdoor PID: %d\n", getpid());
                printf("Mazdoor PPID: %d\n", getppid());

                int matrix[2][2];
                char filename[] = "Worker_ii.txt";
                int x = strlen(filename);
                filename[x - 6] = i;
                int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

                for (int j = 0; j < 2; j++)
                {
                    for (int k = 0; k < 2; k++)
                    {
                        matrix[j][k] = i * (j + k);
                        write(fd, &matrix[j][k], sizeof(int));
                        write(fd, " ", sizeof(" "));
                    }
                    write(fd, "\n", sizeof("\n"));
                }

                close(fd);

                int sumMat = sumMatrix(matrix);
                printf("Mazdoor %d: Done\n", i);
                printf("The sum of Mazdoor %d is: %d\n", i, sumMat);
                exit(sumMat);
            }
            else
            {
                runningTotal += WEXITSTATUS(wait(NULL));

                printf("Abba jee Collected Mazdoor: %d\n", i);
            }
        }
        else
        {
            pid_t pid = fork();
            if (pid < 0)
            {
                perror("Fork failed");
                exit(EXIT_FAILURE);
            }
            else if (pid == 0)
            {
                printf("Mazdoor ID: %d\n", i);
                printf("Mazdoor PID: %d\n", getpid());
                printf("Mazdoor PPID: %d\n", getppid());

                int matrix[2][2];
                char filename[] = "Worker_ii.txt";
                int x = strlen(filename);
                filename[x - 6] = i;
                int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

                for (int j = 0; j < 2; j++)
                {
                    for (int k = 0; k < 2; k++)
                    {
                        matrix[j][k] = i * (j + k);
                        write(fd, &matrix[j][k], sizeof(int));
                        write(fd, " ", sizeof(" "));
                    }
                    write(fd, "\n", sizeof("\n"));
                }

                int subworker = fork();
                if (subworker < 0)
                {
                    perror("SubMazdoor Fork Failed");
                    exit(EXIT_FAILURE);
                }
                else if (subworker == 0)
                {
                    printf("SubMazdoor PID: %d\n", getpid());
                    printf("SubMazdoor PPID: %d\n", getppid());
                    printf("Mazdoor Index: %d\n", i);
                    int len = strlen(subworkerNote);
                    subworkerNote[len - 1] = i;
                    write(fd, subworkerNote, len);
                    exit(0);
                }
                wait(NULL);
                close(fd);

                int sumMat = sumMatrix(matrix);
                printf("Mazdoor %d: Done", i);
                printf("The sum of Mazdoor %d is: %d\n", i, sumMat);
                exit(sumMat);
            }
            else
            {
                runningTotal += WEXITSTATUS(wait(NULL));

                printf("Abba jee collected mazdoor: %d\n", i);
            }
        }
    }

    printf("Running Total: %d\n", runningTotal);
    printf("All mazdoor collected alhumdulillah\n");
    return 0;
}