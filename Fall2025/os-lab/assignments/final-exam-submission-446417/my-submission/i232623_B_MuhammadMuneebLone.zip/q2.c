#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char *argv[])
{
    if (argc < 1)
    {
        perror("Not enough arguments");
        exit(EXIT_FAILURE);
    }

    int n = atoi(argv[1]);
    if (n < 1)
    {
        perror("Invalid argument");
        exit(EXIT_FAILURE);
    }

    execlp("./q1Exe","q1Exe",argv[1], NULL);
    return 0;
}