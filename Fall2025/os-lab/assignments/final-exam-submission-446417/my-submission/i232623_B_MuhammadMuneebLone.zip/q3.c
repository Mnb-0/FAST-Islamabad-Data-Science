#include <stdio.h>
#include <stdlib.h>  
#include <unistd.h>  
#include <sys/types.h> 
#include <sys/wait.h>  
#include <sys/stat.h> 
#include <fcntl.h>     
#include <string.h>

int main()
{
    int fd[2];
    int n;
    pipe(fd);
    pid_t pid = fork();
    if(pid<0)
    {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }
    else if(pid > 0)
    {
        printf("Enter a number: ");
        scanf("%d", &n);
        printf("\n");
        close(fd[0]);
        write(fd[1], &n, sizeof(int));
        wait(NULL);
        close(fd[1]);

    }
    else
    {
        close(fd[1]);
        read(fd[0], &n, sizeof(int));
        printf("Recieved: %d\n", n);
        close(fd[0]);
        exit(0);
    }

    return 0;

}