#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <errno.h>
#include <time.h>

#define NUM_TASKS 10

int reqCPU = 1;
int reqMem = 2;
int availCPU = 2;
int availMem = 6;

pthread_cond_t statusCPU = PTHREAD_COND_INITIALIZER; // 0 idle, 1 waiting, 2 in use
pthread_cond_t statusMem = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void *getResources(void *arg)
{
    for (int i = 0; i < NUM_TASKS; i++)
    {
        pthread_mutex_lock(&mutex);
        while (availCPU <= 0)
        {
            pthread_cond_wait(&statusCPU, &mutex);
        }
        while (availMem <= 2)
        {
            pthread_cond_wait(&statusMem, &mutex);
        }

        int analystID = *(int *)arg;
        printf("Analyst %d recieving resources.\n", analystID);
        availCPU -= reqCPU;
        availMem -= reqMem;
        printf("Analyst %d recieved resources.\n", analystID);

        pthread_mutex_unlock(&mutex);

        printf("Sleep to simulate work\n");
        sleep(1);

        pthread_mutex_lock(&mutex);
        printf("Analyst %d leaving resources.\n", analystID);
        availCPU += reqCPU;
        availMem += reqMem;
        printf("Analyst %d left resources.\n", analystID);

        pthread_cond_broadcast(&statusCPU);
        pthread_cond_broadcast(&statusMem);

        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

int main()
{

    pthread_t Analyst1;
    pthread_t Analyst2;
    pthread_t Analyst3;

    int *id1 = malloc(sizeof(int));
    int *id2 = malloc(sizeof(int));
    int *id3 = malloc(sizeof(int));

    *id1 = 1;
    *id2 = 2;
    *id3 = 3;

    pthread_create(&Analyst1, NULL, getResources, id1);
    pthread_create(&Analyst2, NULL, getResources, id2);
    pthread_create(&Analyst3, NULL, getResources, id3);

    pthread_join(Analyst1, NULL);
    pthread_join(Analyst2, NULL);
    pthread_join(Analyst3, NULL);

    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&statusCPU);
    pthread_cond_destroy(&statusMem);

    printf("All done\n");
    return 0;
}