#include <time.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <semaphore.h>

#define LANES 2

#define NUM_CARS 40
#define NUM_EMERGENCY_VEHICLES 5

pthread_mutex_t intersection = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t intersectionOpen = PTHREAD_COND_INITIALIZER; // intersection open or not
int open2 = 0;

void *routine(void *arg)
{
    // as soon as a thread arrives, lock intersection

    pthread_mutex_trylock(&intersection);
    int carID = *(int *)arg;
    char *direction;
    sleep(2);
    while (open2 == 0)
    {
        if (carID > 0 && carID <= 10)
        {
            printf("Car %d from the North is waiting at the intersection \n", carID);
        }
        else if (carID > 10 && carID <= 20)
        {
            printf("Car %d from the South is waiting at the intersection \n", carID);
        }
        else if (carID > 20 && carID < 30)
        {
            printf("Car %d from the East is waiting at the intersection \n", carID);
        }
        else
        {
            printf("Car %d from the West is waiting at the intersection \n", carID);
        }

        pthread_cond_wait(&intersectionOpen, &intersection);
    }
    if (carID > 0 && carID <= 10)
    {
        printf("Car %d has arrived at the intersection from the North\n", carID);
    }
    else if (carID > 10 && carID <= 20)
    {
        printf("Car %d has arrived at the intersection from the South\n", carID);
    }
    else if (carID > 20 && carID < 30)
    {
        printf("Car %d has arrived at the intersection from the East\n", carID);
    }
    else
    {
        printf("Car %d has arrived at the intersection from the West\n", carID);
    }
    pthread_mutex_unlock(&intersection);
    printf("Car %d has left the intersection MashAllah\n", carID);
    sleep(1);
    pthread_mutex_lock(&intersection);
    pthread_cond_broadcast(&intersectionOpen);
    printf("Intersection is now open\n");
    pthread_mutex_unlock(&intersection);

    return NULL;
}

int main()
{

    pthread_t threads[45];
    int thread_args[45];

    for (int i = 0; i < NUM_CARS; i++)
    {
        thread_args[i] = i;
    }
    for (int j = NUM_CARS; j < NUM_EMERGENCY_VEHICLES; j++)
    {
        thread_args[j] = j;
    }

    // car thread creation
    for (int i = 0; i < NUM_CARS; i++)
    {
        pthread_create(&threads[i], NULL, routine, &thread_args[i]);
    }
    for (int j = NUM_CARS; j < NUM_EMERGENCY_VEHICLES; j++)
    {
        pthread_create(&threads[j], NULL, routine, &thread_args[j]);
    }
    /*
    srand(time(NULL));

    int random = rand() % 10;*/

    sem_t north;
    sem_t west;
    sem_t east;
    sem_t south;

    sem_init(&north, 0, LANES);
    sem_init(&west, 0, LANES);
    sem_init(&east, 0, LANES);
    sem_init(&south, 0, LANES);

    for (int i = 0; i < NUM_CARS + NUM_EMERGENCY_VEHICLES; i++)
    {
        pthread_join(threads[i], NULL);
    }

    sem_destroy(&north); // sem(ester) to mera destroy hogya hai
    sem_destroy(&west);
    sem_destroy(&east);
    sem_destroy(&south);

    pthread_mutex_destroy(&intersection);
    pthread_cond_destroy(&intersectionOpen);
}