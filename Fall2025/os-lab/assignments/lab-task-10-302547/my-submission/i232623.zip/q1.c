#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

void *thread_func(void *arg)
{
    pthread_t tid = pthread_self();
    printf("Thread ID: %ld\n", tid);
    sleep(2);
    return NULL;
}

int main()
{
    pthread_t t1, t2;
    pthread_attr_t attr;

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    if (pthread_create(&t1, NULL, thread_func, NULL) != 0)
    {
        perror("Threat creation failed for T1");
        exit(1);
    }

    if (pthread_create(&t2, &attr, thread_func, NULL) != 0)
    {
        perror("Threat creation failed for T2");
        exit(1);
    }

    if (pthread_join(t1, NULL) == 0)
    {
        printf("Joined T1.\n");
    }
    else
    {
        printf("Join failed for T1.\n");
    }

    if (pthread_join(t2, NULL) == 0)
    {
        printf("Joined T2.\n");
    }
    else
    {
        printf("Join failed for T2 (detached).\n");
    }

    pthread_attr_destroy(&attr);

    return 0;
}
