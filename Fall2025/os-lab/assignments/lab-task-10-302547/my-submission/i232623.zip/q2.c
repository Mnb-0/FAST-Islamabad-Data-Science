#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

int arr[20];
int partials[5];
numDivisions = 4;

void *sum(void *arg)
{
    int tIndex = *(int *)arg;
    int start = tIndex * numDivisions;
    int end = start + numDivisions;
    int sum = 0;

    for (int i = start; i < end; i++)
    {
        sum += arr[i];
    }

    partials[tIndex] = sum;
    printf("Thread %d: Partial sum = %d\n", tIndex, sum);
}

int arr_init()
{
    for(int i = 0; i < 20; i++)
    {
        arr[i] = i+1;
        if(i < 5)
        {
            partials[i] = 0;
        }
    }
}

int main()
{
    pthread_t threads[5];
    pthread_attr_t attr;
    int index[5];

    arr_init();

    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    for (int i = 0; i < 5; i++)
    {
        index[i] = i;

        if (i < 2)
        {
            if (pthread_create(&threads[i], NULL, sum, (void *)&index[i]) != 0)
            {
                perror("Joinable thread creation failed");
                exit(1);
            }
        }
        else
        {
            if (pthread_create(&threads[i], &attr, sum, (void *)&index[i]) != 0)
            {
                perror("Detached thread creation failed");
                exit(1);
            }
        }
    }

    for (int i = 0; i < 2; i++)
    {
        if (pthread_join(threads[i], NULL) != 0)
        {
            perror("Failed to join thread");
            exit(1);
        }
        printf("Thread joined %d\n", i);
    }

    int total_sum = 0;

    for (int i = 0; i < 5; i++)
    {
        total_sum += partials[i];
    }

    printf("Total sum: %d\n", total_sum);

    pthread_attr_destroy(&attr);

    return 0;
}
