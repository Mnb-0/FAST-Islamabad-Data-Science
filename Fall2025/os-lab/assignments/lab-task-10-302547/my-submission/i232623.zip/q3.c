#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

typedef struct
{
    int level;
    int maxDepth;
} threadArgument;

void *threadFunction(void *arg)
{
    threadArgument *args = (threadArgument *)arg;
    int level = args->level;
    int maxDepth = args->maxDepth;

    printf("Level %d Thread ID started: %ld\n", level, (long)pthread_self());

    pthread_t childThread;
    threadArgument *childArgs = NULL;

    if (level < maxDepth)
    {
        childArgs = malloc(sizeof(threadArgument));
        childArgs->level = level + 1;
        childArgs->maxDepth = maxDepth;

        pthread_attr_t attr;
        pthread_attr_init(&attr);

        if (level % 2 == 0)
            pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        else
            pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

        if (pthread_create(&childThread, &attr, threadFunction, childArgs) != 0)
        {
            perror("Thread creation failed");
            free(childArgs);
            pthread_attr_destroy(&attr);
            pthread_exit(NULL);
        }

        pthread_attr_destroy(&attr);

        if (level % 2 != 0)
            pthread_join(childThread, NULL);
        else
            // small delay so detached threads can finish execution
            usleep(100000); // 0.1 seconds
    }

    printf("Level %d Thread ID exited: %ld\n", level, (long)pthread_self());
    free(args);
    pthread_exit(NULL);
}

int main()
{
    int depth;
    printf("Enter the maximum depth: ");
    scanf("%d", &depth);

    if (depth < 0)
    {
        depth *= -1;
    }

    pthread_t topThread;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

    threadArgument *args = malloc(sizeof(threadArgument));
    args->level = 1;
    args->maxDepth = depth;

    if (pthread_create(&topThread, &attr, threadFunction, args) != 0)
    {
        perror("Top-level thread creation failed");
        free(args);
        pthread_attr_destroy(&attr);
        return 1;
    }

    pthread_attr_destroy(&attr);

    pthread_join(topThread, NULL);
    return 0;
}