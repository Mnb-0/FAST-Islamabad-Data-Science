#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int counter = 0;
pthread_mutex_t mutex1;

void *increment(void *t)
{
    pthread_mutex_lock(&mutex1);
    for (int i = 0; i < 1000; i++)
    {
        counter++;
    }
    pthread_mutex_unlock(&mutex1);
    printf("%d\n",counter);
    return NULL;
}

int main(void)
{
    if (pthread_mutex_init(&mutex1, NULL) != 0)
    {
        perror("pthread_mutex_init");
        return 1;
    }

    pthread_t t1, t2;
    if (pthread_create(&t1, NULL, increment, NULL) != 0)
    {
        perror("pthread_create");
        return 1;
    }
    if (pthread_create(&t2, NULL, increment, NULL) != 0)
    {
        perror("pthread_create");
        return 1;
    }

    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("Final counter value: %d\n", counter);
    
    pthread_mutex_destroy(&mutex1);
    return 0;
}
