#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int counter = 0;

void *increment(void *t)
{
    for (int i = 0; i < 1000000; i++)
    {
        counter++;
    }
    return NULL;
}

int main(void)
{
    pthread_t t1, t2;
    if (pthread_create(&t1, NULL, increment, NULL) != 0)
    {
        perror("pthread_create");
        return 1;
    }
    if (pthread_create(&t2, NULL, increment, NULL) != 0)
    {
        perror("pthread_create");
        return 1;
    }
    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("Final counter value: %d\n", counter);


    return 0;
}
