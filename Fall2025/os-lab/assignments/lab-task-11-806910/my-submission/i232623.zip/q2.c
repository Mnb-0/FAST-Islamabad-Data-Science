#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

#define N 100

int A[N];
int B[N];
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct
{
    int start;
    int end; // one past the last index
    int tid;
} threadarg;

void *func(void *argp)
{
    threadarg *arg = (threadarg *)argp;
    for (int i = arg->start; i < arg->end; ++i)
    {
        pthread_mutex_lock(&mutex);
        if (i == 0)
        {
            B[i] = (A[0] + A[1]) / 2;
        }
        else if (i == N - 1)
        {
            B[i] = (A[N - 1] + A[N - 2]) / 2;
        }
        else
        {
            B[i] = (A[i - 1] + A[i] + A[i + 1]) / 3;
        }
        A[i] = B[i] * 2;
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

int main(void)
{
    int num_threads = 5;
    srand((unsigned)time(NULL));
    for (int i = 0; i < N; ++i)
    {
        A[i] = rand() % 10;
        B[i] = 0;
    }

    pthread_t threads[num_threads];
    threadarg args[num_threads];
    int seg = N / num_threads;

    for (int t = 0; t < num_threads; ++t)
    {
        args[t].start = t * seg;
        
        if (t == num_threads - 1)
        {
            args[t].end = N;
        }
        else
        {
            args[t].end = args[t].start + seg;
        }

        args[t].tid = t;

        if (pthread_create(&threads[t], NULL, func, &args[t]) != 0)
        {
            perror("pthread_create");
            return 1;
        }
    }

    for (int t = 0; t < num_threads; ++t)
    {
        pthread_join(threads[t], NULL);
    }

    printf("A:\n");
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            printf("%d\t", A[i * 10 + j]);
        }
        printf("\n");
    }
    printf("\nB:\n");
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            printf("%d\t", B[i * 10 + j]);
        }
        printf("\n");
    }

    pthread_mutex_destroy(&mutex);
    return 0;
}