#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

int personCount = 5;
int waterTank = 0;
sem_t tankAccess;
sem_t fillingStation;
void *filter(void *arg)
{
    while (1)
    {
        sleep(1);

        sem_wait(&tankAccess);
        waterTank += 10;
        printf("[FILTER] Added 10L. Tank now: %d L\n", waterTank);
        sem_post(&tankAccess);
    }

    return NULL;
}

void *person(void *arg)
{
    int id = *(int *)arg;

    while (1)
    {
        sem_wait(&fillingStation);

        sem_wait(&tankAccess);

        if (waterTank >= 5)
        {
            waterTank -= 5;
            printf("Person %d took 5L. Tank left: %d L\n", id, waterTank);
        }
        else
        {
            printf("Person %d found insufficient water.\n", id);
        }

        sem_post(&tankAccess);

        sem_post(&fillingStation);

        sleep(1);
    }

    return NULL;
}

int main()
{
    pthread_t filterThread;
    pthread_t personThreads[5];
    int ids[5];

    sem_init(&tankAccess, 0, 1);     // binary semaphore
    sem_init(&fillingStation, 0, 3); // 3-person limit

    pthread_create(&filterThread, NULL, filter, NULL);

    for (int i = 0; i < personCount; i++)
    {
        ids[i] = i + 1;
        pthread_create(&personThreads[i], NULL, person, &ids[i]);
    }

    pthread_join(filterThread, NULL);

    for (int i = 0; i < personCount; i++)
        pthread_join(personThreads[i], NULL);

    sem_destroy(&tankAccess);
    sem_destroy(&fillingStation);

    return 0;
}