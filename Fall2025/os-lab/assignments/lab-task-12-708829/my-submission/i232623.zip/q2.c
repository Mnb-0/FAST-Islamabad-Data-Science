#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t tableSeats;
sem_t printGate;
int sitting = 0;
pthread_mutex_t sitLock = PTHREAD_MUTEX_INITIALIZER;

void *customer(void *arg)
{
    int id = *(int *)arg;
    usleep((rand() % 400) * 1000);

    sem_wait(&printGate);
    printf("Customer %d arrives.\n", id);
    sem_post(&printGate);

    sem_wait(&tableSeats);

    pthread_mutex_lock(&sitLock);
    sitting++;
    int current = sitting;
    pthread_mutex_unlock(&sitLock);

    sem_wait(&printGate);
    printf("Customer %d sits. Now at table: %d\n", id, current);
    sem_post(&printGate);

    //usleep((rand() % 700) * 1000);

    pthread_mutex_lock(&sitLock);
    sitting--;
    current = sitting;
    pthread_mutex_unlock(&sitLock);

    sem_wait(&printGate);
    printf("Customer %d leaves. Now at table: %d\n", id, current);
    sem_post(&printGate);

    sem_post(&tableSeats);
    return NULL;
}

int main()
{
    srand(time(NULL));
    sem_init(&tableSeats, 0, 3);
    sem_init(&printGate, 0, 1);

    pthread_t threads[10];
    int ids[10];

    for (int i = 0; i < 10; i++)
    {
        ids[i] = i + 1;
        pthread_create(&threads[i], NULL, customer, &ids[i]);
    }

    for (int i = 0; i < 10; i++)
        pthread_join(threads[i], NULL);

    return 0;
}