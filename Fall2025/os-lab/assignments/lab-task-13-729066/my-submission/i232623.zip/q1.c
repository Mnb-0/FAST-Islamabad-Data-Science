#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <stdbool.h>
#include <stdint.h>

#define NUM_THREADS 2

pthread_mutex_t balance_mutex;
int iter = 20;
int maxT = 10;
int balance_no_mutex = 10;
int balance_with_mutex = 10;
bool use_mutex = false;
int deposit = 0;

void *perform_transactions(void *arg)
{
    for (int i = 0; i < iter; i++)
    {
        int add = 10;
        int sub = 10;
        

        if (use_mutex)
        {
            pthread_mutex_lock(&balance_mutex);
        }

        if (use_mutex)
        {
            if (deposit < 9)
            {
                balance_with_mutex += add;
                deposit++;
                printf("Thread %ld deposited %d, new balance: %d\n", add, balance_with_mutex);
            }
            else
            {
                if (balance_with_mutex >= sub)
                {
                    deposit++;
                    balance_with_mutex -= sub;
                    printf("Thread %ld withdrew %d, new balance: %d\n", sub, balance_with_mutex);
                }
                else
                {
                    printf("Thread %ld attempted to withdraw %d but insufficient funds, balance remains: %d\n", sub, balance_with_mutex);
                }
            }
        }
        else
        {
            if (deposit < 9)
            {
                balance_no_mutex += add;
                deposit++;
                printf("Thread %ld deposited %d, new balance: %d\n", add, balance_no_mutex);
            }
            else
            {
                if (balance_no_mutex >= sub)
                {
                    deposit++;
                    balance_no_mutex -= sub;
                    printf("Thread %ld withdrew %d, new balance: %d\n", sub, balance_no_mutex);
                }
                else
                {
                    printf("Thread %ld attempted to withdraw %d but insufficient funds, balance remains: %d\n", sub, balance_no_mutex);
                }
            }
        }

        if (use_mutex)
        {
            pthread_mutex_unlock(&balance_mutex);
        }

        usleep(10); // time for transaction
    }
    return NULL;
}

int main()
{
    srand(time(NULL));
    pthread_t threads[NUM_THREADS];

    use_mutex = false;
    printf("Starting transactions without mutex...\n");
    for (long i = 0; i < NUM_THREADS; i++)
    {
        pthread_create(&threads[i], NULL, perform_transactions, (void *)(intptr_t)i);
    }
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    printf("Final balance without mutex: %d\n", balance_no_mutex);

    balance_with_mutex = 10;
    deposit = 0;

    pthread_mutex_init(&balance_mutex, NULL);

    use_mutex = true;
    printf("Starting transactions with mutex...\n");
    for (long i = 0; i < NUM_THREADS; i++)
    {
        pthread_create(&threads[i], NULL, perform_transactions, (void *)(intptr_t)i);
    }
    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }
    printf("Final balance with mutex: %d\n", balance_with_mutex);

    pthread_mutex_destroy(&balance_mutex);

    return 0;
}
