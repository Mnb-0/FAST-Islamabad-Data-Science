#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 100

pthread_mutex_t file_mutex;
char *log_file = "mlog.txt";
void *submit_print_jobs(void *arg)
{
    long thread_id = (long)arg;
    for (int i = 0; i < 5; i++)
    {
        char log_message[50];
        snprintf(log_message, sizeof(log_message), "Thread-%ld scheduling Job-%d\n", thread_id, i + 1);

        pthread_mutex_lock(&file_mutex);

        FILE *file = fopen(log_file, "a");
        if (file != NULL)
        {
            fputs(log_message, file);
            fclose(file);
        }
        else
        {
            perror("Failed to open log file");
        }

        pthread_mutex_unlock(&file_mutex);
    }
    return NULL;
}
int main()
{
    pthread_t threads[NUM_THREADS];
    pthread_mutex_init(&file_mutex, NULL);

    FILE *file = fopen(log_file, "w");
    if (file != NULL)
    {
        fclose(file);
    }

    for (long i = 0; i < NUM_THREADS; i++)
    {
        pthread_create(&threads[i], NULL, submit_print_jobs, (void *)i);
    }

    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&file_mutex);
    return 0;
}