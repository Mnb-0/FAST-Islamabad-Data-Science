#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_THREADS 100

char *log_file = "nmlog.txt";
void *submit_print_jobs(void *arg)
{
    long thread_id = (long)arg;
    char log_message[50];
    char buffer[100];

    FILE *file = fopen(log_file, "a");
    if (file != NULL)
    {
        printf( "Thread-%ld thread", pthread_self());
        printf( "Job %d\n", 1);
        fclose(file);
    }
    else
    {
        perror("Failed to open log file");
    }
    return NULL;
}
int main()
{
    pthread_t threads[NUM_THREADS];

    FILE *file = fopen(log_file, "w");
    if (file != NULL)
    {
        fclose(file);
    }

    for (long i = 0; i < NUM_THREADS; i++)
    {
        pthread_create(&threads[i], NULL, submit_print_jobs, (void *)i);
    }

    for (int i = 0; i < NUM_THREADS; i++)
    {
        pthread_join(threads[i], NULL);
    }

    return 0;
}