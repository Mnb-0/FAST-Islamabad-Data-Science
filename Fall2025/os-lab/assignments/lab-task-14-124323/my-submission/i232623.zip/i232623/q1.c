#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX_IN_ROOM 5
#define TOTAL_STUDENTS 20
#define TOTAL_GROUPS 5
#define STUDENTS_PER_GROUP (TOTAL_STUDENTS / TOTAL_GROUPS)

sem_t room_sem;
sem_t group_sems[TOTAL_GROUPS];
pthread_mutex_t mutex;
int students_in_room = 0;

typedef struct
{
    int id;
    int group_id;

} student_t;

void *student_demo(void *arg)
{
    student_t *student = (student_t *)arg;

    sem_wait(&room_sem);

    pthread_mutex_lock(&mutex);
    pthread_mutex_unlock(&mutex);
    sem_wait(&group_sems[student->group_id]);
    pthread_mutex_lock(&mutex);
    students_in_room++;
    pthread_mutex_unlock(&mutex);

    printf("Student with ID %d from Group %d is giving demo.\n", student->id, student->group_id);
    sleep(1);

    pthread_mutex_lock(&mutex);
    students_in_room--;

    sem_post(&group_sems[student->group_id]);
    pthread_mutex_unlock(&mutex);

    sem_post(&room_sem);
    printf("Student with ID %d from Group %d has left the demo room.\n", student->id, student->group_id);
    free(student);
}

int main()
{
    pthread_t students[TOTAL_STUDENTS];
    sem_init(&room_sem, 0, MAX_IN_ROOM);
    pthread_mutex_init(&mutex, NULL);
    for (int i = 0; i < TOTAL_GROUPS; i++)
    {
        sem_init(&group_sems[i], 0, 1);
    }

    for (int i = 0; i < TOTAL_STUDENTS; i++)
    {
        student_t *student = (student_t *)malloc(sizeof(student_t));
        student->id = i + 1;
        student->group_id = i / STUDENTS_PER_GROUP;
        pthread_create(&students[i], NULL, student_demo, (void *)student);
    }

    for (int i = 0; i < TOTAL_STUDENTS; i++)
    {
        pthread_join(students[i], NULL);
    }

    sem_destroy(&room_sem);
    for (int i = 0; i < TOTAL_GROUPS; i++)
    {
        sem_destroy(&group_sems[i]);
    }
    pthread_mutex_destroy(&mutex);
    return 0;
}