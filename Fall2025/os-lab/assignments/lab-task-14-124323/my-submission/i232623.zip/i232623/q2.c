#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <semaphore.h>

#define MAX_PASSENGERS 5
#define TOTAL_PASSENGERS 15
#define BOARDING_TIME 2
#define ELEVATOR_CYCLE_TIME 5

sem_t capacity;
sem_t boarding;
sem_t done;
pthread_mutex_t mutex;
int passengers_in_elevator = 0;
bool boarding_open = false;

void *passenger(void *arg)
{
    int id = *((int *)arg);
    free(arg);

    sleep(rand() % 5 + 1);

    pthread_mutex_lock(&mutex);
    printf("Passenger %d has arrived at the ground floor.\n", id);
    pthread_mutex_unlock(&mutex);

    sem_wait(&boarding);

    sem_wait(&capacity);

    pthread_mutex_lock(&mutex);
    passengers_in_elevator++;
    printf("Passenger %d has boarded the elevator. Current passengers: %d\n", id, passengers_in_elevator);
    pthread_mutex_unlock(&mutex);

    sem_post(&boarding);

    sem_wait(&done);

    pthread_mutex_lock(&mutex);
    printf("Passenger %d exited at Floor 1.\n", id);
    passengers_in_elevator--;
    pthread_mutex_unlock(&mutex);

    sem_post(&capacity);

    return NULL;
}

void *elevator(void *arg)
{
    while (true)
    {
       
        boarding_open = false;
        for (int i = 0; i < MAX_PASSENGERS; i++)
        {
            sem_wait(&boarding);
        }

        pthread_mutex_lock(&mutex);
        printf("Elevator leaving the ground floor with %d passengers.\n", passengers_in_elevator);
        pthread_mutex_unlock(&mutex);

        sleep(ELEVATOR_CYCLE_TIME / 2);

        pthread_mutex_lock(&mutex);
        printf("Elevator arrived at Floor 1.\n");
        pthread_mutex_unlock(&mutex);

        for (int i = 0; i < passengers_in_elevator; i++)
        {
            sem_post(&done);
        }

        sleep(ELEVATOR_CYCLE_TIME / 2);
    }
    return NULL;
}
