#include <time.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h> 
#include <signal.h>
#include <ncurses.h>
#include <pthread.h>
#include <sys/types.h>

// run using gcc -o i232623 i232623_Lab15.c -lpthread -lncurses


typedef struct
{
    int elapsedSeconds;
    int isRunning;
} StopwatchState;

// globals

pthread_mutex_t timeDataMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t stopwatchMutex = PTHREAD_MUTEX_INITIALIZER;

int alarmPipe[2];
sig_atomic_t alarmTriggered = 0; // uninterruptible

char currentTimeStr[50] = "--:--:--";
char lastSystemMessage[100] = "Ready.";

StopwatchState myStopwatch = {0, 0};
int countdownValue = 0;

// protos
void signalHandle(int sig);
void *liveClock(void *arg);
void *stopwatch(void *arg);
void *countdown(void *arg);
void updateMsg(const char *msg);
void alarmMonitor(int readPipeFD, pid_t parentPID);

int main()
{
    // ipc and signal setup
    if (pipe(alarmPipe) == -1)
    {
        perror("Pipe failed");
        return 1;
    }

    signal(SIGUSR1, signalHandle);

    pid_t pid = fork();
    if (pid == 0)
    {
        close(alarmPipe[1]);
        alarmMonitor(alarmPipe[0], getppid());
        exit(0);
    }

    // parent with ncurses setup
    close(alarmPipe[0]);

    initscr();
    cbreak();
    noecho();
    nodelay(stdscr, TRUE);
    curs_set(0);

    // start threads
    pthread_t clockThread, stopwatchThread;
    pthread_create(&clockThread, NULL, liveClock, NULL);
    pthread_create(&stopwatchThread, NULL, stopwatch, NULL);

    int ch;
    int alarmDisplayTimer = 0;

    // render loop
    while (1) // busy wait :(
    {
        ch = getch();
        if (ch != ERR)
        {
            if (ch == 'q') // quit
                break;

            if (ch == 's') // start stopwatch
            {
                pthread_mutex_lock(&stopwatchMutex);
                myStopwatch.isRunning = 1;
                pthread_mutex_unlock(&stopwatchMutex);
                updateMsg("Stopwatch: Running");
            }
            if (ch == 'p') // pause stopwatch
            {
                pthread_mutex_lock(&stopwatchMutex);
                myStopwatch.isRunning = 0;
                pthread_mutex_unlock(&stopwatchMutex);
                updateMsg("Stopwatch: Paused");
            }
            if (ch == 'r') // reset stopwatch
            {
                pthread_mutex_lock(&stopwatchMutex);
                myStopwatch.isRunning = 0;
                myStopwatch.elapsedSeconds = 0;
                pthread_mutex_unlock(&stopwatchMutex);
                updateMsg("Stopwatch: Reset");
            }
            if (ch == 'a') // alarm
            {
                updateMsg("> Enter Alarm Seconds: ");
                echo();
                nodelay(stdscr, FALSE);
                curs_set(1);

                mvprintw(10, 2, "Set Alarm (Seconds):      ");
                move(10, 23);
                int seconds;
                scanw("%d", &seconds);
                write(alarmPipe[1], &seconds, sizeof(seconds));

                noecho();
                nodelay(stdscr, TRUE);
                curs_set(0);
                updateMsg("Alarm Set.");
            }
            if (ch == 'c') // countdown start
            {
                updateMsg("> Enter Countdown: ");
                echo();
                nodelay(stdscr, FALSE);
                curs_set(1);

                mvprintw(10, 2, "Set Countdown (Seconds):  ");
                move(10, 27);
                int *startVal = malloc(sizeof(int));
                scanw("%d", startVal);

                pthread_t cdThread;
                pthread_create(&cdThread, NULL, countdown, startVal);
                pthread_detach(cdThread);

                noecho();
                nodelay(stdscr, TRUE);
                curs_set(0);
                updateMsg("Countdown Started.");
            }
        }

        // data read-safe

        char safeTime[50];
        pthread_mutex_lock(&timeDataMutex);
        strcpy(safeTime, currentTimeStr);
        pthread_mutex_unlock(&timeDataMutex);

        int swSecs;
        pthread_mutex_lock(&stopwatchMutex);
        swSecs = myStopwatch.elapsedSeconds;
        pthread_mutex_unlock(&stopwatchMutex);

        clear();

        // big clock
        attron(A_BOLD);
        mvprintw(1, 2, "%s", safeTime);
        attroff(A_BOLD);

        // stopwatch and countdown

        mvprintw(3, 2, "Stopwatch: %ds", swSecs);

        if (countdownValue > 0)
            mvprintw(4, 2, "Countdown: %d", countdownValue);
        else
            mvprintw(4, 2, "Countdown: --");

        // alarm display
        if (alarmTriggered)
        {
            alarmDisplayTimer = 80; // 4 seconds
            alarmTriggered = 0;
        }

        if (alarmDisplayTimer > 0)
        {
            attron(A_REVERSE | A_BOLD); // black text on white background
            mvprintw(6, 2, " ! ALARM RINGING ! ");
            attroff(A_REVERSE | A_BOLD);
            alarmDisplayTimer--;
        }
        else
        {
            mvprintw(6, 2, "[%s]", lastSystemMessage);
        }

        mvprintw(8, 2, "s:Start p:Pause r:Reset a:Alarm c:Count q:Quit");

        refresh();
        usleep(50000); // freecpu
    }

    endwin();
    kill(pid, SIGTERM);
    return 0;
}

void *liveClock(void *arg)
{
    while (1)
    {
        time_t rawtime;
        struct tm *timeinfo;
        time(&rawtime); // curr time
        timeinfo = localtime(&rawtime);
        pthread_mutex_lock(&timeDataMutex);
        strftime(currentTimeStr, 50, "%I:%M:%S %p", timeinfo); // format time
        pthread_mutex_unlock(&timeDataMutex);
        sleep(1);
    }
    return NULL;
}

void *stopwatch(void *arg)
{
    while (1)
    {
        pthread_mutex_lock(&stopwatchMutex);
        if (myStopwatch.isRunning)
        {
            myStopwatch.elapsedSeconds++;
        }
        pthread_mutex_unlock(&stopwatchMutex);
        sleep(1);
    }
    return NULL;
}

void *countdown(void *arg)
{
    int count = *((int *)arg);
    free(arg);
    while (count > 0)
    {
        countdownValue = count;
        count--;
        sleep(1);
    }
    countdownValue = 0;
    updateMsg("Countdown Finished.");
    return NULL;
}

void alarmMonitor(int readPipeFD, pid_t parentPID)
{
    // set non-blocking so read() returns -1 immediately if empty
    fcntl(readPipeFD, F_SETFL, O_NONBLOCK);

    time_t alarms[20];
    int alarmCount = 0;

    while (1)
    {
        int secondsDelay;
        // if > 0 then data present
        if (read(readPipeFD, &secondsDelay, sizeof(secondsDelay)) > 0)
        {
            alarms[alarmCount++] = time(NULL) + secondsDelay;
        }

        time_t now = time(NULL);
        for (int i = 0; i < alarmCount; i++)
        {
            if (alarms[i] != 0 && now >= alarms[i])
            {
                kill(parentPID, SIGUSR1);
                alarms[i] = 0;
            }
        }
        sleep(1); // freecpu
    }
}

void signalHandle(int sig)
{
    if (sig == SIGUSR1)
    {
        alarmTriggered = 1;
    }
}

void updateMsg(const char *msg)
{
    strncpy(lastSystemMessage, msg, 99);
}