# !/bin/bash
#------------------Q1------------------
touch notes.txt
ls -l
echo "Dummy content" > notes.txt
chmod 700 notes.txt
ls -l