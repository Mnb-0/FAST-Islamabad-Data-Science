# !/bin/bash
#------------------Q2------------------
touch backup.txt
ls -l
chmod go-w backup.txt
ls -l