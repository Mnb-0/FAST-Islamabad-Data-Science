#!/bin/bash
#-----------------Q5----------------------
read -p "Enter consumed units: " units
if [ "$units" -le 300 ]; then
    cost=$(( units * 2 ))
elif [ "$units" -gt 200 ] && [ "$units" -le 500 ]; then
    cost=$(( units * 5 ))
elif [ "$units" -gt 500 ]; then
    cost=$(( units * 7 ))
else
    echo "Invalid input."
    exit 1
fi

echo "Total electricity bill for $units units is Rs. $cost"