#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    __pid_t pid1, pid2;

    pid1 = fork();

    if(pid1 < 0)
    {
        perror("Error!");
        return 1;
    }

    if (pid1==0)
    {
        printf("Child 1 (p1) created with PID: %d, Parent PID: %d\n", getpid(), getppid());
        pid2 = fork();
        if(pid2 < 0)
        {
            perror("Error!");
        }
        if (pid2 == 0)
        {
            printf("Child 2 (p2) created with PID: %d, Parent PID: %d\n", getpid(), getppid());
        }
    }

    return 0;
}