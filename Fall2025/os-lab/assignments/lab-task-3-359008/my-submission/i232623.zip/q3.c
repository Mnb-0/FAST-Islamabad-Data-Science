#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int isPrime(int n)
{
    if (n<1)
    {
        return 0;
    }

    for(int i = 2; i * i <= n; i++)
    {
        if(n%i == 0)
        {
            return 0;
        }
    }
    return 1;
}

int sumDigits(int n)
{
    int sum =0;
    while(n>0)
    {
        sum+= n%10;
        n/=10;
    }
    return sum;
}


int main()
{
    int flag;
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);

    pid_t pid = fork();

    if(pid < 0)
    {
        perror("Error forking");
        return 1;
    }
    else if (pid > 0)
    {
        if(isPrime(number))
        {
            printf("Is Prime \n");
        }
        else
        {
            printf("Not prime \n");
        }
    }
    else
    {
        printf("Sum: %d \n", sumDigits(number));
    }
}