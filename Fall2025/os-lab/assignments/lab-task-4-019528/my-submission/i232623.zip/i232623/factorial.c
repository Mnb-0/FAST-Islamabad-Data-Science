#include <stdio.h>
#include <stdlib.h>

int factorial(int n)
{
    if (n <= 1)
    {
        return 1;
    }
    else
    {
        return n * factorial(n - 1);
    }
}

int main(int argc, char* argv[])
{
    if (argc != 2)
    {
        printf("Invalid argument count\n");
        return 1;
    }

    int num = atoi(argv[1]);
    if (num < 0)
    {
        printf("Factorial undefined for negative numbers\n");
        return 1;
    }

    printf("Factorial of %d is %d\n", num, factorial(num));
    return 0;
}
