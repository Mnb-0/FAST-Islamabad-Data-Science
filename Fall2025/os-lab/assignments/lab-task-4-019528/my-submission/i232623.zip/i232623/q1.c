#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid = fork();
    char* argArr[] = {"echo", "Hello", "from", "execv", NULL};
    if (pid == 0)
    {
        execv("/bin/echo", argArr);

        perror("execv failed");
        return 1;
    }
    if (pid > 0)
    {
        wait(NULL);
    }

    return 0;

}