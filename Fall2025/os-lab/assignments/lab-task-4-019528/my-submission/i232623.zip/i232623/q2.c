#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("Fork failed");
        exit(1);
    }
    else if (pid > 0)
    {
        wait(NULL);
        return 1;
    }
    else
    {
        char* argArr[] = {"FIRST_NAME=Muneeb", "LAST_NAME=Lone",NULL};

        execle("/usr/bin/env","env", NULL, argArr);

        perror("execle failed");
        return 1;
    }
    return 0;
}