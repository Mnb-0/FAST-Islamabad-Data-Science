#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{   
    int num;
    char str[128];

    printf("Enter number for factorial: ");
    scanf("%d", &num);

    printf("Enter a string for reversing: ");
    scanf("%s", str);

    pid_t pid1 = fork();

    if(pid1 == 0)
    {
        char numStr[10];
        sprintf(numStr, "%d", num);
        char* factorialArgs[] = {"factorial", numStr, NULL};
        execv("./factorial", factorialArgs);
        perror("execv failed for factorial");
        exit(1);
    }
    
    pid_t pid2 = fork();
    if (pid2 == 0)
    {
        char *reverseArgs[] = {"reverseString", str, NULL};
        execv("./reverseString", reverseArgs);
        perror("execv failed for reverseString");
        exit(1);
    }

    wait(NULL);  // Wait for first child (factorial)
    wait(NULL);  // Wait for second child (reverseString)

    return 0;
}
