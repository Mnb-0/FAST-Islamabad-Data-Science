#include <stdio.h>
#include <string.h>

void reverse(char str[])
{
    int len = strlen(str);
    for (int i = 0; i < len / 2; i++) 
    {
        char temp = str[i];
        str[i] = str[len - 1 - i];
        str[len - 1 - i] = temp;
    }
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Invalid argument count\n");
        return 1;
    }

    char str[128];
    strncpy(str, argv[1], 128); 

    reverse(str);
    printf("Reversed String: %s\n", str); 

    return 0;
}
