#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
    pid_t pid;
    int fd[2];
    int num;
    printf("Enter number to check:\n");
    scanf("%d", &num);
    if (pipe(fd) < 0)
    {
        perror("Pipe creation failed\n");
        exit(1);
    }

    pid = fork();
    if (pid == -1)
    {
        perror("Error in fork");
        exit(1);
    }
    else if (pid > 0)
    {
        close(fd[0]); // close parent read
        printf("Parent writing to pipe\n");

        write(fd[1], &num, sizeof(num));
        printf("Parent finished writing\n");
        wait(NULL);
        exit(0);
    }
    else
    {
        close(fd[1]); // close child write
        printf("Child Reading from pipe\n");
        read(fd[0], &num, sizeof(num));
        printf("Child finished reading\n");
        if (num % 2 == 0)
        {
            printf("Even\n");
            exit(0);
        }
        else
        {
            printf("Odd\n");
            exit(0);
        }
    }
    return 0;
}