#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <time.h>

int main(int argc, char *argv[])
{
    srand(time(NULL));
    int fd[2];
    int num;
    int sum = 0;
    printf("Enter a number n:\n");
    scanf("%d", &num);

    if (pipe(fd) < 0)
    {
        perror("Pipe creation failed\n");
        exit(1);
    }

    for (int i = 0; i < num; i++) //write loop
    {
        pid_t pid = fork();
        if (pid < 0)
        {
            perror("Error in fork");
            exit(1);
        }
        if (pid == 0)
        {
            srand(time(NULL));
            int r = (rand() % 6) + 1;
            printf("Random number: %d \n", r);
            close(fd[0]);
            write(fd[1], &r, sizeof(r));
            close(fd[1]);
            exit(0);
        }
    }

    close(fd[1]);
    for (int i = 0; i < num; i++) //read loop
    {
        int r;
        read(fd[0], &r, sizeof(r));
        sum += r;
        wait(NULL);
    }
    close(fd[0]);

    printf("\nSum of random numbers: %d\n", sum);

    return 0;
}