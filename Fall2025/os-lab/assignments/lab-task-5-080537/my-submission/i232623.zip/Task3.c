#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
    char childMessageR[1024];  // message received by child
    char parentMessageR[1024]; // message received by parent
    char childMessageS[1024];
    char parentMessageS[1024];

    int fd1[2]; // parent reads, child writes
    int fd2[2]; // child reads, parent writes

    if (pipe(fd1) == -1 || pipe(fd2) == -1)
    {
        perror("Pipe creation error\n");
        exit(1);
    }
    pid_t pid = fork();
    if (pid < 0)
    {
        perror("Fork failed\n");
        exit(1);
    }
    while (1)
    {
        if (pid > 0)
        {
            close(fd1[1]);
            close(fd2[0]);
            printf("Write a message to send to child:\n");
            scanf("%s", parentMessageS);
            write(fd2[1], parentMessageS, strlen(parentMessageS) + 1);
            read(fd1[0], parentMessageR, sizeof(parentMessageR));
            printf("Message from child: %s\n", parentMessageR);
            if (strcmp(parentMessageR, "exit") == 0 || strcmp(parentMessageR, "EXIT") == 0)
            {
                printf("End convo\n");
                wait(NULL);
                exit(0);
            }
        }
        if (pid == 0)
        {
            close(fd2[1]);
            close(fd1[0]);
            printf("Write a message to send to parent:\n");
            scanf("%s", childMessageS);
            write(fd1[1], childMessageS, strlen(childMessageS) + 1);
            read(fd2[0], childMessageR, sizeof(childMessageR));
            printf("Message from parent: %s\n", childMessageR);
            if (strcmp(childMessageR, "exit") == 0 || strcmp(childMessageR, "EXIT") == 0)
            {
                printf("End convo\n");
                exit(0);
            }
        }
    }
    return 0;
}