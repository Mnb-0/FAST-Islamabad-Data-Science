#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
int main()
{
    // Create the named pipes (PipeA and PipeB)
    if (mkfifo("PipeA", 0666) < 0 && errno != EEXIST)
    {
        perror("PipeA creation failed");
        exit(1);
    }
    if (mkfifo("PipeB", 0666) < 0 && errno != EEXIST)
    {
        perror("PipeB creation failed");
        exit(1);
    }

    char str[256];
    printf("Enter a string to convert to ASCII: \n");
    fgets(str, sizeof(str), stdin); // Using fgets for safe input
    str[strcspn(str, "\n")] = 0;    // Remove newline character from input

    // Open PipeA for writing
    int fifo_write = open("PipeA", O_WRONLY);
    if (fifo_write < 0)
    {
        perror("Error opening PipeA for writing");
        exit(1);
    }

    // Write input string to PipeA
    write(fifo_write, str, strlen(str) + 1);
    close(fifo_write); // Close after writing

    return 0;
}
