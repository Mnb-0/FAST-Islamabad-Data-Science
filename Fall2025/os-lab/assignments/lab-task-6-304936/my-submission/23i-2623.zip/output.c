#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    char str[1024]; // Ensure large enough buffer to hold the ASCII string

    // Open PipeB for reading
    int fifo_read = open("PipeB", O_RDONLY);
    if (fifo_read < 0)
    {
        perror("Error opening PipeB for reading");
        exit(1);
    }

    ssize_t bytes_read = read(fifo_read, str, sizeof(str) - 1);
    if (bytes_read > 0)
    {
        str[bytes_read] = '\0'; // Null terminate the string

        // Print the received ASCII values correctly as a string
        printf("Received ASCII values (string): %s\n", str);

        // Now we want to print the actual numbers (the ASCII values), not as characters
        printf("Converted ASCII values: \n");

        // Here we are printing the raw ASCII values as integers, not as characters
        int i = 0;
        while (i < bytes_read)
        {
            // Print numbers (ASCII values), separated by spaces
            int num;
            if (sscanf(str + i, "%d", &num) == 1)
            {
                printf("%d ", num);
                // Find the next space after the number
                while (i < bytes_read && str[i] != ' ') {
                    i++;
                }
            }
            i++;
        }
        printf("\n");
    }
    else
    {
        perror("Error reading from PipeB");
    }

    close(fifo_read);

    return 0;
}