#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    char str[256];

    // Open PipeA for reading
    int fifo_read = open("PipeA", O_RDONLY);
    if (fifo_read < 0)
    {
        perror("Error opening PipeA for reading");
        exit(1);
    }

    ssize_t bytes_read = read(fifo_read, str, sizeof(str) - 1);
    if (bytes_read > 0)
    {
        str[bytes_read] = '\0'; // Null terminate the string
        printf("Received text: %s\n", str);

        char ascii_str[1024] = {0};
        int offset = 0;
        for (int i = 0; i < bytes_read; i++)
        {
            offset += snprintf(ascii_str + offset, sizeof(ascii_str) - offset, "%d ", (unsigned char)str[i]);
        }

        printf("ASCII string: %s\n", ascii_str);
        ascii_str[strlen(ascii_str)] = '\0';

        // Open PipeB for writing
        int fifo_write = open("PipeB", O_WRONLY);
        if (fifo_write < 0)
        {
            perror("Error opening PipeB for writing");
            close(fifo_read);
            exit(1);
        }

        write(fifo_write, ascii_str, strlen(ascii_str) + 1);
        close(fifo_write);
    }
    else
    {
        perror("Error reading from PipeA");
    }

    close(fifo_read);

    return 0;
}