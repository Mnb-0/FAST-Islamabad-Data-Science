#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define BUFFER_SIZE 256

int main()
{
    char message[BUFFER_SIZE];
    int fifo_a, fifo_b;

    if (mkfifo("PipeC", 0666) < 0) {
        perror("Error creating PipeA");
        exit(1);
    }
    if (mkfifo("PipeD", 0666) < 0) {
        perror("Error creating PipeB");
        exit(1);
    }

    fifo_a = open("PipeC", O_WRONLY);
    if (fifo_a < 0) {
        perror("Error opening PipeA for writing");
        exit(1);
    }

    fifo_b = open("PipeD", O_RDONLY);
    if (fifo_b < 0) {
        perror("Error opening PipeB for reading");
        exit(1);
    }

    while (1) {
        printf("Process A: Enter message (or type 'exit' to quit): ");
        fgets(message, sizeof(message), stdin);
        message[strcspn(message, "\n")] = 0;
        write(fifo_a, message, strlen(message) + 1);

        if (strcmp(message, "exit") == 0) {
            break;
        }

        read(fifo_b, message, sizeof(message));
        printf("Process A received: %s\n", message);
    }

    // Close the FIFOs
    close(fifo_a);
    close(fifo_b);

    unlink("PipeC");
    unlink("PipeD");

    return 0;
}
