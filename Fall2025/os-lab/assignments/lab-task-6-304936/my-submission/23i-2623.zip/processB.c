#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#define BUFFER_SIZE 256

int main()
{
    char message[BUFFER_SIZE];
    int fifo_a, fifo_b;

    if (mkfifo("PipeC", 0666) < 0 && errno != EEXIST) {
        perror("Error creating PipeC");
        exit(1);
    }
    if (mkfifo("PipeD", 0666) < 0 && errno != EEXIST) {
        perror("Error creating PipeD");
        exit(1);
    }

    // Open PipeC for reading (from A to B)
    fifo_a = open("PipeC", O_RDONLY);
    if (fifo_a < 0) {
        perror("Error opening PipeC for reading");
        exit(1);
    }

    // Open PipeD for writing (from B to A)
    fifo_b = open("PipeD", O_WRONLY);
    if (fifo_b < 0) {
        perror("Error opening PipeD for writing");
        exit(1);
    }

    while (1) {
        read(fifo_a, message, sizeof(message));
        printf("Process B received: %s\n", message);

        if (strcmp(message, "exit") == 0) {
            break;
        }

        printf("Process B: Enter reply (or type 'exit' to quit): ");
        fgets(message, sizeof(message), stdin);
        message[strcspn(message, "\n")] = 0;
        write(fifo_b, message, strlen(message) + 1);

        if (strcmp(message, "exit") == 0) {
            break;
        }
    }

    // Close the FIFOs
    close(fifo_a);
    close(fifo_b);

    // Unlink the FIFOs
    unlink("PipeC");
    unlink("PipeD");

    return 0;
}
