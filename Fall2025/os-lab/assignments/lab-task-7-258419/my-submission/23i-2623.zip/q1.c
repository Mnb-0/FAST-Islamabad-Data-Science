#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

void myHandler(int signum)
{
    printf("Exit signal recieved\n");
}

int main()
{
    signal(SIGINT, myHandler);
    signal(SIGTSTP, myHandler);

    while(1)
    {
        printf("%d\n", getpid());
        sleep(2);
    }

    return 0;
}