#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

void myHandler(int signum)
{
    printf("Got SIGUSR1\n");
    return;
}

//sigusr1 == 10
int main(int argc, int argv[])
{
    //kill -SIGUSR1 getpid();
    signal(SIGUSR1,myHandler);
    printf("PID:%d\n", getpid());
    printf("Waiting for a signal...\n");
    pause();
    return 0;
}