#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/sysinfo.h>
#include <errno.h>

long int temp = 0;
pid_t childPid = -1;
long get_uptime()
{
    struct sysinfo s_info;
    int error = sysinfo(&s_info);
    if (error != 0)
    {
        printf("code error = %d\n", error);
    }
    return s_info.uptime;
}

void gracefullExit(int signum)
{
    printf("SIGTERM Recieved, cleaning and exiting\n");
    if(childPid>0)
    {
        kill(childPid, SIGTERM);
    }
    exit(0);
}

void alarmHandler(int signum)
{
    kill(getpid(),SIGUSR1);
}

void printStats(int signum)
{
    printf("Server Stats: uptime = %ld seconds\n", get_uptime() - temp);
    return;
}

int main()
{
    temp = get_uptime();
    signal(SIGTERM, gracefullExit);
    signal(SIGUSR1, printStats);
    signal(SIGALRM, alarmHandler);
    pid_t pid = fork();
    if (pid < 0)
    {
        perror("Forking failed\n");
        exit(1);
    }
    else if (pid == 0)
    {
        printf("Child Process ID:%d\n", getpid());
        childPid = getpid();
        while (1)
        {
            printf("Server Running....\n");
            sleep(2);
        }
    }
    else
    {
        printf("Parent Process ID:%d\n", getpid());
        while(1)
        {
            alarm(5);
            pause();
        }
    }

    return 0;
}