#include <stdio.h>
#include <unistd.h>

typedef struct
{
    int id;
    int arrival;
    int burst;
    int complete;
} Process;

void printGantt(Process p[], int n)
{
    printf("\nGantt Chart:\n|");
    for (int i = 0; i < n; ++i)
    {
        printf(" P%d |", p[i].id);
    }
    printf("\n0");
    for (int i = 0; i < n; ++i)
    {
        printf("    %d", p[i].complete);
    }
    printf("\n");
}

void fcfs(Process p[], int n)
{
    int time = 0;
    for (int i = 0; i < n; ++i)
    {
        if (time < p[i].arrival)
            time = p[i].arrival;

        time += p[i].burst;
        p[i].complete = time;
    }

    printGantt(p, n);
}

int main()
{
    const int n = 4;
    Process p[4] = {
        {1, 0, 5, 0},
        {2, 2, 3, 0},
        {3, 4, 8, 0},
        {4, 6, 6, 0}};

    fcfs(p, n);

    return 0;
}