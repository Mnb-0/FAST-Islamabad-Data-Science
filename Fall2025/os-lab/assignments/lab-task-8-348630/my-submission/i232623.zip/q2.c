#include <stdio.h>
#include <limits.h>

typedef struct
{
    int id;
    int arrival;
    int burst;
    int left;
    int complete;
} Process;

typedef struct
{
    int id;
    int start;
    int end;
} Slot;

void initProcesses(Process p[], int arrivals[], int bursts[], int n)
{
    for (int i = 0; i < n; i++)
    {
        p[i].id = i + 1;
        p[i].arrival = arrivals[i];
        p[i].burst = bursts[i];
        p[i].left = bursts[i];
        p[i].complete = -1;
    }
}

int pickProcess(Process p[], int n, int time)
{
    int min = INT_MAX;
    int chosen = -1;

    for (int i = 0; i < n; i++)
    {
        if (p[i].arrival <= time && p[i].left > 0 && p[i].left < min)
        {
            min = p[i].left;
            chosen = i;
        }
    }

    return chosen;
}

int allDone(Process p[], int n)
{
    for (int i = 0; i < n; i++)
    {
        if (p[i].left > 0)
        {
            return 0;
        }
    }
    return 1;
}

void printGantt(Slot chart[], int count)
{
    printf("Gantt Chart:\n|");

    for (int i = 0; i < count; i++)
    {
        int len = chart[i].end - chart[i].start;

        for (int j = 0; j < len - 1; j++)
        {
            printf(" ");
        }

        printf("P%d", chart[i].id);

        for (int j = 0; j < len - 1; j++)
        {
            printf(" ");
        }

        printf("|");
    }

    printf("\n");
    printf("%d", chart[0].start);

    for (int i = 0; i < count; i++)
    {
        int len = chart[i].end - chart[i].start;

        for (int j = 0; j < len; j++)
        {
            printf("  ");
        }

        if (chart[i].end > 9)
        {
            printf("\b");
        }

        printf("%d", chart[i].end);
    }

    printf("\n\n");
}

int main()
{
    int n = 4;
    int arrivals[] = {0, 1, 2, 3};
    int bursts[] = {8, 4, 9, 5};

    Process p[n];
    initProcesses(p, arrivals, bursts, n);

    Slot chart[50];
    int slots = 0;
    int time = 0;
    int running = -1;

    while (!allDone(p, n))
    {
        int pick = pickProcess(p, n, time);

        if (pick == -1)
        {
            time++;
            continue;
        }

        if (running != p[pick].id)
        {
            if (slots > 0)
            {
                chart[slots - 1].end = time;
            }

            chart[slots].id = p[pick].id;
            chart[slots].start = time;
            slots++;
            running = p[pick].id;
        }

        p[pick].left--;

        if (p[pick].left == 0)
        {
            p[pick].complete = time + 1;
        }

        time++;
    }

    chart[slots - 1].end = time;
    printGantt(chart, slots);

    return 0;
}