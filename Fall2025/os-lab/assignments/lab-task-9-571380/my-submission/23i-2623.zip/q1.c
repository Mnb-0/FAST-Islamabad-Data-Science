#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

const double PI = 3.142;
const double C = 4.0 / 3.0;

struct Rect
{
    double length;
    double breadth;
};

struct Cube
{
    double length;
};

struct Cuboid
{
    double length;
    double breadth;
    double height;
};

struct Cylinder
{
    double radius;
    double height;
    double pi;
};

struct Sphere
{
    double radius;
    double pi;
    double c;
};

struct Result
{
    double area;
    double volume;
};

struct Result resultRect, resultCube, resultCuboid, resultCylinder, resultSphere;

void *AreaRect(void *arg);
void *VolumeCube(void *arg);
void *VolumeCuboid(void *arg);
void *VolumeCylinder(void *arg);
void *VolumeSphere(void *arg);

int main(int argc, char *argv[])
{
    struct Rect rect = {5.0, 3.0};
    struct Cube cube = {4.0};
    struct Cuboid cuboid = {4.0, 3.0, 2.0};
    struct Cylinder cylinder = {3.0, 5.0, PI};
    struct Sphere sphere = {3.0, PI, C};

    pthread_t t1, t2, t3, t4, t5;
    pthread_create(&t1, NULL, AreaRect, &rect);
    pthread_create(&t2, NULL, VolumeCube, &cube);
    pthread_create(&t3, NULL, VolumeCuboid, &cuboid);
    pthread_create(&t4, NULL, VolumeCylinder, &cylinder);
    pthread_create(&t5, NULL, VolumeSphere, &sphere);

    sleep(2);
    
    printf("Rectangle Area: %f\n", resultRect.area);
    printf("Cube Volume: %f\n", resultCube.volume);
    printf("Cuboid Volume: %f\n", resultCuboid.volume);
    printf("Cylinder Volume: %f\n", resultCylinder.volume);
    printf("Sphere Volume: %f\n", resultSphere.volume);
    
    pthread_exit(NULL);

    return 0;
}

void *AreaRect(void *arg)
{
    struct Rect *rect = (struct Rect *)arg;
    resultRect.area = rect->length * rect->breadth;
    pthread_exit(NULL);
}

void *VolumeCube(void *arg)
{
    struct Cube *cube = (struct Cube *)arg;
    resultCube.volume = cube->length * cube->length * cube->length;
    pthread_exit(NULL);
}

void *VolumeCuboid(void *arg)
{
    struct Cuboid *cuboid = (struct Cuboid *)arg;
    resultCuboid.volume = cuboid->length * cuboid->breadth * cuboid->height;
    pthread_exit(NULL);
}

void *VolumeCylinder(void *arg)
{
    struct Cylinder *cylinder = (struct Cylinder *)arg;
    resultCylinder.volume = cylinder->pi * cylinder->radius * cylinder->radius * cylinder->height;
    pthread_exit(NULL);
}

void *VolumeSphere(void *arg)
{
    struct Sphere *sphere = (struct Sphere *)arg;
    resultSphere.volume = sphere->c * sphere->pi * sphere->radius * sphere->radius * sphere->radius;
    pthread_exit(NULL);
}