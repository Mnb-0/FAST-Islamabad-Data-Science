#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]) //argv-> string, int
{
    if (argc < 3 || atoi(argv[2]) < 1)
    {
        perror("Wrong cmd args\n");
        exit(1);
    }

    pid_t p1;
    printf("Parent PID: %d\n", getpid());
    p1 = fork();
    if (p1 < 0)
    {
        perror("P1 fork failed\n");
        exit(1);
    }
    else if (p1 == 0)
    {
        char* args[] = {"Q1_Pattern_i232623",argv[1],argv[2],NULL};
        execvp("./Q1_Pattern_i232623", args);
    }
    else
    {
        wait(NULL);
    }
}