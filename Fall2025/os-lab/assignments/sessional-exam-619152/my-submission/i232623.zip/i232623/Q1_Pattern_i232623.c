#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[]) //argv-> string, int
{
    int size = atoi(argv[2]);

    if(strcmp(argv[1],"square") == 0)
    {
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j< size; j++)
            {
                printf("*");
            }
            printf("\n");
        }
    }
    else if(strcmp(argv[1], "triangle") == 0)
    {
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j <= i; j++)
            {
                printf("*");
            }
            printf("\n");
        }

    }
    else
    {
        printf("Sir edge cases handle krne ka time nai tha try to understand\n");
    }

}