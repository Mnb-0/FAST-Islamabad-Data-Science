#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char *argv[])
{
    if (argc != 2 || atoi(argv[1] < 1))
    {
        perror("Wrong input\n");
        exit(EXIT_FAILURE);
    }
    pid_t p0 = 0;
    int m = atoi(argv[1]);

    char buf[BUFSIZ];
    for (int i = 0; i < m; i++)
    {
        pid_t p = fork();
        p0 = p;
        if (p < 0)
        {
            perror("Worker Fork failed\n");
            exit(1);
        }
        else if (p == 0)
        {
            printf("Worker PID: %d, PPID: %d", getpid(), getppid());
            int matrix[2][2];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    matrix[i][j] = i * (i + j);
                }
            }

            strcpy(buf, (char)(matrix));

            if (i % 2 == 0)
            {
                pid_t p1 = fork();
                if (p1 < 0)
                {
                    perror("Subworked fork failed");
                    exit(1);
                }
                else if (p1 == 0)
                {
                    printf("Subworker of %d PID: %d, PPID: %d", i, getpid(), getppid());
                    strcat(buf, "\n");
                    strcat(buf,("Subworker note for worker %d", i));
                }
                else
                {
                    wait(NULL);
                    printf("Worker %d: Collected Subworker\n", i);
                }
            }
            int f = mkfifo("worker_%d.txt", i, 0666);
            int fd = open("worker_%d.txt", i, O_RDWR);
            write(fd, buf,16+1+strlen("Subworker note for worker i"));
        }
    }

    if (p0 > 0)
    {
        for (int i = 0; i < m; i++)
        {
            wait(NULL);
            printf("Parent collected worked: %d", i);
        }
    }
}