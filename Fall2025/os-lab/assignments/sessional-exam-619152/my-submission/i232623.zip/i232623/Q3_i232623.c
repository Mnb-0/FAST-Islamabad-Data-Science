#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main()
{
    int image[4][4] = {{10, 20, 30, 40},
                       {50, 60, 70, 80},
                       {90, 100, 110, 120},
                       {130, 140, 150, 160}};

    pid_t p1, p2, p3, p4;

    int f = mkfifo("matrix.txt", 0666);
    int fd = open("matrix.txt", O_RDWR);

    char buf[512] = {};

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            strcat(buf, (((char)image[4][4])));
            strcat(buf, "\n");
        }
    }

    char args[] = {NULL}; // temporary

    p1 = fork();
    if (p1 < 0)
    {
        perror("Fork 1 Failed\n");
        exit(1);
    }
    else if (p1 == 0) // child
    {
        execvp("./Q3_P1_i232623", args);
    }
    else
    {
        p2 = fork();
        if (p2 < 0)
        {
            perror("Fork 2 Failed\n");
            exit(1);
        }
        else if (p2 == 0) // child
        {
            execvp("./Q3_P2_i232623", args);
        }
        else
        {
            p3 = fork();
            if (p3 < 0)
            {
                perror("Fork 3 Failed\n");
                exit(1);
            }
            else if (p3 == 0) // child
            {
                execvp("./Q3_P3_i232623", args);
            }
            else
            {
                p4 = fork();
                if (p4 < 0)
                {
                    perror("Fork 4 Failed\n");
                    exit(1);
                }
                else if (p4 == 0) // child
                {
                    execvp("./Q3_P4_i232623", args);
                }
                else
                {
                }
            }
        }
    }

    return 0;
}