#include <iostream>
using namespace std;

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;

    int *arr = new int[size];

    cout << "Enter " << size << " elements of the array:\n";
    for (int i = 0; i < size; i++) 
    {
        cin >> arr[i];
    }

    int target;
    cout << "Enter the target sum: ";
    cin >> target;

    for (int i = 0; i < size; i++) 
    {
        for (int j = i; j < size; j++) 
        {
            for (int k = i; k < size; k++) 
            {
                int sum = 0;
                cout << "Subset: ";
                for (int l = i; l <= k; l++) 
                {
                    cout << arr[l] << " ";
                    sum += arr[l];
                }
                cout << endl;
                if (sum == target) 
                {
                    cout << "Sum of subset is " << target << endl;
                }
            }
        }
    }

    delete[] arr;
    return 0;
}
