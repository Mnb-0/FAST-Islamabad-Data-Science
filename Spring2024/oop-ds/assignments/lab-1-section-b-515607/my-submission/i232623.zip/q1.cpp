#include <iostream>
using namespace std;
void pattern(int , int);
int main()
{
	for (int i = 3, j= 3; i<=8; i++,j+=2)
	{
		cout<< "length="<< i << " & height=" << j << endl;
		pattern(i,j);
		cout<<endl;
	}
}

void pattern(int waveLength, int waveHeight)
{
	for (int i = 0; i < waveHeight; i++) 
	{
		for (int rep = 0; rep < waveLength; rep++)
		{
			for (int j = 0; j < waveHeight * 2 - 1; j++) 
			{
				if (j == i || j == waveHeight * 2 - 2 - i) 
				{
					cout << "*";
				}
				else 
				{
					cout << " ";
				}
			}
		}
		cout << endl;
	}
	for (int i = waveHeight - 2; i >=  0; i--) 
	{
		for (int rep = 0; rep < waveLength; rep++)
		{
			for (int j = 0; j < waveHeight * 2 - 1; j++) 
			{
				if (j == i || j == waveHeight * 2 - 2 - i) 
				{
					cout << "*";
				} 
				else 
				{
					cout << " ";
				}
			}
		}
		cout << endl;
	}
}
