#include <iostream>
#include <fstream>
#include <string>
using namespace std;
void displayMenu();
void registerUser();
void loginUser();
bool isPasswordStrong(string);
string fileName;
string name, password, email, age, user;
int main()
{
	int choice;
	do
	{
		displayMenu();
		cout<<"Enter your choice: \n";
		cin>>choice;
		switch (choice)
		{
	
			case 1:
				{
					cout<<"Register\n";
					registerUser();
					break;
				}
			case 2:
				{
					cout<<"Login\n";
					cout<<"Enter your username: \n";
					cin>>user;
					cout<<"Enter your password: \n";
					cin>>password;
					string temp1,temp2,temp3;
					fstream dataFile;
					dataFile.open(fileName , ios::in);
						dataFile >> temp1;//name
						dataFile >> temp1;//age
						dataFile >> temp1;//email
						dataFile >> temp2;//username
						dataFile >> temp3;//password
					dataFile.close();
					if(temp2 == "username: " + user && temp3 == "password: " + password)
					{
						loginUser();
					}
					break;
				}
			case 3:
				{
					cout<<"Ending\n";
					break;
				}
			default:
				{
					cout<<"Please enter a valid option from 1 - 3\n";
				}
		}
	} while(choice != 3);
	return 0;
}

void displayMenu()
{
	cout<<"Press 1 to Register=>\n";
	cout<<"Press 2 to Login=>\n";
	cout<<"Press 3 to Exit=>\n";
}
void registerUser()
{
	
	cout<<"Enter your name: \n";
	cin>>name;
	cout<<"Enter your age: \n";
	cin>>age;
	cout<<"Enter your email: \n";
	cin>>email;
	cout<<"Enter your username: \n";
	cin>>user;
	cout<<"Enter your password: \n";
	cin>>password;
	if(isPasswordStrong(password) == true)
	{
		cout<<"Starting your registration now!\n";
		fileName = name + ".txt";
		fstream dataFile;
		dataFile.open(fileName , ios::out);
			dataFile << "name: " + name + "\n";
			dataFile << "age: " + age + "\n";
			dataFile << "email: " + email + "\n";
			dataFile << "username: " + user + "\n";
			dataFile << "password: " + password + "\n";
		dataFile.close();
		cout<<"Registration finished. Press 2 to login.\n";
	}
	else
	{
		cout<<"Please enter a strong password. It should be alphanumeric, contain at least one special character, a mix of upper and lower case characters and also be at least 8 characters.\n";
		cout<<"Press 1 to restart registration";
	}
}
void loginUser()
{	
	string temp;
	fstream dataFile;
	dataFile.open(fileName , ios::in);
		dataFile >> temp;
		cout<<temp<<"\n";
		dataFile >> temp;
		cout<<temp<<"\n";
		dataFile >> temp;
		cout<<temp<<"\n";
		dataFile >> temp;
		cout<<temp<<"\n";
		dataFile >> temp;
		cout<<temp<<"\n";
	dataFile.close();
	cout<<"Login Successful! All details displayed.\n";
}
bool isPasswordStrong(string pass)
{
	bool up = false, low = false, num = false, special = false;
	bool valid = false;
	int length = pass.length();
	char arr[length+1];
	for(int i = 0 ; i < length ; i++)
	{
		arr[i] = pass[i];
	}
	arr[length] = '\0';
	for(int i = 0 ; i <= length ; i++)
	{
		if (arr[i] >= 'A' && arr[i] <= 'Z')
		{
			up = true;
		}
		if (arr[i] >= 'a' && arr[i] <= 'z')
		{
			low = true;
		}
		if (arr[i] >= '0' && arr[i] <= '9')
		{
			num = true;
		}
		if (arr[i] == '@' || arr[i] == '#' || arr[i] == '$' || arr[i] == '%')
		{
			special = true;
		}
	}
	if(up == true && low == true && num == true && special == true && length >= 8)
	{
		return true;
	}
	else
	{
		return false;
	}
}
