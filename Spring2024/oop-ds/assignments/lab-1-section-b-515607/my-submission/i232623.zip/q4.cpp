#include <iostream>
#include <string>
using namespace std;

void replaceSubstring(string stringIn, string toFind, string replacement) {
    int startPos = -1, endPos = -1;
    bool found = false;
    int lengthIn = 0, lengthFind = 0, lengthRep = 0;

    int count = 0;
    while (stringIn[count] != '\0') {
        lengthIn++;
        count++;
    }

    count = 0;
    while (toFind[count] != '\0') {
        lengthFind++;
        count++;
    }

    count = 0;
    while (replacement[count] != '\0') {
        lengthRep++;
        count++;
    }

    for (int i = 0, j = 0, k = 0; i <= lengthIn; i++) {
        if (stringIn[i] == toFind[j] && j <= lengthFind) {
            if (!found) {
                found = true;
                startPos = i - j;
                endPos = i;
            }
            j++;
        } else {
            j = 0;
            found = false;
        }

        if (found && k <= lengthRep) {
            stringIn[startPos] = replacement[k];
            k++;
            startPos++;
        }
    }

    cout << stringIn;
}

int main() {
    replaceSubstring("I support Pakistan", "Pak", "Afghan");

    return 0;
}

