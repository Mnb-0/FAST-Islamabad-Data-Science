#include <iostream>
using namespace std;
int main()
{
	int fno, sno, *ptr1, *ptr2, sum;
	ptr1 = &fno;
	ptr2 = &sno;
	cout<<"Enter two numbers:\n";
	cin>>fno>>sno;
	sum = *ptr1 + *ptr2;
	cout<<sum<<"\n";
	return 0;
}
