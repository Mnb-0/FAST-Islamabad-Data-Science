#include <iostream>
#include <string>
using namespace std;
int main()
{
    string str = " ";
    cout<<"Enter a string: ";
    cin>>str;
    int len = 0, i = 0;
    while(str[i] != '\0')
    {
        len++;
        i++;
    }
    cout<<"Original string: "<<str<<endl;
    cout<<"Reversed string: ";
    for(int j = len -1; j>=0; j--)
    {
        cout<<str[j];
    }
    return 0;
}