#include <iostream>
using namespace std;

void swapNumbers(int*, int*);
int main()
{
    int num1 , num2;
    cout<<"Enter two numbers to swap: ";
    cin>>num1>>num2;
    swapNumbers(&num1, &num2);
    cout<<num1<<"\n"<<num2<<"\n";
}

void swapNumbers(int *x, int *y)
{
    int temp = 0;
    temp = *x;
    *x = *y;
    *y = temp;
}