#include <iostream>
using namespace std;
int Factorial(int, int*);
int main()
{
    int fact = 0, n = 0;
    cout<<"Enter a number:\n";
    cin>>n;
    Factorial(n , &fact);
    cout<<fact<<"\n";
    return 0;
}

int Factorial(int num , int *factorial)
{
    *factorial = 1;
    for(int i = 1; i <= num; i++)
    {
        *factorial = *factorial * i;
    }
    return *factorial;
}