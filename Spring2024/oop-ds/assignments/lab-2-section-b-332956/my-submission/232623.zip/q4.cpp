#include <iostream>
#include <string>
using namespace std;
int main()
{
    string str1 = "abcdefghijk";
    char *ptr;
    int len = 0;
    int ctrV = 0, ctrC = 0;
    len = str1.length();
    ptr = &str1[0];
    for(int i = 0; i < len; i++)
    {
        if(*ptr == 'a' || *ptr == 'e' || *ptr == 'i' || *ptr == 'o' || *ptr == 'u')
        {
            ctrV++;
            ptr++;
        }
        else if((*ptr >= 'A' && *ptr <= 'Z') || (*ptr >= 'a' && *ptr <= 'z'))
        {
            ctrC++;
            ptr++;
        }
    }
    cout<<"Consonants: "<< ctrC <<endl;
    cout<<"Vowels "<<ctrV<< endl;
    return 0;
}