#include <iostream>
using namespace std;
int main()
{
    int n, i , arr1[15];
    int *ptr;
    ptr = arr1;
    for(int i = 0; i <= 15; i++)
    {
        cout<<"Enter a number: "<<endl;
        cin>>*ptr;
        ptr++;
    }
    ptr--;
    for(int i = 14; i >=-1; i--)
    {
        cout<<*ptr<<endl;
        ptr--;
    }

    return 0;
}