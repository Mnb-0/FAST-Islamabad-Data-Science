#include <iostream>
#include <string>
using namespace std;

int main()
{
    string password;
    cout << "Enter a password: " << endl;
    cin >> password;

    char *ptr = &password[0];
    bool isLow = false, isUp = false, isNum = false, isSpecial = false;
    int len = 0;

    while (*ptr != '\0')
    {
        len++;
        ptr++;
    }

    ptr = &password[0];

    if (len >= 8)
    {
        for (int j = 0; j < len; j++)
        {
            if (*ptr >= 'A' && *ptr <= 'Z')
            {
                isUp = true;
            }
            else if (*ptr >= 'a' && *ptr <= 'z')
            {
                isLow = true;
            }
            else if (*ptr == '@' || *ptr == '#' || *ptr == '$' || *ptr == '%')
            {
                isSpecial = true;
            }
            else if (*ptr >= '0' && *ptr <= '9')
            {
                isNum = true;
            }
            ptr++;
        }

        if (isNum == true && isSpecial == true && isLow == true && isUp == true)
        {
            cout << "Valid Password" << endl;
        }
        else
        {
            cout << "Invalid Password" << endl;
        }
    }
    else
    {
        cout << "Length must be at least 8" << endl;
    }

    return 0;
}
