#include <iostream>
using namespace std;
int main()
{
    int arr[9] = {0,1,3,4,5,6,7,8,10};
    int *ptr = &arr[0];
    bool swap = false;
    int temp = 0;
    int size = sizeof(arr)/sizeof(arr[0]);
    for(int i = 0; i < size-1; i++)
    {
        if(i % 2 == 0)
        {
            if(*ptr > *(ptr+1))
            {
                temp = *ptr;
                *ptr = *(ptr + 1);
                *(ptr+1) = temp;
            }
            
        }
        if(i % 2 == 1)
        {
            if(*ptr < *(ptr+1))
            {
                temp = *ptr;
                *ptr = *(ptr + 1);
                *(ptr+1) = temp;
            }
        }
        ptr++;
    }
    for(int i = 0; i < size; i++)
    {
        cout<<arr[i]<<endl;
    }
    
}