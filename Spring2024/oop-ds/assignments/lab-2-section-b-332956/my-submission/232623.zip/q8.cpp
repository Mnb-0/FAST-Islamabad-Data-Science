#include <iostream>
using namespace std;
int main()
{
    int sum = 0,size = 8, count;
    int arr[size] = {1, 5, 7, 5,8, 9, 11, 12};
    cout<<"Enter a number to test: "<<endl;
    cin>>sum;
    cout<<"Array pairs whose sum equals to "<<sum<<" : "<<endl;
    for(int i = 0; i < size ; i++)
    {
        for(int j = i + 1; j < size ; j++)
        {
            if((arr[i]+arr[j]) == sum)
            {
                cout<<arr[i]<<" , "<<arr[j]<<endl;
                count++;
            }
        }
    }
    cout<<"Number of pairs whose sum equals to "<<sum<<" :"<<count<<endl;
    return 0;

}