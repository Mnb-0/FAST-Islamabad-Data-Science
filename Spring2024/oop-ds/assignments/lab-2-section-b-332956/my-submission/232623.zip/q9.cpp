#include <iostream>
using namespace std;

int main() {
    const int size = 8;
    int arr[size] = {4, 5, 9, 12, 9, 22, 45, 7};
    int temp = 0;

    //Sorting the array in ascending order
    for (int i = 0; i < size - 1; i++) {
        bool swapped = false;

        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;

                swapped = true;
            }
        }
        if (!swapped) {
            break;
        }
    }

    cout << "Sorted Array using Bubble Sort:\n";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    //Pattern is high-low-high-low
    for(int i = 0; i < size -1; i+=2)
    {
        temp = arr[i];
        arr[i] = arr[i + 1];
        arr[i + 1] = temp;
    }
    cout<<endl;
    cout << "Wave Form:\n";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
