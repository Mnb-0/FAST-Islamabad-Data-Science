#include <iostream>
using namespace std;

// Function prototypes
void Populate(int* arr, int size, char name);
void SortA(int* arr, int size);
void SortD(int* arr, int size);
void printArr(int* arr, int size);
void MergeSort(int* A, int* B, int* C, int &K, int M, int N);

int main() 
{
    int M = 0, N = 0;
    cout << "Enter M: ";
    cin >> M;
    int* A = new int[M];
    cout << "Enter elements:\n";
    Populate(A, M, 'A');

    cout << "Enter N: ";
    cin >> N;
    int* B = new int[N];
    cout << "Enter elements:\n";
    Populate(B, N, 'B');

    int k = M + N;
    int* C = new int[M + N];
    
    SortA(A, M);
    SortD(B, N);
    MergeSort(A, B, C, k, M, N);
    
    cout << "The Merged Array in Ascending Order:\n";
    printArr(C, M + N);

    
    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}

void MergeSort(int* A, int* B, int* C, int &K, int M, int N)
{
    int i = 0, j = N - 1;
    K = 0;
    while (i < M && j >= 0)
    {
        if (A[i] <= B[j])
            C[K++] = A[i++];
        else
            C[K++] = B[j--];
    }
    while (i < M)
        C[K++] = A[i++];
    while (j >= 0)
        C[K++] = B[j--];
}

void Populate(int* arr, int size, char name) 
{
    for (int i = 0; i < size; i++) 
    {
        cout << "Enter element " << i + 1 << ": ";
        cin >> arr[i];
    }
}

void SortA(int* arr, int size) 
{
    for (int i = 0; i < size; i++) 
    {
        for (int j = 0; j < size - 1; j++) 
        {
            if (arr[j] > arr[j + 1]) 
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void SortD(int* arr, int size) 
{
    for (int i = 0; i < size; i++) 
    {
        for (int j = 0; j < size - 1; j++) 
        {
            if (arr[j] < arr[j + 1]) 
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void printArr(int* arr, int size) 
{
    for (int i = 0; i < size; i++) 
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
