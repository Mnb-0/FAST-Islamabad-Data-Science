#include <iostream>
using namespace std;

void Mix(int* A, int* B, int* C, int K);
void Populate(int* arr, int size, char name);

int M = 0, N = 0; // Declared Globally so I dont have to pass them

int main() 
{
    cout << "Enter M: ";
    cin >> M;
    int* A = new int[M];
    cout << "Enter elements for A:\n";
    Populate(A, M, 'A');

    cout << "Enter N: ";
    cin >> N;
    int* B = new int[N];
    cout << "Enter elements for B:\n";
    Populate(B, N, 'B');

    int K = M + N;
    int* C = new int[K];

    Mix(A, B, C, K);

    cout << "Merged array C:\n";
    for (int i = 0; i < K; i++) 
    {
        cout << C[i] << " ";
    }
    cout << endl;

    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}

void Populate(int* arr, int size, char name) 
{
    for (int i = 0; i < size; i++) 
    {
        cout << "Enter element " << i + 1 << " for " << name << ": ";
        cin >> arr[i];
    }
}

void Mix(int* A, int* B, int* C, int K) 
{
    int inC = 0;
    int enC = K - 1;

    for (int i = 0; i < M; i++)
    {
        if (A[i] % 2 == 0) 
        { 
            C[inC++] = A[i]; 
        }
        else 
        { 
            C[enC--] = A[i]; 
        }
    }
    for (int i = 0; i < N; i++)
    {
        if (B[i] % 2 == 0) 
        {
            C[inC++] = B[i]; 
        }
        else 
        {
            C[enC--] = B[i]; 
        }
    }
}
