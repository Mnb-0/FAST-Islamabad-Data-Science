#include <iostream>
using namespace std;

int main() {
    int row = 6, col = 6, max = 0, sum = 0;
    
    
    int** arr = new int*[row];
    for (int i = 0; i < row; i++)
        arr[i] = new int[col];

    int temp[row][col] = {{1, 1, 1, 0, 0, 0},
                          {0, 1, 0, 0, 0, 0},
                          {1, 1, 1, 0, 0, 0},
                          {0, 0, 0, 0, 0, 0},
                          {1, 1, 0, 1, 0, 0}};

    
    for (int i = 0; i < row; i++)
        for (int j = 0; j < col; j++)
            arr[i][j] = temp[i][j];

    for (int i = 0; i < row - 2; i++) 
	{
        for (int j = 0; j < col - 2; j++) 
		{
            sum = arr[i][j] + arr[i][j + 1] + arr[i][j + 2] +
                  arr[i + 1][j + 1] +
                  arr[i + 2][j] + arr[i + 2][j + 1] + arr[i + 2][j + 2];
            if (sum > max) 
			{
                max = sum;
            }
        }
    }

    cout << "The Maximum Hourglass Sum is: " << max << endl;

    
    for (int i = 0; i < row; i++)
        delete[] arr[i];
    delete[] arr;

    return 0;
}
