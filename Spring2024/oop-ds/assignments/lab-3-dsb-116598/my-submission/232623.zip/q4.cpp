#include <iostream>

using namespace std;

int ElementSum(int*** arr, int x, int y, int z)
{
    int sum = 0;
    for(int i = 0; i < x; i++)
    {
        for(int j = 0; j < y; j++)
        {
            for(int k = 0; k < z; k++)
            {
                sum = sum + arr[i][j][k];
            }
        }
    }
    return sum;
}
int RowSum(int*** arr, int x, int y, int z)
{
    int sum = 0,row = 0;
    cout<<"Enter the row you want to sum(Starting at 1): ";
    cin>>row;
    if(row <= x && row > 0)
    {
        for(int i = 0; i < x; i++)
        {
            for(int j = 0; j < y; j++)
            {
            
                sum = sum + arr[row-1][i][j];
        
            }
        }
    return sum;
    }
}

int ColSum(int*** arr, int x, int y, int z)
{
    int sum = 0,col = 0;
    cout<<"Enter the column you want to sum(Starting at 1): ";
    cin>>col;
    if(col <= x && col > 0)
    {
        for(int i = 0; i < x; i++)
        {
            for(int j = 0; j < y; j++)
            {
            
                sum = sum + arr[col-1][i][j];
        
            }
        }
    return sum;
    }
}
int LayerSum(int*** arr, int x, int y, int z)
{
    int sum = 0,layer = 0;
    cout<<"Enter the layer you want to sum(Starting at 1): "<<endl;
    cin>>layer;
    if(layer <= x && layer > 0)
    {
        for(int i = 0; i < x; i++)
        {
            for(int j = 0; j < y; j++)
            {
            
                sum = sum + arr[layer-1][i][j];
        
            }
        }
    return sum;
    }
}

int main() 
{
    int x, y, z;
    
    
    cout << "Enter the dimensions of the 3D array (Length/Width/Height): ";
    cin >> x >> y >> z;

    
    int*** arr = new int**[x];
    for (int i = 0; i < x; i++) 
    {
        arr[i] = new int*[y];
        for (int j = 0; j < y; j++) 
        {
            arr[i][j] = new int[z];
        }
    }

    
    cout << "Enter the elements of the 3D array:" << endl;
    for (int i = 0; i < x; i++) 
    {
        for (int j = 0; j < y; j++) 
        {
            for (int k = 0; k < z; k++) 
            {
                cin >> arr[i][j][k];
            }
        }
    }

    
    cout << "3D Array:" << endl;
    for (int i = 0; i < x; i++) 
    {
        cout << "Layer " << i + 1 << ":" << endl;
        for (int j = 0; j < y; j++) 
        {
            for (int k = 0; k < z; k++) 
            {
                cout << arr[i][j][k] << " ";
            }
            cout << endl;
        }
    }
    int el = ElementSum(arr,x,y,z);
    cout<<"Total Sum of Elements: "<<el<<endl;
    el = RowSum(arr,x,y,z);
    cout<<"Sum of Specified Row: "<<el<<endl;
    el = ColSum(arr,x,y,z);
    cout<<"Sum of Specified Column: "<<el<<endl;
    el = LayerSum(arr,x,y,z);
    cout<<"Sum of Specified Layer: "<<el<<endl;

    
    for (int i = 0; i < x; i++) 
    {
        for (int j = 0; j < y; j++) 
        {
            delete[] arr[i][j];
        }
        delete[] arr[i];
    }
    delete[] arr;

    return 0;
}
