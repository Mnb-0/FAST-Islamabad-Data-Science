#include <iostream>
#include <string>
using namespace std;
string dictionary[109] = {
    "cat", "dog", "bat", "hat", "run", "sun", "red", "blue", "pen", "cup",
    "fish", "bird", "rose", "tree", "lake", "moon", "star", "fork", "lamp", "book",
    "play", "pool", "rose", "silk", "song", "ship", "tile", "vest", "wish", "zoom",
    "case", "drop", "face", "gold", "jump", "kick", "lime", "nose", "ring", "tail",
    "cloud", "crawl", "dream", "fresh", "grain", "happy", "juice", "lucky", "music", "piano",
    "queen", "quick", "smile", "storm", "toast", "umbra", "video", "wrist", "zebra", "world",
    "apple", "brave", "chess", "drink", "flame", "grape", "jazz", "lemon", "novel", "pride",
    "quest", "route", "shoe", "trace", "unity", "vivid", "water", "xerox", "yellow", "zesty",
    "silver", "orange", "camera", "travel", "window", "floral", "banana", "purple", "turkey", 
    "magnet", "branch", "guitar", "impact", "castle", "pickle", "forest", "oliver", "planet", "summer",
    "a", "i", "on", "up", "by", "go", "no", "us", "it", "as"
};
int main(){
	int rows, columns, index=0;
	string compare="";
	cout<<"Enter rows = ";
	cin>>rows;
	cout<<"Enter columns = ";
	cin>>columns;
	char **arr;
	arr = new char *[rows];
	for(int i=0; i<rows; i++){
		arr[i]= new char[columns];
		for(int j=0; j<columns; j++){
			cout<<"Array["<<i<<"]["<<j<<"] = ";
			cin>>arr[i][j];	
		}
		cout<<endl;
	}
	
	
	for(int i=0; i<rows; i++){
		for(int j=0; j<columns; j++){
			compare = "";
			while(index<=columns-1){
				compare += arr[i][j+index];
				for(int k=0; k<109; k++){ 
					if(compare==dictionary[k])
						cout<<compare<<" ";
				}
				index++;
			}	
			index=0;
		}
	}
	for(int i=0; i<rows; i++)
		delete[]arr[i];
	delete[]arr; 
}
