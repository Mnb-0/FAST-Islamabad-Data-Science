#include <iostream>
using namespace std;

int search(int arr[], int target, int size)
{
    if(arr[size-1] == target)
    {
        return size-1;
    }
    else if(size>0)
    {
        return search(arr, target, size-1);
    }
    return -1;
}
