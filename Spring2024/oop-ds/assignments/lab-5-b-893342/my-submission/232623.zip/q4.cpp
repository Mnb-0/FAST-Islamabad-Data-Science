#include <iostream>
#include <string>
using namespace std;


int Consonants(string str, int index) 
{
    if (index == str.length()) 
    {
        return 0;
    }
    char c = str[index];
    if (!(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') && (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z')) 
    {
        return 1 + Consonants(str, index + 1);
    }
    return Consonants(str, index + 1);
}

int countConsonants(string str) 
{
    return Consonants(str, 0);
}
