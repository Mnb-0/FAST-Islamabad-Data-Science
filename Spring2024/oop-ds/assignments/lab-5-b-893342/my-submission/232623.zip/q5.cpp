#include <iostream>
using namespace std;

int arrSum(int arr[], int size)
{
    if (size > 0)
    {
        return arr[size - 1] + arrSum(arr, size - 1);
    }
    else
    {
        return 0;
    }
}

