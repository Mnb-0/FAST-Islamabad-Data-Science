
#include <gtest/gtest.h>
#include "q1.cpp"
#include "q2.cpp"
#include "q3.cpp"
#include "q4.cpp"
#include "q5.cpp"

// Test cases for factorial function
TEST(FactorialTest, HandlesPositiveInput) {
    EXPECT_EQ(factorial(0), 1);
    EXPECT_EQ(factorial(1), 1);
    EXPECT_EQ(factorial(5), 120);
}

TEST(FactorialTest, HandlesNegativeInput) {

    EXPECT_EQ(factorial(-5), -1);
}

// Test cases for search function
TEST(SearchTest, HandlesExistingElement) {
    int arr[] = {1, 2, 3, 4, 5};
    EXPECT_EQ(search(arr, 3, 5), 2);
}

TEST(SearchTest, HandlesNonExistingElement) {
    int arr[] = {1, 2, 3, 4, 5};
    EXPECT_EQ(search(arr, 6, 5), -1);
}

// Test cases for isPrimeNumber function
TEST(PrimeTest, HandlesPrimeNumbers) {
    EXPECT_TRUE(isPrimeNumber(2));
    EXPECT_TRUE(isPrimeNumber(3));
    EXPECT_TRUE(isPrimeNumber(7));
    EXPECT_TRUE(isPrimeNumber(13));
}

TEST(PrimeTest, HandlesNonPrimeNumbers) {
    EXPECT_FALSE(isPrimeNumber(1));
    EXPECT_FALSE(isPrimeNumber(4));
    EXPECT_FALSE(isPrimeNumber(9));
    EXPECT_FALSE(isPrimeNumber(15));
}

// Test cases for Consonants function
TEST(ConsonantsTest, HandlesEmptyString) {
    EXPECT_EQ(Consonants("", 0), 0);
}

TEST(ConsonantsTest, HandlesStringWithConsonants) {
    EXPECT_EQ(Consonants("hello", 0), 3);
}

TEST(ConsonantsTest, HandlesStringWithNoConsonants) {
    EXPECT_EQ(Consonants("aeiou", 0), 0);
}

// Test cases for countConsonants function
TEST(CountConsonantsTest, HandlesEmptyString) {
    EXPECT_EQ(countConsonants(""), 0);
}

TEST(CountConsonantsTest, HandlesStringWithConsonants) {
    EXPECT_EQ(countConsonants("hello"), 3); 
}

TEST(CountConsonantsTest, HandlesStringWithNoConsonants) {
    EXPECT_EQ(countConsonants("aeiou"), 0);
}


int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
