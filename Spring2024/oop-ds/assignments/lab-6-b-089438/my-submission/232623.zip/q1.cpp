#include <iostream>
using namespace std;

void matrixMultiplication(int**& A, int**& B, int m, int n, int i = 0, int j = 0)
{

}

void createArray(int**& arr, int m, int n)
{
    if (m > 0)
    {
        arr[m - 1] = new int[n];
        createArray(arr, m - 1, n);
    }
}

void populateArray(int**& arr, int m, int n, int i = 0, int j = 0)
{
    if (i < m)
    {
        if (j < n)
        {
            cout << "Enter a value for [" << i << "][" << j << "]:\n";
            cin >> arr[i][j];
            populateArray(arr, m, n, i, j + 1);
        }
        else
        {
            populateArray(arr, m, n, i + 1, 0);
        }
    }
}

int main()
{
    int rows, cols;
    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    int **A = new int*[rows];
    createArray(A, rows, cols);
    populateArray(A, rows, cols);
    int **B = new int*[rows];
    createArray(B, rows, cols);
    populateArray(B, rows, cols);


    // Printing the array
    cout << "Array elements: \n";
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            cout << A[i][j] << " ";
        }
        cout << endl;
    }

    // Deallocating memory
    for (int i = 0; i < rows; i++)
    {
        delete[] A[i];
    }
    delete[] A;
    
    cout << "Array elements: \n";
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            cout << B[i][j] << " ";
        }
        cout << endl;
    }

    // Deallocating memory
    for (int i = 0; i < rows; i++)
    {
        delete[] B[i];
    }
    delete[] B;

    return 0;
}
