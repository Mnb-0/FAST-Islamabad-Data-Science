#include <iostream>
using namespace std;
int temp = 0;
void populateArray(int*& arr, int size, int i = 0)
{
    if(i<size)
    {
        cout<<"Enter a value: \n";
        cin>>arr[i];
        populateArray(arr,size,i + 1);
    }
    else
    {
        return;
    }
}
void print(int*& arr, int size, int i = 0)
{
    if(i<size)
    {
        cout<<arr[i]<<' ';
        print(arr,size,i + 1);
    }
    else
    {
        return;
    }
}

void movePositives(int*& arr, int*& res, int& resIndex, int size, int i = 0)
{
    if(i < size)
    {
        if(arr[i] >= 0)
        {
            res[resIndex++] = arr[i];
        }
        movePositives(arr, res, resIndex, size, i + 1);
    }
}
void moveNegatives(int*& arr, int*& res, int& resIndex, int size, int i = 0)
{
    if(i < size)
    {
        if(arr[i] < 0)
        {
            res[resIndex++] = arr[i];
        }
        moveNegatives(arr, res, resIndex, size, i + 1);
    }
}
int main()
{
    int size = 0;
    cout<<"Enter array size: \n";
    cin>>size;
    int* arr = new int[size];
    int* res = new int[size];
    populateArray(arr,size,0);
    print(arr,size);
    int resIndex = 0;
    cout<<endl;
    movePositives(arr, res, resIndex, size);
    moveNegatives(arr,res,resIndex,size);
    print(res, resIndex);
    delete[] arr;
    delete[] res;
    return 0;
}
