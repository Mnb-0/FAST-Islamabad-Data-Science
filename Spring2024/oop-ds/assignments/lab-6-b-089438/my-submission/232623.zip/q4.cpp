#include <iostream>
using namespace std;
int temp = 0;
void populateArray(int*& arr, int size, int i = 0)
{
    if(i<size)
    {
        cout<<"Enter a value: \n";
        cin>>arr[i];
        populateArray(arr,size,i + 1);
    }
    else
    {
        return;
    }
}
void print(int*& arr, int size, int i = 0)
{
    if(i<size)
    {
        cout<<arr[i]<<' ';
        print(arr,size,i + 1);
    }
    else
    {
        return;
    }
}
void bubble(int*& arr, int size, int i)
{
    if(i == size)
    {
        return;
    }
    else
    {
        for(int j = 0; j < size - 1; j++)
        {
            if(arr[j] > arr[j+1])
            {

                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j+1] = temp;
            }
            
        }
        bubble(arr,size,i+1);
        
    }
}

int main()
{
    int size = 0;
    cout<<"Enter array size: \n";
    cin>>size;
    int* arr = new int[size];
    int* res = new int[size];
    populateArray(arr,size,0);
    print(arr,size);
    //int max_swaps = (size*(size -1))/2;
    //bubbleSort(arr,size,max_swaps, 0);
    bubble(arr,size,0);
    cout<<endl;
    print(arr,size);
    delete[] arr;
    return 0;
}

// void bubbleSort(int*& arr, int size, int swaps, int i)
// {
//     if(swaps>0)
//     {
//         if(i<size - 1)
//         {
//             if(arr[i]>arr[i+1])
//             {
//                 temp = arr[i];
//                 arr[i] = arr[i+1];
//                 arr[i+1] = temp;
//                 bubbleSort(arr,size,swaps,i++);
//             }
//             bubbleSort(arr,size,swaps--,i);
//         }
        
//     }

// }