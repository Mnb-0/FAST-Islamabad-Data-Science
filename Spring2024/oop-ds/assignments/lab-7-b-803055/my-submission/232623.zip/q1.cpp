#include <iostream>
#include <string>
using namespace std;
struct Student
{
    int roll;
    string name;
    float marks;
};
void store(Student *arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << "Enter roll number: ";
        cin >> arr[i].roll;
        cout << "Enter name: ";
        cin >> arr[i].name;
        cout << "Enter marks of student: ";
        cin >> arr[i].marks;
    }
}
void display(Student *arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << arr[i].roll << endl;
        cout << arr[i].name << endl;
        cout << arr[i].marks << endl;
    }
}

int main()
{
    int studentNo = 0;
    cout << "Enter the number of students: \n";
    cin >> studentNo;
    Student *arr = new Student[studentNo];
    store(arr, studentNo);
    display(arr, studentNo);
    delete[] arr;
}