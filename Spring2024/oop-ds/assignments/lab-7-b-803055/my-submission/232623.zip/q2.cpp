#include <iostream>
#include <string>
using namespace std; 
struct Employee
{
    string code;
    string name;
    float salary;
};
void input(Employee &struct1)
{
    cout<<"Enter employee code: \n";
    cin>>struct1.code;
    cout<<"Enter employee name: \n";
    cin>>struct1.name;
    cout<<"Enter employee salary: \n";
    cin>>struct1.salary;
}

void swapArg(Employee &struct1, Employee &struct2)
{
    string temp;
    float temp1;
    cout<<"Before Swap: \n";
    cout<<"Employee 1: \n";
    cout<<struct1.code<<"\n";
    cout<<struct1.name<<"\n";
    cout<<struct1.salary<<"\n";
    cout<<"Employee 2: \n";
    cout<<struct2.code<<"\n";
    cout<<struct2.name<<"\n";
    cout<<struct2.salary<<"\n";
    //Roll Swap
    temp = struct1.code;
    struct1.code = struct2.code;
    struct2.code = temp;
    //Name Swap
    temp = struct1.name;
    struct1.name = struct2.name;
    struct2.name = temp;
    //Salary Swap
    temp1 = struct1.salary;
    struct1.salary = struct2.salary;
    struct2.salary = temp1;
    cout<<"After Swap: \n";
    cout<<"Employee 1: \n";
    cout<<struct1.code<<"\n";
    cout<<struct1.name<<"\n";
    cout<<struct1.salary<<"\n";
    cout<<"Employee 2: \n";
    cout<<struct2.code<<"\n";
    cout<<struct2.name<<"\n";
    cout<<struct2.salary<<"\n";
}

int main()
{
    Employee emp1 ={"0", " ", 0.0};
    Employee emp2 ={"0", " ", 0.0};
    input(emp1);
    input(emp2);
    swapArg(emp1,emp2);
    return 0;
}