#include <iostream>
#include <string>
using namespace std;
struct fraction
{
    int numerator;
    int denominator;
};
void init(fraction &num)
{
    cout << "Enter a numerator: ";
    cin >> num.numerator;
    cout << "Enter a denominator: ";
    cin >> num.denominator;
}
fraction add(fraction &one, fraction &two)
{
    fraction sum;
    sum.numerator = (one.numerator * two.denominator) + (two.numerator * one.denominator);
    sum.denominator = (one.denominator * two.denominator);
    return sum;
}
fraction sub(fraction &one, fraction &two)
{
    fraction sum;
    sum.numerator = (one.numerator * two.denominator) - (two.numerator * one.denominator);
    sum.denominator = (one.denominator * two.denominator);
    return sum;
}
fraction multi(fraction &one, fraction &two)
{
    fraction sum;
    sum.numerator = (one.numerator * two.numerator);
    sum.denominator = (one.denominator * two.denominator);
    return sum;
}
fraction div(fraction &one, fraction &two)
{
    fraction sum;
    sum.numerator = (one.numerator * two.denominator);
    sum.denominator = (one.denominator * two.numerator);
    return sum;
}

int main()
{
    fraction num1, num2;
    init(num1);
    init(num2);
    cout << add(num1, num2).numerator << "/";
    cout << add(num1, num2).denominator << endl;

    cout << sub(num1, num2).numerator << "/";
    cout << sub(num1, num2).denominator << endl;

    cout << multi(num1, num2).numerator << "/";
    cout << multi(num1, num2).denominator << endl;

    cout << div(num1, num2).numerator << "/";
    cout << div(num1, num2).denominator << endl;
}