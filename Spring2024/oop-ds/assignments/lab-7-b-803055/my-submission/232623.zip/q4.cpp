#include <iostream>
#include <string>
using namespace std;
struct car
{
    int petrolLevel;
    void setPetrolLevel(int petrolLevelVal)
    {
        if (petrolLevelVal < 45)
        {
            petrolLevel = petrolLevelVal;
        }
    }
    int getPetrolLevel()
    {
        return petrolLevel;
    }
    bool moveCar(int distanceKM)
    {
        if (distanceKM <= petrolLevel)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    void refill()
    {
        petrolLevel = 45;
    }
    bool isEmpty()
    {
        if (petrolLevel == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};

int main()
{
    car meow;
    meow.setPetrolLevel(40);
    meow.refill();
    cout<<meow.isEmpty()<<endl;
    cout<<meow.moveCar(30);
    return 0;
}