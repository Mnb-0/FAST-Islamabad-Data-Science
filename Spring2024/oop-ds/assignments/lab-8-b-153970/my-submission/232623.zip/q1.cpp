#include <iostream>
#include <string>
using namespace std;

struct Address
{
    string street;
    int zipCode;
};

struct Student
{
    string name;
    int rollNumber;
    Address address;
    void setStudentInfo(const string &studentName, int rollNo, const string &street, int zipCode)
    {
        name = studentName;
        rollNumber = rollNo;
        address = {street, zipCode};
    }
    void displayStudentInfo()
    {
        cout << name << endl;
        cout << rollNumber << endl;
        cout << address.street << endl;
        cout << address.zipCode << endl;
    }
};
struct ExamRoom
{
    int numRows;
    int numCols;
    Student *students;
    Student **seatingArrangement;

    void inputStudentRecords(int n)
    {
        students = new Student[n];
        for (int i = 0; i < n; i++)
        {
            cout << "Enter Name, Roll Number, Street and Zipcode: \n";
            cin >> students[i].name;
            cin >> students[i].rollNumber;
            cin >> students[i].address.street;
            cin >> students[i].address.zipCode;
        }
    }
    void makeSeatingPlan(int rows, int cols)
    {
        numRows = rows;
        numCols = cols;
        seatingArrangement = new Student *[rows];
        for (int i = 0; i < rows; i++)
        {
            seatingArrangement[i] = new Student[cols];
        }
        for (int i = 0; i < numRows * numCols; i++)
        {
            for (int j = i + 1; j < numRows * numCols; j++)
            {
                if (students[i].rollNumber > students[j].rollNumber)
                {
                    Student temp = students[i];
                    students[i] = students[j];
                    students[j] = temp;
                }
            }
        }
        for (int i = 0, k = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++, k++)
            {
                seatingArrangement[i][j] = students[k];
            }
        }
    }
    void displaySeatingPlan()
    {
        for (int i = 0; i < numRows; i++)
        {
            for (int j = 0; j < numCols; j++)
            {
                cout << seatingArrangement[i][j].name << endl;
            }
        }
    }
};
int main()
{
    Student John;
    John.setStudentInfo("John Doe", 231234, "123 Main Street", 1234);
    John.displayStudentInfo();
    ExamRoom temp;
    temp.inputStudentRecords(9);
    temp.makeSeatingPlan(3, 3);
    cout << "\nStudents in seating order: \n";
    temp.displaySeatingPlan();
    delete[] temp.students;
    for (int i = 0; i < temp.numRows; i++)
    {
        delete[] temp.seatingArrangement[i];
    }
    delete[] temp.seatingArrangement;
    return 0;
}
