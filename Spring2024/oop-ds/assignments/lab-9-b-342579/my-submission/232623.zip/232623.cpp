#include <iostream>
using namespace std;

class Matrix
{
private:
    int **matrix;
    int row;
    int col;

public:
    Matrix(int row, int col) // Constructor Default
    {
        this->row = row;
        this->col = col;
        matrix = new int *[row];
        for (int i = 0; i < row; i++)
        {
            matrix[i] = new int[col];
            for (int j = 0; j < col; j++)
            {
                matrix[i][j] = 0;
            }
        }
    }

    Matrix(int n1, int n2, int n3, int n4, int row = 2, int col = 2) // Constructor 2D
    {
        this->row = row;
        this->col = col;
        matrix = new int *[row];
        for (int i = 0; i < row; i++)
        {
            matrix[i] = new int[col];
        }
        matrix[0][0] = n1;
        matrix[0][1] = n2;
        matrix[1][0] = n3;
        matrix[1][1] = n4;
    }

    Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int row = 3, int col = 3) // Constructor 3D
    {
        this->row = row;
        this->col = col;
        matrix = new int *[row];
        for (int i = 0; i < row; i++)
        {
            matrix[i] = new int[col];
        }
        matrix[0][0] = n1;
        matrix[0][1] = n2;
        matrix[0][2] = n3;
        matrix[1][0] = n4;
        matrix[1][1] = n5;
        matrix[1][2] = n6;
        matrix[2][0] = n7;
        matrix[2][1] = n8;
        matrix[2][2] = n9;
    }

    Matrix(const Matrix &m) // Copy constructor
    {
        this->row = m.row;
        this->col = m.col;
        matrix = new int *[row];
        for (int i = 0; i < row; i++)
        {
            matrix[i] = new int[col];
            for (int j = 0; j < col; j++)
            {
                matrix[i][j] = m.matrix[i][j];
            }
        }
    }
    int getRow() const // Row Getter
    {
        return row;
    }
    int getCol() const // Col Getter
    {
        return col;
    }

    int getValue(int row, int col) // Matrix Val Getter
    {
        return matrix[row][col];
    }

    int RightDiagonalTotal()
    {
        int sum = 0;
        for (int i = 0; i < row && i < col; i++)
        {
            sum += matrix[i][i];
        }
        return sum;
    }

    int HighestInRow(int row)
    {
        int max = matrix[row][0];
        for (int i = 1; i < col; i++)
        {
            if (matrix[row][i] > max)
            {
                max = matrix[row][i];
            }
        }
        return max;
    }

    Matrix Multiply(Matrix m) // Matrix Multiplication
    {
        if (col != m.row)
        {
            cout << "Matrix dimensions mismatch for multiplication" << endl;
            return Matrix(0, 0); // Return empty matrix
        }

        Matrix result(row, m.col);
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < m.col; j++)
            {
                result.matrix[i][j] = 0;
                for (int k = 0; k < col; k++)
                {
                    result.matrix[i][j] += matrix[i][k] * m.matrix[k][j];
                }
            }
        }
        return result;
    }

    int findkSmallest(int k)
    {
        int *temp = new int[row * col];
        int x = 0;
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                temp[x] = matrix[i][j];
                x++;
            }
        }
        for (int i = 0; i < x - 1; i++)
        {
            for (int j = 0; j < x - 1 - i; j++)
            {
                if (temp[j] > temp[j + 1])
                {
                    int tempVal = temp[j];
                    temp[j] = temp[j + 1];
                    temp[j + 1] = tempVal;
                }
            }
        }
        int smallest = temp[k - 1];
        delete[] temp;
        return smallest;
    }

    Matrix Transpose()
    {
        Matrix trans(col, row);
        for (int i = 0; i < row; i++)
        {
            for (int j = 0; j < col; j++)
            {
                trans.matrix[j][i] = matrix[i][j];
            }
        }
        return trans;
    }

    ~Matrix()
    {
        for (int i = 0; i < row; i++)
        {
            delete[] matrix[i];
        }
        delete[] matrix;
    }
};

int main()
{
    // Test the Matrix class
    Matrix m1(1, 2, 3, 4);                // 2x2 matrix
    Matrix m2(1, 2, 3, 4, 5, 6, 7, 8, 9); // 3x3 matrix
    Matrix m4(4, 3, 2, 1);

    // Test the getRow() and getCol() functions
    cout << "Number of rows in m1: " << m1.getRow() << endl;
    cout << "Number of columns in m1: " << m1.getCol() << endl;
    cout << "Number of rows in m2: " << m2.getRow() << endl;
    cout << "Number of columns in m2: " << m2.getCol() << endl;

    // Test getValue function
    cout << "Value at (0, 0) in m1: " << m1.getValue(0, 0) << endl;
    cout << "Value at (1, 1) in m2: " << m2.getValue(1, 1) << endl;

    // Test RightDiagonalTotal function
    cout << "Right Diagonal Total in m1: " << m1.RightDiagonalTotal() << endl;
    cout << "Right Diagonal Total in m2: " << m2.RightDiagonalTotal() << endl;

    // Test HighestInRow function
    cout << "Highest value in row 0 of m1: " << m1.HighestInRow(0) << endl;
    cout << "Highest value in row 1 of m2: " << m2.HighestInRow(1) << endl;

    // Test Multiply function
    Matrix m3 = m1.Multiply(m4);
    cout << "Result of multiplication:" << endl;
    for (int i = 0; i < m3.getRow(); i++)
    {
        for (int j = 0; j < m3.getCol(); j++)
        {
            cout << m3.getValue(i, j) << " ";
        }
        cout << endl;
    }

    // Test FindkSmallest function
    cout << "3rd smallest element in m1: " << m1.findkSmallest(3) << endl;
    cout << "2nd smallest element in m2: " << m2.findkSmallest(2) << endl;

    // Test Transpose function
    Matrix transposed = m2.Transpose();
    cout << "Transposed matrix m2:" << endl;
    for (int i = 0; i < transposed.getRow(); i++)
    {
        for (int j = 0; j < transposed.getCol(); j++)
        {
            cout << transposed.getValue(i, j) << " ";
        }
        cout << endl;
    }

    return 0;
}
