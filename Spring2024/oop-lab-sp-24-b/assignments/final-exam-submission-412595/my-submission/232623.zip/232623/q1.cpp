#include <iostream>
using namespace std;

// Global Variables/functions not allowed

// Recursive function to calculate the length of a string
int getStringLength(char *inStr)
{ // Default arguments not allowed
    if (*inStr != '\0')
    {
        return 1 + getStringLength(inStr + 1);
    }
    return 0;
}

int main()
{
    // Test cases, don't modify
    string test1 = "123456";
    string test2 = "moyeMoye";
    string test3 = ""; // Empty string
    string test4 = "OOP Lab";
    string test5 = "Recursion is fun!";

    // You can make modifications down here....//
    char test11[] = "123456";
    char test22[] = "moyeMoye";
    char test33[] = "";
    char test44[] = "OOP Lab";
    char test55[] = "Recursion is fun!";

    cout << " String = " << test1 << ", Expected = 6, Your output = " << getStringLength(test11) << endl;
    cout << " String = " << test2 << ", Expected = 8, Your output = " << getStringLength(test22) << endl;
    cout << " String = " << test3 << ", Expected = 0, Your output = " << getStringLength(test33) << endl;
    cout << " String = " << test4 << ", Expected = 7, Your output = " << getStringLength(test44) << endl;
    cout << " String = " << test5 << ", Expected = 17, Your output = " << getStringLength(test55) << endl;

    return 0;
}