#include <iostream>
using namespace std;

// ADD ONE HELPER FUNCTION (RECURSIVE)
void helper(int line)
{
    
}

void pattern(int n /* YOU CAN ADD MAX ONE DEFAULT ARGUMENTS */)
{

    // You can use only one if condition
}

int main()
{
    cout << endl
         << "........Printing for n = 3......." << endl;
    pattern(3);
    cout << endl
         << "........Printing for n = 5........." << endl;
    pattern(5);
    cout << endl
         << "........Printing for n = 7........." << endl;
    pattern(7);
}
