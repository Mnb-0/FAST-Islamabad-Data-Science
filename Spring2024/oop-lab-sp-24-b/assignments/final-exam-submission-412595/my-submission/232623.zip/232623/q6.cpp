#include <iostream>
#include <string>
using namespace std;

class Student
{
    // Following are the two members of Student class, don't add more members
protected:
    string name;
    int age;

public:
    // Constructor
    Student(const string &name, int age) : name(name), age(age) {}
    Student() {}

    // Write Code Below
    virtual void display() = 0;
};

class BachelorStudent : public Student
{
    // Following are the one member of BachelorStudent class, don't add more members
private:
    string major;

public:
    // Constructor
    BachelorStudent(const string &name, int age, const string &major)
        : Student(name, age), major(major) {}

    // Write code below
    void display()
    {
        cout << "Student Type: Bachelor\n";
        cout << "Name " << name << ", Age: " << age << ", Major: " << major;
        cout << endl;
    }
};

class MasterStudent : public Student
{
    // Following are the two members of MasterStudent class, don't add more members
private:
    string researchTopic;
    int researchYears;

public:
    // Constructor
    MasterStudent(const string &name, int age, const string &researchTopic, int researchYears)
        : Student(name, age), researchTopic(researchTopic), researchYears(researchYears) {}

    // Write code below
    void display()
    {
        cout << "Student Type: Master\n";
        cout << "Name " << name << ", Age: " << age << ", Research Topic: " << researchTopic << ", Research Years: " << researchYears;
        cout << endl;
    }
};

class Academy
{
    // Following are the three members of MasterStudent class, don't add more members
private:
    Student *students[4];   // There are only four students, contains both BS and MS students
    int number_of_students; // number_of_students = 4
    int studentCount;       // You can use it as iterator, increment by one(1) after adding a student

public:
    // Parametrized Constructor
    Academy(int number_of_students)
    {
        studentCount = 0; // setting it to zero, because no student has been added yet
        this->number_of_students = number_of_students;
    }

    // Write code below
    void addStudent(string name, int age, string major)
    {
        if (studentCount >= 4)
        {
            cout << "Academy full\n";
            return;
        }
        students[studentCount++] = new BachelorStudent(name, age, major);
    }

    void addStudent(string name, int age, string research, int years)
    {

        if (studentCount >= 4)
        {
            cout << "Academy full\n";
            return;
        }
        students[studentCount++] = new MasterStudent(name, age, research, years);
    }

    void displayStudents()
    {
        for (int i = 0; i < studentCount; i++)
        {
            students[i]->display();
        }
    }
};

int main()
{
    Academy academy(4);

    // Add Bachelor students
    academy.addStudent("Alice", 20, "Computer Science");
    academy.addStudent("Charlie", 21, "Mechanical Engineering");

    // Add Master students
    academy.addStudent("Bob", 25, "Artificial Intelligence", 2);
    academy.addStudent("David", 26, "Data Science", 1);

    // Display all students
    academy.displayStudents();

    return 0;
}