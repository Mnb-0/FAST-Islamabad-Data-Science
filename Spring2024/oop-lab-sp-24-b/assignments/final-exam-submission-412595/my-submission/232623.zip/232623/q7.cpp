#include <iostream>
#include <string>

using namespace std;

class Customer
{
private:
    string name;
    int age;

public:
    // Constructor
    Customer(const string &name, int age) : name(name), age(age) {}
    Customer() : name(""), age(0) {}

    // Getter for name
    string getName() const
    {
        return name;
    }

    // Setter for name
    void setName(const string &newName)
    {
        name = newName;
    }

    // Getter for age
    int getAge() const
    {
        return age;
    }

    // Setter for age
    void setAge(int newAge)
    {
        if (newAge >= 0)
        { // Optional validation to ensure age is non-negative
            age = newAge;
        }
        else
        {
            cout << "Invalid age. Age must be non-negative." << endl;
        }
    }
};

struct Product
{
    string productName;
    double price;

    // Parametrized Constructor
    Product(const string &productName, double price) : productName(productName), price(price) {}

    // Default Constructor
    Product() : productName(""), price(0.0) {}
};

class Order
{
private:
    Customer customer;
    int numberOfItems;
    // Add more members if you want
    Product *product;
    int *quantityProd;
    int iterator;

public:
    // Constructor
    Order(const Customer &customer, int numberOfItems) : customer(customer), numberOfItems(numberOfItems), iterator(0)
    {
        product = new Product[numberOfItems];
        quantityProd = new int[numberOfItems];
    }

    // Destructor to release dynamically allocated memory
    ~Order()
    {
        delete[] product;
        delete[] quantityProd;
    }

    // Function to add an item to the order
    void addItem(const string &productName, double price, int quantity)
    {
        product[iterator].productName = productName;
        product[iterator].price = price;
        quantityProd[iterator] = quantity;
        iterator++;
    }

    // Function to display the order
    void displayOrder() const
    {
        cout << "Customer: " << customer.getName() << endl;
        cout << "Items:" << endl;
        // Write your code below
        // Display the details of all order items
        for (int i = 0; i < numberOfItems; i++)
        {
            cout << "Product: " << product[i].productName << ", Price: $" << product[i].price << ", Quantity: " << quantityProd[i];
            cout << endl;
        }
        cout << endl;
    }
};

int main()
{
    // Create a Customer
    Customer customer("John Doe", 30);

    // Create an Order
    Order order(customer, 2); // 2 is the number of items

    // Add items to the order
    order.addItem("Laptop", 999.99, 2); // name, price and quantity
    order.addItem("Phone", 699.99, 1);

    // Display the order
    order.displayOrder(); // displaying the order

    return 0;
}