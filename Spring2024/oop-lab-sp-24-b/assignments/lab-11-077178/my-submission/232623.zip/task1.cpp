#include <iostream>
using namespace std;

class MathOperations
{
    public:
    
    int add(int a, int b)
    {
        return a + b;
    }

    double add(double a, double b, double c)
    {
        return a+b+c;
    }
};

int main()
{
    MathOperations temp;
    cout<<temp.add(1,1)<<endl;
    cout<<temp.add(1,0.5,0.6);
    return 0;
}