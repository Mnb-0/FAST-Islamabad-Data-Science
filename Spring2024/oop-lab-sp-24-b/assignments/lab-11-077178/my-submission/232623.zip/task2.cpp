#include <iostream>
using namespace std;

class Counter
{
private:
    int count;

public:
    Counter() : count(0) {}

    // Prefix increment operator
    Counter& operator++()
    {
        count++;
        return *this;
    }

    // Postfix increment operator
    Counter operator++(int)
    {
        Counter temp = *this;
        count++;
        return temp;
    }

    int getCount()
    {
        return count;
    }
};

int main()
{
    Counter temp;
    cout << temp.getCount() << endl;
    cout << (temp++).getCount() << endl;
    cout<<temp.getCount()<<endl;
    cout << (++temp).getCount();
    return 0;
}
