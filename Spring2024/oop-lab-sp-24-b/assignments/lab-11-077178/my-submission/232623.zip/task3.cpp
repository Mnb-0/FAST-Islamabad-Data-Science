#include <iostream>
using namespace std;

class Matrix
{
    int matrix[2][2];

public:

        Matrix()
        {
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    matrix[i][j] = 0;
                }
            }
        }

        Matrix(int a)
        {
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    cout<<"Enter an element:\n";
                    cin>>matrix[i][j];
                }
            }
        }

        Matrix operator *(Matrix A)
        {
            Matrix temp;
            for(int i = 0; i < 2; i++)
            {
                for(int j = 0; j < 2; j++)
                {
                    temp.matrix[i][j] = 0;
                    for(int k = 0; k < 2; k++)
                    {
                        temp.matrix[i][j] += this->matrix[i][k] * A.matrix[k][j];
                    }
                }
            }
            return temp;
        }

        void Display()
        {
        	for(int i = 0; i < 2; i++)
        	{
        		for(int j = 0; j < 2; j++)
        		{
        			cout<<matrix[i][j]<<" ";
        		}
        		cout<<endl;
        	}
        }
};

int main()
{
	Matrix A(0);
	Matrix B(1);
	(A*B).Display();
	return 0;
}
