#include <iostream>
using namespace std;

class Vector
{
    int *data;
    int size;

    public:
    
    Vector()
    {
        data = NULL;
        size = 0;
    }

    Vector(int size)
    {
        this->size = size;
        data = new int[size];

    }

    Vector(const Vector& other)
    {
        data = new int[other.size];
        for(int i = 0; i < size; i++)
        {
            data[i] = other.data[i];
        }
    }

    ~Vector()
    {
        delete[] data;
    }

    Vector operator+(Vector& other)
    {   
        //Assuming dimensions of vectors are same
        Vector temp(other.size);
        for(int i = 0; i < other.size; i++)
        {
            temp.data[i] = this->data[i] + other.data[i]; 
        }

        return temp;
    }

    Vector operator-(Vector& other)
    {   
        //Assuming dimensions of vectors are same
        Vector temp(other.size);
        for(int i = 0; i < other.size; i++)
        {
            temp.data[i] = this->data[i] - other.data[i]; 
        }

        return temp;
    }

    int operator*(Vector& other)
    {   
        int scalar = 0;
        //Assuming dimensions of vectors are same
        Vector temp(other.size);
        for(int i = 0; i < other.size; i++)
        {
            temp.data[i] = this->data[i] * other.data[i]; 
        }
        for(int j = 0; j < other.size; j++)
        {
            scalar+=temp.data[j];
        }
        return scalar;
    }

    int operator/(Vector& other)
    {   
        int scalar = 0;
        //Assuming dimensions of vectors are same
        Vector temp(other.size);
        for(int i = 0; i < other.size; i++)
        {
            temp.data[i] = this->data[i] / other.data[i]; 
        }
        for(int j = 0; j < other.size; j++)
        {
            scalar+=temp.data[j];
        }
        return scalar;
    }

    Vector operator+=(Vector& other)
    {
        for(int i = 0; i < other.size; i++)
        {
            this->data[i] += other.data[i];
        }

        return *this;
    }

    Vector operator-=(Vector& other)
    {
        for(int i = 0; i < other.size; i++)
        {
            this->data[i] -= other.data[i];
        }

        return *this;
    }

    bool operator ==(Vector& other)
    {   
        if(this->size != other.size)
        {
            return false;
        }
        for(int i = 0; i < other.size; i++)
        {
            if(this->data[i] != other.data[i])
            {
                return false;
            }
        }
        return true;
    }

    bool operator !=(Vector& other)
    {
        for(int i = 0; i < other.size; i++)
        {
            if(this->data[i] == other.data[i])
            {
                return false;
            }
        }
        return true;
    }
    friend ostream& operator <<(ostream& out, Vector other)
    {   
        cout<<"The Vector is: ";
        for(int i = 0; i<other.size;i++)
        {
            out<<other.data[i];
            cout<<" ";
        }
        return out;
    }

    friend istream& operator >>(istream& in, Vector& other)
    {   
        cout<<"Enter a vector: ";
        for(int i = 0; i<other.size;i++)
        {
            in>>other.data[i];
        }
        return in;
    }
};

int main()
{
    Vector v1(2);
    cin>>v1;
    Vector v2(2);
    cin>>v2;
    cout<<(v1+v2)<<endl;
    cout<<(v1*v2)<<endl;
    cout<<(v1/v2)<<endl;
    Vector v3(2);
    cin>>v3;
    v3+=v1;
    cout<<v3<<endl;


    return 0;
}