#include <iostream>
#include <string>
using namespace std;

class Product
{
    string name;
    float price;

public:
    Product() : name(""), price(0.0) {}
    Product(string name, float price) : name(name), price(price) {}

    string getName() const
    {
        return name;
    }

    float getPrice() const
    {
        return price;
    }
};

class Customer
{

private:
    string name;
    string address;

public:
    Customer() : name(""), address("") {}
    Customer(string name, string address) : name(name), address(address) {}

    string getName() const
    {
        return name;
    }

    string getAddress() const
    {
        return address;
    }
};

class Order
{
    struct OrderItem
    {
        Product *product;
        int quantity;
    };
    Customer customer;
    OrderItem *items;
    int capacity;
    int itemCount;

public:
    Order(const Customer &customer) : customer(customer), capacity(5), itemCount(0)
    {
        items = new OrderItem[capacity];
    }

    ~Order()
    {
        delete[] items;
    }

    void addItem(const Product &product, int quantity)
    {
        if (itemCount < capacity)
        {
            items[itemCount++] = {new Product(product), quantity};
        }
        else
        {
            cout << "Full cart" << endl;
        }
    }

    float totalPrice() const
    {
        float sum = 0.0;
        for (int i = 0; i < itemCount; i++)
        {
            sum += items[i].product->getPrice() * items[i].quantity;
        }
        return sum;
    }

    void displayOrder() const
    {
        cout << "Customer Name: " << customer.getName() << endl;
        for (int i = 0; i < itemCount; i++)
        {
            cout << "Item Ordered: " << items[i].product->getName() << endl;
            cout << "Item Price: " << items[i].product->getPrice() << endl;
            cout << "Quantity: " << items[i].quantity << endl;
        }
        cout << "Total Price: " << totalPrice() << endl;
    }
};

int main()
{
    string name, address;
    int num;
    cout << "Enter customer name: ";
    cin >> name;
    cout << "Enter customer address: ";
    cin >> address;
    cout << "Enter how many items: ";
    cin >> num;
    Customer customer(name, address);
    Order order(customer);

    for (int i = 0; i < num; i++)
    {
        int choice;
        string productName;
        float productPrice;
        int quantity;

        cout << "\nEnter the name of the product: ";
        cin >> productName;
        cout << "Enter the price of the product: ";
        cin >> productPrice;
        cout << "Enter the quantity: ";
        cin >> quantity;

        Product product(productName, productPrice);
        order.addItem(product, quantity);

        order.displayOrder();
    }
    return 0;
}
