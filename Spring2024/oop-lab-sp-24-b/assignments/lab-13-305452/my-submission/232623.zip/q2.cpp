#include <iostream>
#include <string>
using namespace std;

class Course;

struct Student
{
    string name;
    int id;
    Course **courses;

    Student() : name(""), id(0), courses(nullptr) {}
    Student(string name, int id) : name(name), id(id)
    {
        courses = new Course*[2];
    }
    ~Student()
    {
        delete[] courses;
    }
};

class Course
{
private:
    string name;
    int code;
    Student **students;
    int numStudents;

public:
    Course() : name(""), code(0), numStudents(0)
    {
        students = new Student*[2];
    }
    Course(string name, int code) : name(name), code(code), numStudents(0)
    {
        students = new Student*[2];
    }
    ~Course()
    {
        delete[] students;
    }
    void enrollStudent(Student* student)
    {
        if(numStudents >=2 )
        {
            cout<<"No more students can be enrolled."<<endl;
            return;
        }
        students[numStudents++] = student;
        cout<<"Student Enrolled.\n";
    }

    friend ostream& operator <<(ostream& out, Course& course)
    {
        out<<course.name;
        out<<endl;
        out<<course.code;
        out<<endl;
        out<<course.numStudents;
        out<<endl;
        for(int i = 0; i < course.numStudents; i++)
        {
            out<<course.students[i]->name;
            cout<<endl;
        }
        return out;
    }
};

int main()
{
    // Creating students
    Student student1("Shahood", 1001);
    Student student2("Hammad", 1002);
    Student student3("Ali", 1003);

    // Creating courses
    Course course1("Math", 2001);
    Course course2("Physics", 2002);

    // Enrolling students
    course1.enrollStudent(&student1);
    course1.enrollStudent(&student2);
    course2.enrollStudent(&student2);
    course2.enrollStudent(&student3);

    // Displaying course information
    cout << course1 << endl;
    cout << course2 << endl;

    return 0;
}
