#include <iostream>
#include <string>
using namespace std;

class Shape
{
    string color;
    bool filled;

public:
    Shape() : color("red"), filled(true) {}

    Shape(string color, bool filled) : color(color), filled(filled) {}

    string getColor() const { return color; }

    bool isFilled() const { return filled; }

    void setColor(string color)
    {
        this->color = color;
    }

    void setFilled(bool filled)
    {
        this->filled = filled;
    }

    string toString()
    {
        string temp2;
        if (filled)
        {
            temp2 = "Filled";
        }
        else
        {
            temp2 = "Not Filled";
        }
        string temp = "A shape with color of " + color + " and " + temp2;
        return temp;
    }
};

class Circle : public Shape
{
    double radius;

public:
    Circle() : radius(1.0) {}

    Circle(double radius) : radius(radius) {}

    double getRadius() const { return radius; }

    void setRadius(double radius)
    {
        this->radius = radius;
    }

    double getArea() const { return 3.14 * radius * radius; }

    double getPerimeter() const { return 2 * radius * 3.14; }

    string toString()
    {
        string temp = "A circle with radius " + to_string(radius) + ", which is a subclass of " + Shape::toString();
        return temp;
    }
};

class Rectangle : public Shape
{
    double width;
    double length;

public:
    Rectangle() : width(1.0), length(1.0) {}

    Rectangle(double width, double length) : width(width), length(length) {}

    double getWidth() const { return width; }

    double getLength() const { return length; }

    void setWidth(double width)
    {
        this->width = width;
    }

    void setLength(double length)
    {
        this->length = length;
    }

    double getArea()
    {
        return width * length;
    }

    double getPerimeter()
    {
        return 2 * (width + length);
    }

    string toString()
    {
        string temp = "A rectangle with width " + to_string(width) + " and length " + to_string(length) + ", which is a subclass of " + Shape::toString();
        return temp;
    }
};

class Square : public Rectangle
{
public:
    Square() {}

    double getSide() const { return Rectangle::getWidth(); }

    void setSide(double side)
    {
        Rectangle::setLength(side);
        Rectangle::setWidth(side);
    }
    void setWidth(double side)
    {
        Rectangle::setWidth(side);
    }

    void setLength(double side)
    {
        Rectangle::setLength(side);
    }

    string toString()
    {
        string temp = "A square with side " + to_string(getSide()) + ", which is a subclass of " + Rectangle::toString();
        return temp;
    }
};

int main()
{
    Shape shape1;
    Circle circle1(3.5);
    Rectangle rectangle1(2.5, 4.5);
    Square square1;

    cout << "Shape: " << shape1.toString() << endl;
    cout << "Circle: " << circle1.toString() << endl;
    cout << "Rectangle: " << rectangle1.toString() << endl;
    cout << "Square: " << square1.toString() << endl;

    return 0;
}