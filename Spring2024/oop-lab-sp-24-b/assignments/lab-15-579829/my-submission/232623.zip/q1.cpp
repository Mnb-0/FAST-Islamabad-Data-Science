#include <iostream>
using namespace std;

const double pi = 3.14159;
class BasicShape
{
protected:
    double area;

public:
    double getArea() const { return area; }

    virtual void calcArea() = 0;
};

class Circle : virtual public BasicShape
{
private:
    long int centreX;
    long int centreY;
    double radius;

public:
    Circle() : centreX(0), centreY(0), radius(0) {}

    Circle(long int centreX, long int centreY, double radius) : centreX(centreX), centreY(centreY), radius(radius) {}

    long int getCentreX() const { return centreX; }

    long int getCentreY() const { return centreY; }

    void calcArea() override
    {
        area = pi * radius * radius;
    }
};

class Rectangle : virtual public BasicShape
{

private:
    long int width;
    long int length;

public:
    Rectangle() : width(0), length(0) {}

    Rectangle(long int width, long int length) : width(width), length(length) {}

    long int getWidth() const { return width; }

    long int getLength() const { return length; }

    void calcArea() override
    {
        area = length * width;
    }
};
int main()
{
    const int size = 4;
    BasicShape *shapes[size];

    shapes[0] = new Circle(2, 3, 5.0);
    shapes[1] = new Circle(-1, 2, 3.5);

    shapes[2] = new Rectangle(4, 6);
    shapes[3] = new Rectangle(5, 5);

    for (int i = 0; i < size; ++i)
    {
        shapes[i]->calcArea();
        cout << "Area: " << shapes[i]->getArea() << endl;
    }

    for (int i = 0; i < size; ++i)
    {
        delete shapes[i];
    }

    return 0;
}