#include<iostream>
using namespace std;

/*
    returns length of a string
*/
int getStringLength(string str) { 
    int characterCount = 0;
    for (int i = 0; str[i]!= '\0'; i++,characterCount++);
    return characterCount;
}

/*
    returns the reversed string, 
    test this function before using it
*/
string reverseString(string word) {
    int wordLength = getStringLength(word); 
    for (int i = 0,j =  wordLength - 1; i<wordLength/2; i++,j--){
        char temp = word[i];
        word[i] = word[j];
        word[j] = temp;
    }
    return word;
}

void reverseWords(string sentence) 
{

    int len = getStringLength(sentence);
    string word;
    for (int i = 0; i < len; i++) 
    {
        if (sentence[i] == ' ' || i == len - 1) 
        {

            if (i == len - 1) 
            {
                word += sentence[i];
            }
            cout << reverseString(reverseString(word)) << " ";
            word = "";
        } 
        else 
        {
            word += sentence[i];
        }
    }
}

int main(){
    cout << endl <<"Expected Output: " << "programming learning am I" << endl << "Your Output = ";
    reverseWords(("I am learning programming"));
    cout << endl;

    cout << endl <<"Expected Output: " << "Solution Practice Excercise" << endl << "Your Output = ";
    reverseWords(("Excercise Practice Solution"));
    cout << endl << endl;
}
