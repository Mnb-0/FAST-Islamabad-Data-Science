#include<iostream>
using namespace std;

/*
    No more Helper Function
*/
void printCharacter(char character, int count, int iterator = 1) {
    if (iterator > count) {
        return;
    }
    cout << character;
    printCharacter(character,count,iterator+1);
}

/* 
    arg1 & arg2 as an argument names is not meaningful. Give different names to the arguments if you want
*/
void pattern(int arg1, int arg2 = /*someting*/) {
    if (/* anything*/) {   // No more conditional statement
        
    }
}

int main(){
    cout << endl << "........Printing for 5.......\n" << endl;
    pattern(5);
    cout << endl << "........Printing for 7.........\n" << endl;
    pattern(7);
    cout << endl << "........Printing for 9.........\n" << endl;
    pattern(9);
}