#include<iostream>
using namespace std;

/*
    returns length of a string
*/
int getStringLength(string str) { 
    int characterCount = 0;
    for (int i = 0; str[i]!= '\0'; i++,characterCount++);
    return characterCount;
}
int wordCounter(string sentence, int wordCount , int i = 0)
{
    if(i <= getStringLength(sentence))
    {
        if(sentence[i] == ' ' || i == getStringLength(sentence))
        {
            wordCount+=1;
        }
        wordCounter(sentence,wordCount,i + 1);
        return wordCount;
    }
    
}
string construct(string sentence, string replace, string replaceWith, string final, int i = 0)
{
    if(i > wordCounter(sentence,0,0))
    {
        return sentence;
    }
    if(sentence[i] == 'L');
}

/*
    you can add default arguments
    you can add helper functions
    Use recursion only
*/
string replaceSubString(string sentence, string replace, string replaceWith) {   

    if(getStringLength(sentence) > -1)
    {
        return sentence;
    }
    if(sentence[getStringLength(sentence)]);
    
}

int main(){

    /*
    DO NOT MODIFY THIS FUNCTION 
    */
    cout<<endl<<wordCounter("Meow xd xd",0,0)<<endl;
    cout <<endl<< "Expected Output = " << "Mental Health, pani ma gai, Chapaak" << endl;
    cout << "Your Output = "; 
    cout << replaceSubString("Aik machli, pani ma gai, Chapaak","Aik machli","Mental Health");
    cout <<endl<<endl;    

    cout << "Expected Output = " << "Welcome to Ammar Masood Lab" << endl;
    cout << "Your Output = "; 
    cout << replaceSubString("Welcome to OOP Lab","OOP","Ammar Masood");
    cout <<endl<<endl; 

    cout << "Expected Output = " << "pak..pakpak..pakistan.pak.pak" << endl;
    cout << "Your Output = "; 
    cout << replaceSubString("#..##..#istan.#.#","#","pak");
    cout <<endl<<endl; 

    /*
    DO NOT MODIFY 
    */
}