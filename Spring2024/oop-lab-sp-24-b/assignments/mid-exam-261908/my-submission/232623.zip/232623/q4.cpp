#include <iostream>
using namespace std;

class Matrix {
private:
    int **matrix;             // Double pointer to create a 2D array (matrix)
    int row;                 // Number of rows in the matrix
    int col;                // Number of columns in the matrix
    string matrixName;     // Name of matrix A,B,C..

public:

    
    /*
    Allocating the memory dynamocally for 2d array(**matrix), you can call this function in constructor
    */
    void allocateMemory()
    {
        matrix = new int *[row];
        for (int i = 0; i < row; ++i)
        {
            matrix[i] = new int[col];
        }
    }
    Matrix(int row, int col, string matrixName) {//Constructor
        this->row = row;
        this->col = col;
        this->matrixName = matrixName;
        allocateMemory();
        initalizeMatrix();
    }
    /*
    Destructor to deallocate the memory
    */
    ~Matrix() { 
        for (int i = 0; i < row; ++i) {
            delete[] matrix[i];
        }
        delete[] matrix;
    }

    /*
    Initializing the values to the 2D array (matrix), you can call this function in constructor
    */
    void initalizeMatrix() {
        int number = 1;
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                matrix[i][j] = number++;
            }
        }
    }

    /*
    Dispaying the values of 2D array (matrix)
    */
    void displayMatrix() {
        cout << this->matrixName << " Matrix: " << endl;
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                cout << matrix[i][j] << " ";
            }
            cout << endl;
        }
        cout<<endl;
    }

    Matrix Multiply(Matrix m2) {
        if (this->col != m2.row) {
            cout << "Matrix multiplication is not possible due to row/col mismatch. Returning Parameter Matrix" << endl;
            return *this;
        }
        Matrix result(this->row, m2.col, "Multiplied");
        for(int i = 0; i < this->row;i++)
        {
            for(int j = 0; j < m2.col;j++)
            {
                result.matrix[i][j] = 0;
            }

        }
        for(int i = 0; i < (this->row) - 1; i++) 
        {
            for(int j = 0; j < (m2.col) - 1; j++) 
            {
                for(int k = 0; k < (this->col); k++) 
                {

                    result.matrix[i][j] = result.matrix[i][j] +  (this->matrix[i][k] * m2.matrix[k][j]);
                }
            }
        }
        
        return result;
    }

    Matrix Transpose() {
        Matrix result(this->col, this->row, "Transposed");
        for (int i = 0; i < this->row; ++i) {
            for (int j = 0; j < this->col; ++j) {
                result.matrix[j][i] = this->matrix[i][j];
            }
        }
        return result;
    }

};
int main() {
    Matrix m1(2, 3, "M1");
    Matrix m2(3, 5, "M2");

    m1.displayMatrix();
    m2.displayMatrix();

    Matrix m3 = m1.Multiply(m2); // multiplying two matrices
    m3.displayMatrix();

    Matrix m4 = m3.Transpose();  // transpose of the matrix
    m4.displayMatrix(); 
    
}
