#include <iostream>
using namespace std;

// ADD ONE HELPER FUNCTION (RECURSIVE)
void helper(int line)
{
     if (line == 0)
          return;
     else
     {
          cout << " ";
          helper(line - 1);
     }
}

void pattern(int n, int i = 1 /* YOU CAN ADD MAX ONE DEFAULT ARGUMENTS */)
{

     if (i == n + 1)
          return;
     else
     {
          helper(n - i);
          cout << "*";
          helper((i - 1) * 2);
          cout << "*";
          cout << endl;
          pattern(n, i + 1);
          helper(n - i);
          cout << "O";
          helper((i - 1) * 2);
          cout << "O";
          cout << endl;
     }
}

int main()
{
     cout << endl
          << "........Printing for n = 3......." << endl;
     pattern(3);
     cout << endl
          << "........Printing for n = 5........." << endl;
     pattern(5);
     cout << endl
          << "........Printing for n = 7........." << endl;
     pattern(7);
}
