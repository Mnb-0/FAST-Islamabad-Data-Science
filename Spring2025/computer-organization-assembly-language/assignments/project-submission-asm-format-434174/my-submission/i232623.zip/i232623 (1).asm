; player.asm - Responsible for drawing Pac-Man, updating position,
;              and tracking the score when pellets are collected

INCLUDE Irvine32.inc

PUBLIC DrawPlayer, UpdatePlayer, UpdateScore

.data
xPos BYTE ?                    ; This is where the player is on the X-axis
yPos BYTE ?                    ; This is the player's position on the Y-axis
Xcoordinates db 3332 dup(-1)  ; Stores X positions for all coins/pellets
Ycoordinates db 3332 dup(-1)  ; Stores Y positions for all coins/pellets
score dw ?                    ; Keeps track of how many pellets we’ve eaten
player BYTE 'X'              ; The character representing the player
.code

; ---------------------------------------------------------------
; DrawPlayer - This draws the player character (an 'X') on screen
;              at their current position with yellow color
; ---------------------------------------------------------------
DrawPlayer PROC
    mov eax, yellow             ; Make the player appear yellow
    call SetTextColor

    mov dl, xPos                ; Load player's current X
    mov dh, yPos                ; Load player's current Y
    call Gotoxy                 ; Move cursor to the player’s spot

    mov al, 'X'                 ; Our player is shown as 'X'
    call WriteChar              ; Actually display the character
    ret
DrawPlayer ENDP

; -------------------------------------------------------------------
; UpdatePlayer - This erases the player from their old spot
;                so we don’t leave a trail behind while moving
; -------------------------------------------------------------------
UpdatePlayer PROC
    mov dl, xPos
    mov dh, yPos
    call Gotoxy

    mov al, ' '                 ; Replace 'X' with space to erase
    call WriteChar
    ret
UpdatePlayer ENDP

; ----------------------------------------------------------------------------
; UpdateScore - Checks if player is standing on a pellet.
;               If yes, we "eat" the pellet and increase score by 1.
; ----------------------------------------------------------------------------
UpdateScore PROC
    mov esi, OFFSET Xcoordinates   ; Start looping through X list
    mov edi, OFFSET Ycoordinates   ; Start looping through Y list
    mov ecx, LENGTHOF Xcoordinates ; Total number of pellets (3332)

checkLoop:
    mov al, [edi]       ; Get current pellet's Y coordinate
    mov ah, [esi]       ; Get current pellet's X coordinate
    inc esi             ; Move to next X
    inc edi             ; Move to next Y
    cmp al, yPos        ; Is player's Y same as this pellet?
    jne skip            ; If not, skip this one
    cmp ah, xPos        ; Is X also same?
    je increment        ; If both match, we got a pellet!
skip:
    loop checkLoop      ; Keep checking all pellets
    ret

increment:
    dec edi             ; Go back to current pellet Y
    dec esi             ; Go back to current pellet X
    mov al, -1          ; Mark it as removed (we use -1 for deleted)
    mov [esi], al
    mov [edi], al
    inc score           ; Yay! We got one point.
    ret
UpdateScore ENDP

END
