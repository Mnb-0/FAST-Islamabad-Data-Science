; pause.asm - Handles the Pause Screen Logic for the Game
; This file lets the player pause the game anytime, and gives the choice
; to either continue playing or quit from the pause screen.

INCLUDE Irvine32.inc

PUBLIC ShowPauseScreen

.data
pauseMsg db 'PAUSED - Press Enter to Resume or ESC to Exit', 0  ; Pause message
pauseScreen         db'                 $$$$$$$\  $$$$$$$$\  $$$$$$\  $$\   $$\ $$\      $$\ $$$$$$$$\ ',13,10
                    db'                 $$  __$$\ $$  _____|$$  __$$\ $$ |  $$ |$$$\    $$$ |$$  _____|',13,10
                    db'                 $$ |  $$ |$$ |      $$ /  \__|$$ |  $$ |$$$$\  $$$$ |$$ |      ',13,10
                    db'                 $$$$$$$  |$$$$$\    \$$$$$$\  $$ |  $$ |$$\$$\$$ $$ |$$$$$\    ',13,10
                    db'                 $$  __$$< $$  __|    \____$$\ $$ |  $$ |$$ \$$$  $$ |$$  __|   ',13,10
                    db'                 $$ |  $$ |$$ |      $$\   $$ |$$ |  $$ |$$ |\$  /$$ |$$ |      ',13,10
                    db'                 $$ |  $$ |$$$$$$$$\ \$$$$$$  |\$$$$$$  |$$ | \_/ $$ |$$$$$$$$\ ',13,10
                    db'                 \__|  \__|\________| \______/  \______/ \__|     \__|\________|',13,10
                    db'                                                                                ',13,10
                    db'                                                                                ',13,10
                    db'                                                                                ',13,10
                    db'                             $$$$$$$$\ $$\   $$\ $$$$$$\ $$$$$$$$\              ',13,10
                    db'                             $$  _____|$$ |  $$ |\_$$  _|\__$$  __|             ',13,10
                    db'                             $$ |      \$$\ $$  |  $$ |     $$ |                ',13,10
                    db'                             $$$$$\     \$$$$  /   $$ |     $$ |                ',13,10
                    db'                             $$  __|    $$  $$<    $$ |     $$ |                ',13,10
                    db'                             $$ |      $$  /\$$\   $$ |     $$ |                ',13,10
                    db'                             $$$$$$$$\ $$ /  $$ |$$$$$$\    $$ |                ',13,10
                    db'                             \________|\__|  \__|\______|   \__|                ',13,10
                    db 0


.code

; -----------------------------------------------------------------
; ShowPauseScreen - Clears the screen and shows the pause message.
;                   Waits for the player to press Enter or Escape.
; -----------------------------------------------------------------
ShowPauseScreen PROC
    call Clrscr                      ; Clear everything first

    mov dl, 20                       ; Set X coordinate (column)
    mov dh, 10                       ; Set Y coordinate (row)
    call Gotoxy                      ; Move cursor to (20,10)

    mov edx, OFFSET pauseMsg         ; Load the pause message
    call WriteString                 ; Show it on screen

waitInput:
    call ReadChar                    ; Wait for player to press a key

    cmp al, 27                       ; If ESC key (ASCII 27), quit game
    je forceExit

    cmp al, 13                       ; If Enter key, go back to game
    je resumeGame

    jmp waitInput                    ; If any other key, keep waiting

forceExit:
    call ExitProcess                 ; Quit the whole game (for now)
                                     ; Optional: link to your proper game over logic

resumeGame:
    call Clrscr                      ; Clear pause message before returning
    ret
ShowPauseScreen ENDP

END
