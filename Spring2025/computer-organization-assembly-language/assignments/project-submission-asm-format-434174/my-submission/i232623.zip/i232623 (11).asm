; sound.asm - Handles all the game sounds using Winmm.lib
; This file plays different audio effects for various game actions.

INCLUDE Irvine32.inc
INCLUDELIB Winmm.lib           ; Links in the Windows multimedia library

PUBLIC PlayChompSound, PlayDeathSound, PlayIntroMusic, PlayPelletSound

PlaySound PROTO :PTR BYTE, :DWORD, :DWORD

.const
SND_FILENAME DWORD 00020000h

.data
file        BYTE "pacman_chomp.wav", 0           ; Used for chomp sound
musicDeath  BYTE "pacman_death.wav", 0           ; Played when Pac-Man dies
musicIntro  BYTE "pacman_beginning.wav", 0       ; Intro music on game launch
pelletfile  BYTE "pacman_chomp.wav", 0           ; Optional: reuse chomp for pellet

.code

; ----------------------------------------
; PlayChompSound
; Called when Pac-Man eats a pellet
; ----------------------------------------
PlayChompSound PROC
    INVOKE PlaySound, OFFSET file, NULL, SND_FILENAME
    ret
PlayChompSound ENDP

; ----------------------------------------
; PlayDeathSound
; Called when Pac-Man is caught by a ghost
; ----------------------------------------
PlayDeathSound PROC
    INVOKE PlaySound, OFFSET musicDeath, NULL, SND_FILENAME
    ret
PlayDeathSound ENDP

; ----------------------------------------
; PlayIntroMusic
; Plays when the game first starts
; ----------------------------------------
PlayIntroMusic PROC
    INVOKE PlaySound, OFFSET musicIntro, NULL, SND_FILENAME
    ret
PlayIntroMusic ENDP

; ----------------------------------------
; PlayPelletSound
; ----------------------------------------
PlayPelletSound PROC
    INVOKE PlaySound, OFFSET pelletfile, NULL, SND_FILENAME
    ret
PlayPelletSound ENDP

END
