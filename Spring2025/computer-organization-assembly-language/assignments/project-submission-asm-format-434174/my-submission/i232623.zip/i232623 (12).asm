; game.asm - Entry Point and Main Game Flow Control

INCLUDE Irvine32.inc
INCLUDE constants.inc ;containts main constants, mazes, etc
EXTERN InitGame:PROC
EXTERN HandleMenuInput:PROC
EXTERN ExitGame:PROC

.code
main PROC
    call InitGame         ; screen and name input
    call HandleMenuInput  ; Menu loop and input handling
    call ExitGame
    exit
main ENDP

END main
