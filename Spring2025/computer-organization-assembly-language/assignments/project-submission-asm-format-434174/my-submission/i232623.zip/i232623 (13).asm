; menu.asm - Main Menu Logic
; This file handles showing the menu and letting the player choose what to do.

INCLUDE Irvine32.inc

; Pulling in functions from other files
EXTERN ShowInstructions:PROC
EXTERN StartLevelOne:PROC
EXTERN ExitGame:PROC

; These are the strings for menu items defined elsewhere
EXTERN START:BYTE
EXTERN INSTRUCTIONS:BYTE
EXTERN EXITED:BYTE

.data
selectedOption BYTE 1                     ; By default, highlight option 1
arrowMsg BYTE '  <---------------   ',13,10,0  ; Arrow to show current selection

START             DB '                                               ___ ___ ___ ___ ___   ',13,10
                  DB '                                              / __|_ _| . | . |_ _|  ',13,10
                  DB '                                              \__ \| ||   |   /| |   ',13,10
                  DB '                                              <___/|_||_|_|_\_\|_|   ',13,10
                  DB 0   

INSTRUCTIONS    DB '                                     _ _ _ ___ ___ ___ _ _ ___ ___ _ ___ _ _ ___ ',13,10
                DB '                                    | | \ / __|_ _| . | | |  _|_ _| | . | \ / __>',13,10
                DB '                                    | |   \__ \| ||   |   | <__| || | | |   \__ \',13,10
                DB '                                    |_|_\_<___/|_||_\_`___`___/|_||_`___|_\_<___/',13,10
                DB 0
            
EXITED           DB '                                                  _____  _ _ ___   ',13,10
                 DB '                                                 | __\ \/ | |_ _|  ',13,10
                 DB '                                                 | _> \ \ | || |   ',13,10
                 DB '                                                 |____/\_\|_||_|   ',13,10
                 DB 0
                                           


.code

; ----------------------------------------
; HandleMenuInput - Main loop for menu
; ----------------------------------------
HandleMenuInput PROC
    call RenderMenuLoop
    ret
HandleMenuInput ENDP

; ----------------------------------------
; RenderMenuLoop - Keeps redrawing and checking keypresses
; ----------------------------------------
RenderMenuLoop PROC
menu_loop:
    call RenderMenu            ; Show the menu
    call ReadChar              ; Wait for a key

    cmp al, '1'
    je SelectOption1
    cmp al, '2'
    je SelectOption2
    cmp al, '3'
    je SelectOption3
    cmp al, 13                 ; ENTER key
    je ProceedOption

    jmp menu_loop              ; Loop again if input not handled

SelectOption1:
    mov selectedOption, 1
    jmp menu_loop

SelectOption2:
    mov selectedOption, 2
    jmp menu_loop

SelectOption3:
    mov selectedOption, 3
    jmp menu_loop

; Based on selection, jump to the actual action
ProceedOption:
    cmp selectedOption, 1
    je StartLevelOne
    cmp selectedOption, 2
    je ShowInstructions
    cmp selectedOption, 3
    je ExitGame
    jmp menu_loop
RenderMenuLoop ENDP

; ----------------------------------------
; RenderMenu - Draws the menu + highlights current choice
; ----------------------------------------
RenderMenu PROC
    call Clrscr               ; Clear screen first

    ; Show all 3 options (START, INSTRUCTIONS, EXIT)
    mov dl, 0
    mov dh, 1
    mov edx, OFFSET START
    call Gotoxy
    call WriteString

    mov dl, 0
    mov dh, 10
    mov edx, OFFSET INSTRUCTIONS
    call Gotoxy
    call WriteString

    mov dl, 0
    mov dh, 20
    mov edx, OFFSET EXITED
    call Gotoxy
    call WriteString

    ; Show the arrow pointing to current selection
    cmp selectedOption, 1
    jne skip_arrow1
    mov dl, 70
    mov dh, 3
    mov edx, OFFSET arrowMsg
    call Gotoxy
    call WriteString
skip_arrow1:

    cmp selectedOption, 2
    jne skip_arrow2
    mov dl, 80
    mov dh, 12
    mov edx, OFFSET arrowMsg
    call Gotoxy
    call WriteString
skip_arrow2:

    cmp selectedOption, 3
    jne skip_arrow3
    mov dl, 70
    mov dh, 22
    mov edx, OFFSET arrowMsg
    call Gotoxy
    call WriteString
skip_arrow3:

    ret
RenderMenu ENDP

END
