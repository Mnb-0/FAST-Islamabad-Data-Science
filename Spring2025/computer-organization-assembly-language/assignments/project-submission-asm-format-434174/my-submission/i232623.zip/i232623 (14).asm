; level2.asm - This file runs Level 2 of the game.
; It's pretty much like Level 1 but can be changed later to add difficulty.
; Manages player input, ghost movement, coins, score, lives, and sounds.

INCLUDE Irvine32.inc

; Bringing in functions from other files
EXTERN DrawPlayer:PROC
EXTERN UpdatePlayer:PROC
EXTERN UpdateScore:PROC
EXTERN DrawCoin:PROC
EXTERN CreateRandomCoin:PROC
EXTERN WallCollision:PROC
EXTERN UpdateCoin:PROC
EXTERN updateGhost:PROC
EXTERN ExitGame:PROC

PUBLIC StartLevelTwo  ; Renamed from StartLevelOne to avoid confusion

.data
xPos BYTE 32                    ; Player starting X position
yPos BYTE 14                    ; Player starting Y position
inputChar BYTE ?                ; Stores the key that was pressed
xCoinPos BYTE ?                 ; Coin’s X position
yCoinPos BYTE ?                 ; Coin’s Y position
lives db 3                      ; Player starts with 3 lives
score dw 0                      ; Player’s score at the beginning

file BYTE "pacman_chomp.wav",0        ; Sound when player moves
musicDeath BYTE "pacman_death.wav",0  ; Unused here but ready

livesMsg db "Lives:",0
strScore db "Apka Kaam: ",0
names db 20 dup(32)                    ; Name of player (max 20 chars)
strName db "Apka Naam:",0

.code

; -----------------------------------------------------
; StartLevelTwo - Starts the main loop for level 2
; -----------------------------------------------------
StartLevelTwo PROC
    call DrawCoin                 ; Draw all coins on screen

Level2Loop:
    call updateGhost             ; Move the ghost
    call HandleCoinCollision     ; Check if coin is collected
    call DrawHUD                 ; Show score, name, and lives
    call UpdatePlayer            ; Clear old player position
    call DrawPlayer              ; Draw new player position
    call DelayFrame              ; Delay for smoother motion
    call ReadKeyInput            ; Get keyboard input
    jmp Level2Loop               ; Repeat the loop
StartLevelTwo ENDP

; -----------------------------------------------------
; DrawHUD - Displays score, name, and how many lives are left
; -----------------------------------------------------
DrawHUD PROC
    mov eax, white
    call SetTextColor

    ; Draw score
    mov dl, 0
    mov dh, 0
    call Gotoxy
    mov edx, OFFSET strScore
    call WriteString
    movzx eax, score
    call WriteInt

    ; Draw name label and player name
    mov dl, 20
    call Gotoxy
    mov edx, OFFSET strName
    call WriteString
    mov dl, 30
    call Gotoxy
    mov edx, OFFSET names
    call WriteString

    ; Draw lives (each life shown with a $ sign)
    mov dl, 110
    mov dh, 0
    call Gotoxy
    mov edx, OFFSET livesMsg
    call WriteString

    mov dl, 116
    call Gotoxy
    mov al, '$'
    movzx ecx, lives
DrawLife:
    call WriteChar
    loop DrawLife
    ret
DrawHUD ENDP

; -----------------------------------------------------
; HandleCoinCollision - If we touch the coin, score up!
; -----------------------------------------------------
HandleCoinCollision PROC
    mov al, xPos
    cmp al, xCoinPos
    jne skipCoin
    mov al, yPos
    cmp al, yCoinPos
    jne skipCoin

    ; We collected the coin
    inc score
    call CreateRandomCoin
    call DrawCoin
skipCoin:
    ret
HandleCoinCollision ENDP

; -----------------------------------------------------
; DelayFrame - Adds delay between frames to control speed
; -----------------------------------------------------
DelayFrame PROC
    mov eax, 400
    call Delay
    ret
DelayFrame ENDP

; -----------------------------------------------------
; ReadKeyInput - Handles input (WASD to move, X to quit)
; -----------------------------------------------------
ReadKeyInput PROC
    call ReadKey
    jz noInput               ; If nothing pressed, skip

    mov inputChar, al
    cmp inputChar, 'x'
    je ExitGame
    cmp inputChar, 'w'
    je MoveUp
    cmp inputChar, 's'
    je MoveDown
    cmp inputChar, 'a'
    je MoveLeft
    cmp inputChar, 'd'
    je MoveRight
noInput:
    ret
ReadKeyInput ENDP

; -----------------------------------------------------
; Movement functions (play sound + move position)
; -----------------------------------------------------
MoveUp PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    dec yPos
    call UpdateScore
    ret
MoveUp ENDP

MoveDown PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    inc yPos
    call UpdateScore
    ret
MoveDown ENDP

MoveLeft PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    dec xPos
    call UpdateScore
    ret
MoveLeft ENDP

MoveRight PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    inc xPos
    call UpdateScore
    ret
MoveRight ENDP

END
