; coin.asm - Handles coin (dot) drawing, updating, and random placement

INCLUDE Irvine32.inc

PUBLIC DrawCoin, CreateRandomCoin, UpdateCoin

EXTERN xCoinPos:BYTE
EXTERN yCoinPos:BYTE

.data
Xcoordinates db 3332 dup(-1)     ; Stores X positions for all coins
Ycoordinates db 3332 dup(-1)     ; Stores Y positions for all coins
loopVarCoin db 30                ; Used for column looping
groundChar BYTE '.'              ; The visual for a coin dot

.code

; DrawCoin
; This fills the screen with rows of dots ('.') to act as collectible coins.
; We track their positions so we can update/remove them later.
DrawCoin PROC
    mov eax, green               ; Coins will show in green
    call SetTextColor

    mov dh, 1                    ; Start one row down (leave space for HUD)
    mov al, groundChar
    mov ecx, 27                  ; Number of rows
    mov ah, 118                  ; Number of columns per row

    mov edi, OFFSET Xcoordinates ; X tracker
    mov esi, OFFSET Ycoordinates ; Y tracker

drawRow:
    inc dh                      ; Move to next row
    mov dl, 0                   ; Start each row from column 0
    mov loopVarCoin, ah         ; Set up loop counter for columns

drawCol:
    inc dl
    call Gotoxy
    mov [esi], dh               ; Store Y
    mov [edi], dl               ; Store X
    inc esi
    inc edi
    call WriteChar              ; Draw the dot
    dec loopVarCoin
    cmp loopVarCoin, 0
    jne drawCol                 ; Repeat for next dot
    loop drawRow                ; Go to next row
    ret
DrawCoin ENDP

; CreateRandomCoin
; After a coin is collected, this spawns another one at a random spot.
CreateRandomCoin PROC
    mov eax, 55                 ; Limit X position range
    inc eax                     ; To avoid hitting exact borders
    call RandomRange
    mov xCoinPos, al
    mov yCoinPos, 27            ; Keep Y fixed at bottom row
    ret
CreateRandomCoin ENDP

; UpdateCoin
; Refreshes the screen to show collected coins as blank space,
; and leaves uncollected coins visible.
UpdateCoin PROC
    mov eax, red                ; Use red color for update effect
    call SetTextColor

    mov esi, OFFSET Xcoordinates
    mov edi, OFFSET Ycoordinates
    mov ecx, 3186               ; Total number of coin positions saved

updateLoop:
    mov dl, [esi]               ; Get stored X
    mov dh, [edi]               ; Get stored Y
    call Gotoxy

    cmp dl, -1                  ; Was this dot already collected?
    je eraseSpace
    mov al, '.'                 ; Still active? Keep it as dot
    jmp drawIt
eraseSpace:
    mov al, ' '                 ; Otherwise, show empty space
drawIt:
    call WriteChar
    inc esi
    inc edi
    loop updateLoop
    ret
UpdateCoin ENDP

END
