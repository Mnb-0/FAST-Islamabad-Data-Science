; level3.asm - This handles Level 3 gameplay logic.
; Adds extra ghosts for more challenge. Everything else works like before.

INCLUDE Irvine32.inc

; Bring in stuff we already wrote somewhere else
EXTERN DrawPlayer:PROC
EXTERN UpdatePlayer:PROC
EXTERN UpdateScore:PROC
EXTERN CreateRandomCoin:PROC
EXTERN DrawCoin:PROC
EXTERN updateGhost2:PROC
EXTERN updateInky:PROC
EXTERN updateClyde:PROC
EXTERN ExitGame:PROC

PUBLIC StartLevelThree

.data
xPos BYTE 1                 ; Player starting X
yPos BYTE 2                 ; Player starting Y
xCoinPos BYTE ?             ; Coin X location
yCoinPos BYTE ?             ; Coin Y location
score dw 0                  ; Initial score
lives db 3                  ; Player has 3 lives at start
file BYTE "pacman_chomp.wav",0  ; Movement sound

.code

; -----------------------------------------------------
; StartLevelThree - Core game loop for Level 3
; -----------------------------------------------------
StartLevelThree PROC
    call CreateRandomCoin      ; Place a coin somewhere
    call DrawCoin              ; Draw the coin on screen

Level3Loop:
    call updateGhost2          ; Ghost 1 movement
    call updateInky            ; Ghost 2 (Inky) movement
    call updateClyde           ; Ghost 3 (Clyde) movement

    call CheckCoinCollision3   ; See if coin is picked up
    call UpdatePlayer          ; Erase old player pos
    call DrawPlayer            ; Draw player at new pos

    call DelayFrame            ; Wait so game isn’t too fast
    call ReadKeyInput3         ; Check keypress
    jmp Level3Loop             ; Loop again
StartLevelThree ENDP

; -----------------------------------------------------
; CheckCoinCollision3 - If coin collected, make a new one
; -----------------------------------------------------
CheckCoinCollision3 PROC
    mov al, xPos
    cmp al, xCoinPos
    jne skip3
    mov al, yPos
    cmp al, yCoinPos
    jne skip3

    ; Coin collected!
    inc score
    call CreateRandomCoin
    call DrawCoin
skip3:
    ret
CheckCoinCollision3 ENDP

; -----------------------------------------------------
; ReadKeyInput3 - Handles keypress for WASD + exit
; -----------------------------------------------------
ReadKeyInput3 PROC
    call ReadKey
    jz noInput

    mov inputChar, al
    cmp inputChar, 'x'
    je ExitGame
    cmp inputChar, 'w'
    je MoveUp3
    cmp inputChar, 's'
    je MoveDown3
    cmp inputChar, 'a'
    je MoveLeft3
    cmp inputChar, 'd'
    je MoveRight3
noInput:
    ret
ReadKeyInput3 ENDP

; -----------------------------------------------------
; MoveUp3 - Move player up and play sound
; -----------------------------------------------------
MoveUp3 PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    dec yPos
    call UpdateScore
    ret
MoveUp3 ENDP

MoveDown3 PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    inc yPos
    call UpdateScore
    ret
MoveDown3 ENDP

MoveLeft3 PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    dec xPos
    call UpdateScore
    ret
MoveLeft3 ENDP

MoveRight3 PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    inc xPos
    call UpdateScore
    ret
MoveRight3 ENDP

; Delay between frames (same as level 1 & 2)
DelayFrame PROC
    mov eax, 400
    call Delay
    ret
DelayFrame ENDP

END
