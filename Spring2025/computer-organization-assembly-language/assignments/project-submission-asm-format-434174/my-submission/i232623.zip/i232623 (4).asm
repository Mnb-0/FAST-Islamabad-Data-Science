; ghosts.asm - Ghost Movement Logic

INCLUDE Irvine32.inc
PUBLIC UpdateGhost, ResetGhost, GhostCollisionCheck
PUBLIC UpdateAllGhosts; - updates all 3 ghosts
PUBLIC UpdateAllGhosts
PUBLIC UpdateGhost1; - updates only ghost 1
PUBLIC UpdateGhost

EXTERN xPos:BYTE
EXTERN yPos:BYTE

.data
; Ghost 1 variables
ghost1 db '^'
Xghost1 db 24             ; starting X position for ghost1
Yghost1 db 6              ; starting Y position for ghost1
ghostDirection1 db 0      ; direction for ghost1 (0-3)
x1 BYTE ?                 ; to store old X for ghost1
y1 BYTE ?                 ; to store old Y for ghost1

; Ghost 2 variables
ghost2 db '>'
Xghost2 db 30             ; starting X position for ghost2
Yghost2 db 10             ; starting Y position for ghost2
ghostDirection2 db 0      ; direction for ghost2 (0-3)
x2 BYTE ?                 ; to store old X for ghost2
y2 BYTE ?                 ; to store old Y for ghost2

; Ghost 3 variables
ghost3 db '<'
Xghost3 db 36             ; starting X position for ghost3
Yghost3 db 14             ; starting Y position for ghost3
ghostDirection3 db 0      ; direction for ghost3 (0-3)
x3 BYTE ?                 ; to store old X for ghost3
y3 BYTE ?                 ; to store old Y for ghost3

.code

; ----------------------------------------------------
; UpdateGhost
; Moves all ghosts around in a square pattern
; Each ghost has its own position and direction
; ----------------------------------------------------
UpdateGhost PROC
    ; ========== GHOST 1 ==========
    mov cl, Xghost1
    mov ch, Yghost1
    mov x1, cl
    mov y1, ch

    cmp Xghost1, 44
    jne g1_check2
    cmp Yghost1, 6
    jne g1_check3
    inc ghostDirection1     ; top-right corner
g1_check3:
    cmp Yghost1, 25
    jne g1_check2
    inc ghostDirection1     ; bottom-right corner
g1_check2:
    cmp Xghost1, 24
    jne g1_check4
    cmp Yghost1, 25
    jne g1_check5
    inc ghostDirection1     ; bottom-left corner
g1_check5:
    cmp Yghost1, 6
    jne g1_check4
    mov ghostDirection1, 0  ; back to top-left (loop reset)
g1_check4:

    cmp ghostDirection1, 0
    jne g1_dir1
    inc Xghost1             ; move right
    jmp g1_render
g1_dir1:
    cmp ghostDirection1, 1
    jne g1_dir2
    inc Yghost1             ; move down
    jmp g1_render
g1_dir2:
    cmp ghostDirection1, 2
    jne g1_dir3
    dec Xghost1             ; move left
    jmp g1_render
g1_dir3:
    cmp ghostDirection1, 3
    jne g1_render
    dec Yghost1             ; move up

g1_render:
    mov eax, 18
    call delay

    mov dl, Xghost1
    mov dh, Yghost1
    mov al, ghost1
    call gotoxy
    call writechar

    mov dl, x1
    mov dh, y1
    call gotoxy
    mov al, ' '
    call writechar

    ; ========== GHOST 2 ==========
    mov cl, Xghost2
    mov ch, Yghost2
    mov x2, cl
    mov y2, ch

    cmp Xghost2, 44
    jne g2_check2
    cmp Yghost2, 6
    jne g2_check3
    inc ghostDirection2     ; top-right corner
g2_check3:
    cmp Yghost2, 25
    jne g2_check2
    inc ghostDirection2     ; bottom-right corner
g2_check2:
    cmp Xghost2, 24
    jne g2_check4
    cmp Yghost2, 25
    jne g2_check5
    inc ghostDirection2     ; bottom-left corner
g2_check5:
    cmp Yghost2, 6
    jne g2_check4
    mov ghostDirection2, 0  ; back to top-left (loop reset)
g2_check4:

    cmp ghostDirection2, 0
    jne g2_dir1
    inc Xghost2             ; move right
    jmp g2_render
g2_dir1:
    cmp ghostDirection2, 1
    jne g2_dir2
    inc Yghost2             ; move down
    jmp g2_render
g2_dir2:
    cmp ghostDirection2, 2
    jne g2_dir3
    dec Xghost2             ; move left
    jmp g2_render
g2_dir3:
    cmp ghostDirection2, 3
    jne g2_render
    dec Yghost2             ; move up

g2_render:
    mov eax, 18
    call delay

    mov dl, Xghost2
    mov dh, Yghost2
    mov al, ghost2
    call gotoxy
    call writechar

    mov dl, x2
    mov dh, y2
    call gotoxy
    mov al, ' '
    call writechar

    ; ========== GHOST 3 ==========
    mov cl, Xghost3
    mov ch, Yghost3
    mov x3, cl
    mov y3, ch

    cmp Xghost3, 44
    jne g3_check2
    cmp Yghost3, 6
    jne g3_check3
    inc ghostDirection3     ; top-right corner
g3_check3:
    cmp Yghost3, 25
    jne g3_check2
    inc ghostDirection3     ; bottom-right corner
g3_check2:
    cmp Xghost3, 24
    jne g3_check4
    cmp Yghost3, 25
    jne g3_check5
    inc ghostDirection3     ; bottom-left corner
g3_check5:
    cmp Yghost3, 6
    jne g3_check4
    mov ghostDirection3, 0  ; back to top-left (loop reset)
g3_check4:

    cmp ghostDirection3, 0
    jne g3_dir1
    inc Xghost3             ; move right
    jmp g3_render
g3_dir1:
    cmp ghostDirection3, 1
    jne g3_dir2
    inc Yghost3             ; move down
    jmp g3_render
g3_dir2:
    cmp ghostDirection3, 2
    jne g3_dir3
    dec Xghost3             ; move left
    jmp g3_render
g3_dir3:
    cmp ghostDirection3, 3
    jne g3_render
    dec Yghost3             ; move up

g3_render:
    mov eax, 18
    call delay

    mov dl, Xghost3
    mov dh, Yghost3
    mov al, ghost3
    call gotoxy
    call writechar

    mov dl, x3
    mov dh, y3
    call gotoxy
    mov al, ' '
    call writechar

    ret
UpdateGhost ENDP

; ----------------------------------------------------
; ResetGhost
; Brings all ghosts back to their start points
; ----------------------------------------------------
ResetGhost PROC
    mov Xghost1, 24
    mov Yghost1, 6
    mov ghostDirection1, 0

    mov Xghost2, 30
    mov Yghost2, 10
    mov ghostDirection2, 0

    mov Xghost3, 36
    mov Yghost3, 14
    mov ghostDirection3, 0
    ret
ResetGhost ENDP

; ----------------------------------------------------
; GhostCollisionCheck
; Checks if Pac-Man hits any ghost
; ----------------------------------------------------
GhostCollisionCheck PROC
    mov al, xPos
    cmp Xghost1, al
    jne check_g2
    mov al, yPos
    cmp Yghost1, al
    je collision
check_g2:
    mov al, xPos
    cmp Xghost2, al
    jne check_g3
    mov al, yPos
    cmp Yghost2, al
    je collision
check_g3:
    mov al, xPos
    cmp Xghost3, al
    jne skip
    mov al, yPos
    cmp Yghost3, al
    je collision
skip:
    ret
collision:
    ; If any ghost collides, just return (could set a flag here)
    ret
GhostCollisionCheck ENDP

; ----------------------------------------------------
; UpdateAllGhosts
; Moves all ghosts around in a square pattern
; ----------------------------------------------------
UpdateAllGhosts PROC
    call UpdateGhost1

    ; ========== GHOST 2 ==========
    mov cl, Xghost2
    mov ch, Yghost2
    mov x2, cl
    mov y2, ch

    cmp Xghost2, 44
    jne g2_check2_all
    cmp Yghost2, 6
    jne g2_check3_all
    inc ghostDirection2     ; top-right corner
g2_check3_all:
    cmp Yghost2, 25
    jne g2_check2_all
    inc ghostDirection2     ; bottom-right corner
g2_check2_all:
    cmp Xghost2, 24
    jne g2_check4_all
    cmp Yghost2, 25
    jne g2_check5_all
    inc ghostDirection2     ; bottom-left corner
g2_check5_all:
    cmp Yghost2, 6
    jne g2_check4_all
    mov ghostDirection2, 0  ; back to top-left (loop reset)
g2_check4_all:

    cmp ghostDirection2, 0
    jne g2_dir1_all
    inc Xghost2             ; move right
    jmp g2_render_all
g2_dir1_all:
    cmp ghostDirection2, 1
    jne g2_dir2_all
    inc Yghost2             ; move down
    jmp g2_render_all
g2_dir2_all:
    cmp ghostDirection2, 2
    jne g2_dir3_all
    dec Xghost2             ; move left
    jmp g2_render_all
g2_dir3_all:
    cmp ghostDirection2, 3
    jne g2_render_all
    dec Yghost2             ; move up

g2_render_all:
    mov eax, 18
    call delay

    mov dl, Xghost2
    mov dh, Yghost2
    mov al, ghost2
    call gotoxy
    call writechar

    mov dl, x2
    mov dh, y2
    call gotoxy
    mov al, ' '
    call writechar

    ; ========== GHOST 3 ==========
    mov cl, Xghost3
    mov ch, Yghost3
    mov x3, cl
    mov y3, ch

    cmp Xghost3, 44
    jne g3_check2_all
    cmp Yghost3, 6
    jne g3_check3_all
    inc ghostDirection3     ; top-right corner
g3_check3_all:
    cmp Yghost3, 25
    jne g3_check2_all
    inc ghostDirection3     ; bottom-right corner
g3_check2_all:
    cmp Xghost3, 24
    jne g3_check4_all
    cmp Yghost3, 25
    jne g3_check5_all
    inc ghostDirection3     ; bottom-left corner
g3_check5_all:
    cmp Yghost3, 6
    jne g3_check4_all
    mov ghostDirection3, 0  ; back to top-left (loop reset)
g3_check4_all:

    cmp ghostDirection3, 0
    jne g3_dir1_all
    inc Xghost3             ; move right
    jmp g3_render_all
g3_dir1_all:
    cmp ghostDirection3, 1
    jne g3_dir2_all
    inc Yghost3             ; move down
    jmp g3_render_all
g3_dir2_all:
    cmp ghostDirection3, 2
    jne g3_dir3_all
    dec Xghost3             ; move left
    jmp g3_render_all
g3_dir3_all:
    cmp ghostDirection3, 3
    jne g3_render_all
    dec Yghost3             ; move up

g3_render_all:
    mov eax, 18
    call delay

    mov dl, Xghost3
    mov dh, Yghost3
    mov al, ghost3
    call gotoxy
    call writechar

    mov dl, x3
    mov dh, y3
    call gotoxy
    mov al, ' '
    call writechar

    ret
UpdateAllGhosts ENDP

; ----------------------------------------------------
; UpdateGhost1
; Moves only ghost 1 around in a square pattern
; ----------------------------------------------------
UpdateGhost1 PROC
    mov cl, Xghost1
    mov ch, Yghost1
    mov x1, cl
    mov y1, ch

    cmp Xghost1, 44
    jne g1_check2_1
    cmp Yghost1, 6
    jne g1_check3_1
    inc ghostDirection1     ; top-right corner
g1_check3_1:
    cmp Yghost1, 25
    jne g1_check2_1
    inc ghostDirection1     ; bottom-right corner
g1_check2_1:
    cmp Xghost1, 24
    jne g1_check4_1
    cmp Yghost1, 25
    jne g1_check5_1
    inc ghostDirection1     ; bottom-left corner
g1_check5_1:
    cmp Yghost1, 6
    jne g1_check4_1
    mov ghostDirection1, 0  ; back to top-left (loop reset)
g1_check4_1:

    cmp ghostDirection1, 0
    jne g1_dir1_1
    inc Xghost1             ; move right
    jmp g1_render_1
g1_dir1_1:
    cmp ghostDirection1, 1
    jne g1_dir2_1
    inc Yghost1             ; move down
    jmp g1_render_1
g1_dir2_1:
    cmp ghostDirection1, 2
    jne g1_dir3_1
    dec Xghost1             ; move left
    jmp g1_render_1
g1_dir3_1:
    cmp ghostDirection1, 3
    jne g1_render_1
    dec Yghost1             ; move up

g1_render_1:
    mov eax, 18
    call delay

    mov dl, Xghost1
    mov dh, Yghost1
    mov al, ghost1
    call gotoxy
    call writechar

    mov dl, x1
    mov dh, y1
    call gotoxy
    mov al, ' '
    call writechar

    ret
UpdateGhost1 ENDP
END
