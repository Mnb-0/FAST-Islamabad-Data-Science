; init.asm - This handles the intro screen and gets the player's name

INCLUDE Irvine32.inc
INCLUDELIB winmm.lib

; Bringing in Windows sound functions manually
PlaySound PROTO :PTR BYTE, :DWORD, :DWORD  
SND_FILENAME equ 20000h     ; tells PlaySound we're giving it a file name
SND_ASYNC equ 1        ; play sound asynchronously
PUBLIC InitGame

.data
prompt1     db "Enter your name:",0                ; Ask the player to enter name
strName     db "Apka Naam:",0                      ; This is what we’ll display later
names       db 20 dup (32)                         ; Where the player's name will be saved
musicIntro  db "pacman_beginning.wav", 0           ; File path to intro music

; ASCII art for the PACMAN splash screen
PACMAN_ART     db '                  ________  ________  ________  _____ ______   ________  ________      ',13,10
               db '                           |\   __  \|\   __  \|\   ____\|\   _ \  _   \|\   __  \|\   ___  \    ',13,10
               db '                           \ \  \|\  \ \  \|\  \ \  \___|\ \  \\\__\ \  \ \  \|\  \ \  \\ \  \   ',13,10
               db '                            \ \   ____\ \   __  \ \  \    \ \  \\|__| \  \ \   __  \ \  \\ \  \  ',13,10
               db '                             \ \  \___|\ \  \ \  \ \  \____\ \  \    \ \  \ \  \ \  \ \  \\ \  \ ',13,10
               db '                              \ \__\    \ \__\ \__\ \_______\ \__\    \ \__\ \__\ \__\ \__\\ \__\',13,10
               db '                               \|__|     \|__|\|__|\|_______|\|__|     \|__|\|__|\|__|\|__| \|__|',13,10
               db '                                                                                  ',13,10
               db 0                                                      
                                                                      
                                                                      


                               
 gameOverScreen   db'                    ______        ______  _______     _____  _    _ _______ ______                                    ',13,10
                  db'                   / _____)  /\  |  ___ \(_______)   / ___ \| |  | (_______(_____ \                                    ',13,10
                  db'                  | /  ___  /  \ | | _ | |_____     | |   | | |  | |_____   _____) )                                   ',13,10
                  db'                  | | (___)/ /\ \| || || |  ___)    | |   | |\ \/ /|  ___) (_____ (                                    ',13,10
                  db'                  | \____/| |__| | || || | |_____   | |___| | \  / | |_____      | |                                   ',13,10
                  db'                   \_____/|______|_||_||_|_______)   \_____/   \/  |_______)     |_|                                   ',13,10
                  db 0                                            
                  

.code

InitGame PROC
    ; Print the PACMAN splash screen art near center
    mov dl,10
    mov dh,5
    call gotoxy
    mov eax,white
    call SetTextColor
    mov edx,OFFSET PACMAN_ART
    call WriteString

    ; Play the intro music to make it feel arcade-y
    INVOKE PlaySound, OFFSET musicIntro, NULL, SND_FILENAME
    mov eax,1500           ; short delay while music plays
    call delay
    call clrscr            ; clear screen for next step

    ; Ask the player to type their name
    mov dl,0
    mov dh,0
    call gotoxy
    mov edx,OFFSET prompt1
    call WriteString

    ; Read the input into the `names` variable
    mov edx,OFFSET names
    mov ecx,20
    call ReadString

    call clrscr            ; clean the screen again before menu appears
    ret
InitGame ENDP

END
