; instructions.asm - Shows the how-to-play screen for the player

INCLUDE Irvine32.inc
PUBLIC ShowInstructions

.data
GUIDE db 'Controls:                                                                                        ',13,10
                    db '                                                                                                 ',13,10
                    db ' 1. WASD To Move                                                                                 ',13,10
                    db ' 2. Eat all the pellets                                                                          ',13,10
                    db '                                                                                                 ',13,10
                    db 'Gameplay:                                                                                        ',13,10
                    db '                                                                                                 ',13,10
                    db ' 1. Pac-Man is basically on a non-stop food tour. Guide him through snack city.                  ',13,10
                    db ' 2. Avoid ghosts like you avoid your group project teammates.                                    ',13,10
                    db ' 3. Grab a power pellet and suddenly halaat badal jaatay hain                                    ',13,10
                    db ' 4. Occasionally, mysterious pellets show up. Eat them. Why? Because points.                      ',13,10
                    db '                                                                                                 ',13,10
                    db 'Scoring:                                                                                         ',13,10
                    db '                                                                                                 ',13,10
                    db ' 1. Each dot gives you points. Tiny snack, tiny reward.                                          ',13,10
                    db ' 2. Eat ghosts while powered up for bonus points and bragging rights.                            ',13,10
                    db ' 3. Finish a level and collect bonus points. Basically, win to win more.                         ',13,10
                    db '                                                                                                 ',13,10
                    db 'Game Over:                                                                                       ',13,10
                    db '                                                                                                 ',13,10
                    db ' 1. Get caught by a ghost without a power pellet? That�s one life gone.                          ',13,10
                    db ' 2. Lose all three lives and it�s goodbye, hero. Start crying or start over.                     ',13,10
                    db '                                                                                                 ',13,10
                    db 'Final Instruction: Film up rakhni hai.                                                           ',13,10
                    db 0

.code

ShowInstructions PROC
    call Clrscr                 ; clear the screen before showing anything

    mov eax, white              ; make the text bright white for visibility
    call SetTextColor

    ; position cursor to somewhere clean in the middle-ish
    mov dl, 5
    mov dh, 5
    call Gotoxy

    ; actually display the instructions
    mov edx, OFFSET GUIDE
    call WriteString

    ; wait for any key press so user has time to read
    call ReadChar

    ; clear screen again before going back to menu or wherever
    call Clrscr
    ret
ShowInstructions ENDP

END
