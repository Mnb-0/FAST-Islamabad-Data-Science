; level1.asm - Handles the main game loop for Level 1
; This is where everything runs — ghosts move, player moves,
; coins get collected, and the HUD updates.

INCLUDE Irvine32.inc

; External procedures we need from other files
EXTERN DrawPlayer:PROC
EXTERN UpdatePlayer:PROC
EXTERN UpdateScore:PROC
EXTERN DrawCoin:PROC
EXTERN CreateRandomCoin:PROC
EXTERN WallCollision:PROC
EXTERN UpdateCoin:PROC
EXTERN updateGhost:PROC
EXTERN ExitGame:PROC

PUBLIC StartLevelOne

.data
xPos BYTE 32               ; Player's starting X position
yPos BYTE 14               ; Player's starting Y position
inputChar BYTE ?           ; Key input from player
xCoinPos BYTE ?            ; Random coin X
yCoinPos BYTE ?            ; Coin Y is fixed (for now)
lives db 3                 ; Player starts with 3 lives
score dw 0                 ; Score starts at 0
;maze1_row0  db "########################################################################################################################",0
;maze1_row1  db "#............##............##............##............##............##............##............##............##......#",0
;maze1_row2  db "#.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#",0
;maze1_row3  db "#.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#",0
;maze1_row4  db "#.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#####.##.#####.####.##.####.#",0
;maze1_row5  db "#......................................................................................................................#",0
;maze1_row6  db "#.####.##.########.##.####.##.####.##.########.##.####.##.####.##.########.##.####.##.####.##.########.##.####.##.####.#",0
;maze1_row7  db "#......##....##....##......##......##....##....##......##......##....##....##......##......##....##....##......##......#",0
;maze1_row8  db "######.##### ## #####.######.##### ## #####.######.##### ## #####.######.##### ## #####.######.##### ## #####.######.###",0
;maze1_row9  db "     #.##### ## #####.#     #.##### ## #####.#     #.##### ## #####.#     #.##### ## #####.#     #.##### ## #####.#     ",0
;maze1_row10 db "     #.##          ##.#     #.##          ##.#     #.##          ##.#     #.##          ##.#     #.##          ##.#     ",0
;maze1_row11 db "     #.## ###--### ##.#     #.## ###--### ##.#     #.## ###--### ##.#     #.## ###--### ##.#     #.## ###--### ##.#     ",0
;maze1_row12 db "######.## #      # ##.######.## #      # ##.######.## #      # ##.######.## #      # ##.######.## #      # ##.######.###",0
;maze1_row13 db "      .   #      #   .      .   #      #   .      .   #      #   .      .   #      #   .      .   #      #   .      .   ",0
;maze1_row14 db "######.## #      # ##.######.## #      # ##.######.## #      # ##.######.## #      # ##.######.## #      # ##.######.###",0
;maze1_row15 db "     #.## ######## ##.#     #.## ######## ##.#     #.## ######## ##.#     #.## ######## ##.#     #.## ######## ##.#     ",0
;maze1_row16 db "     #.##          ##.#     #.##          ##.#     #.##          ##.#     #.##          ##.#     #.##          ##.#     ",0
;maze1_row17 db "     #.## ######## ##.#     #.## ######## ##.#     #.## ######## ##.#     #.## ######## ##.#     #.## ######## ##.#     ",0
;maze1_row18 db "######.## ######## ##.######.## ######## ##.######.## ######## ##.######.## ######## ##.######.## ######## ##.######.###",0
;maze1_row19 db "########################################################################################################################",0

file BYTE "pacman_chomp.wav",0        ; SFX for chomp
musicDeath BYTE "pacman_death.wav",0  ; SFX for game over

livesMsg db "Lives:",0
strScore db "Apka Kaam: ",0           ; Score label
names db 20 dup(32)                   ; Stores player name (max 20 chars)
strName db "Apka Naam:",0             ; Name label

.code

; -----------------------------------------------------
; StartLevelOne - Starts Level 1 and handles main loop
; -----------------------------------------------------
StartLevelOne PROC
    call DrawCoin                 ; Draw all coins on the board

Level1Loop:
    call updateGhost             ; Move the ghost
    call HandleCoinCollision     ; Did we collect a coin?
    call DrawHUD                 ; Show score, name, and lives
    call UpdatePlayer            ; Erase old player pos
    call DrawPlayer              ; Draw player at new pos
    call DelayFrame              ; Add a short delay
    call ReadKeyInput            ; Handle WASD or exit
    jmp Level1Loop               ; Repeat forever (until 'x')
StartLevelOne ENDP

; -----------------------------------------------------
; DrawHUD - Displays score, player name, and lives
; -----------------------------------------------------
DrawHUD PROC
    mov eax, white
    call SetTextColor

    ; Show score
    mov dl,0
    mov dh,0
    call Gotoxy
    mov edx,OFFSET strScore
    call WriteString
    movzx eax,score
    call WriteInt

    ; Show name
    mov dl,20
    call Gotoxy
    mov edx,OFFSET strName
    call WriteString
    mov dl,30
    call Gotoxy
    mov edx,OFFSET names
    call WriteString

    ; Show lives
    mov dl,110
    mov dh,0
    call Gotoxy
    mov edx,OFFSET livesMsg
    call WriteString

    mov dl,116
    call Gotoxy
    mov al,'$'              ; $ = a life
    movzx ecx,lives
DrawLife:
    call WriteChar
    loop DrawLife
    ret
DrawHUD ENDP

; -----------------------------------------------------
; HandleCoinCollision - Checks if player hit the coin
; -----------------------------------------------------
HandleCoinCollision PROC
    mov al,xPos
    cmp al,xCoinPos
    jne skipCoin
    mov al,yPos
    cmp al,yCoinPos
    jne skipCoin

    ; Player picked up a coin
    inc score
    call CreateRandomCoin
    call DrawCoin
skipCoin:
    ret
HandleCoinCollision ENDP

; -----------------------------------------------------
; DelayFrame - Adds a delay to control speed
; -----------------------------------------------------
DelayFrame PROC
    mov eax,400
    call Delay
    ret
DelayFrame ENDP

; -----------------------------------------------------
; ReadKeyInput - Handles input like WASD and X (quit)
; -----------------------------------------------------
ReadKeyInput PROC
    call ReadKey
    jz noInput             ; If no key pressed, skip

    mov inputChar,al
    cmp inputChar,'x'
    je ExitGame            ; Quit the game
    cmp inputChar,'w'
    je MoveUp
    cmp inputChar,'s'
    je MoveDown
    cmp inputChar,'a'
    je MoveLeft
    cmp inputChar,'d'
    je MoveRight
noInput:
    ret
ReadKeyInput ENDP

; Movement handlers (self-explanatory)

MoveUp PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    dec yPos
    call UpdateScore
    ret
MoveUp ENDP

MoveDown PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    inc yPos
    call UpdateScore
    ret
MoveDown ENDP

MoveLeft PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    dec xPos
    call UpdateScore
    ret
MoveLeft ENDP

MoveRight PROC
    INVOKE PlaySound, OFFSET file, NULL, 20000h
    inc xPos
    call UpdateScore
    ret
MoveRight ENDP

END
