; filehandler.asm - Manages reading and saving high scores with level info

INCLUDE Irvine32.inc

PUBLIC LoadScores, SaveHighScoreIfEligible
EXTERN score:WORD
EXTERN names:BYTE
EXTERN level:BYTE

.data
scoreFile db "scores.txt", 0
fileHandle HANDLE ?
buffer BYTE 5000 dup(?)
bytesRead DWORD ?

.code

; ---------------------------------------------
; LoadScores
; Reads saved scores names and level from scores.txt into buffer
; ---------------------------------------------
LoadScores PROC
    mov edx, OFFSET scoreFile     ; file name
    call OpenInputFile
    mov fileHandle, eax           ; save the file handle

    mov edx, OFFSET buffer        ; where to store the file data
    mov ecx, 5000                 ; max buffer size
    call ReadFromFile

    mov eax, fileHandle
    call CloseFile                ; done with reading
    ret
LoadScores ENDP

; ----------------------------------------------------------
; SaveHighScoreIfEligible
; This saves the player's name, score, and level to the file
; if the score is good enough (just checking if it's > 100)
; ----------------------------------------------------------
SaveHighScoreIfEligible PROC
    call LoadScores               ; get old data first

    mov ax, score
    cmp ax, 100                  ; only save if score is > 100
    jle skipSave

    ; Copy player name into buffer (first 20 bytes)
    mov esi, OFFSET buffer
    mov edi, OFFSET names
    mov ecx, 20
copyName:
    mov al, [edi]
    mov [esi], al
    inc esi
    inc edi
    loop copyName

    ; Now convert score (number) to string (ASCII) - 10 digits
    movzx eax, score
    mov ecx, 10
    mov edi, OFFSET buffer
    add edi, 20                   ; score starts after name
    mov ebx, 10                   ; base 10
scoreToStrLoop:
    xor edx, edx
    div ebx
    add dl, '0'                   ; turn digit into ASCII
    push dx
    loop scoreToStrLoop

    ; Pop the digits back in correct order
    mov ecx, 10
    mov edi, OFFSET buffer
    add edi, 20
writeDigits:
    pop dx
    mov [edi], dl
    inc edi
    loop writeDigits

    ; Add the level number at the end (as ASCII too)
    mov al, level
    add al, '0'
    mov [edi], al                ; goes to byte 30

    ; Write it all back to the file
    mov edx, OFFSET scoreFile
    call CreateOutputFile
    mov fileHandle, eax

    mov edx, OFFSET buffer
    mov ecx, 31                  ; total = 20 (name) + 10 (score) + 1 (level)
    mov eax, fileHandle
    call WriteToFile

skipSave:
    ret
SaveHighScoreIfEligible ENDP

END
