; ui.asm - User Interface Functions for Pac-Man
; This file handles the main menu and the Game Over screen.

INCLUDE Irvine32.inc

.MODEL SMALL
.STACK 100h

.DATA
    ; Title shown in menus
    gameTitle    BYTE "PAC-MAN", 0Dh, 0Ah, 0

    ; Menu options for the main screen
    menuOptions  BYTE "1. Start Game", 0Dh, 0Ah,
                      "2. Instructions", 0Dh, 0Ah,
                      "3. Exit", 0Dh, 0Ah, 0

    ; Game over screen message
    gameOverText BYTE "GAME OVER!", 0Dh, 0Ah,
                      "You were caught by a ghost!", 0Dh, 0Ah,
                      "Better luck next time!", 0Dh, 0Ah,
                      "Press any key to return...", 0Dh, 0Ah, 0

.CODE

; -------------------------------------------
; ShowMainMenu
; Clears the screen and shows the main menu
; -------------------------------------------
ShowMainMenu PROC
    call Clrscr
    mov edx, OFFSET gameTitle
    call WriteString
    call Crlf
    mov edx, OFFSET menuOptions
    call WriteString
    ret
ShowMainMenu ENDP

; -------------------------------------------
; ShowGameOver
; Shows a proper game over message and waits
; -------------------------------------------
ShowGameOver PROC
    call Clrscr
    mov edx, OFFSET gameTitle
    call WriteString
    call Crlf
    mov edx, OFFSET gameOverText
    call WriteString
    call ReadChar            ; Wait for the user to press a key
    call Clrscr
    ret
ShowGameOver ENDP

END
