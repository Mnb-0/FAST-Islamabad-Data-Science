# | Muneeb Lone |  23i-2623 | DS-B |
import heapq

ROWS = 10
COLS = 10

MOVES = [(1, 0), (-1, 0), (0, 1), (0, -1)]


grid = [
    ['S', '.', '.', '.', '#', '.', '.', '.', '.', '.'],
    ['.', '~', '~', '.', '#', '.', '&', '&', '.', '.'],
    ['.', '~', '.', '.', '.', '.', '#', '&', '.', '.'],
    ['.', '.', '.', '#', '#', '.', '.', '.', '.', '.'],
    ['#', '#', '.', '.', '.', '.', '.', '.', '#', '#'],
    ['.', '.', '.', '.', '~', '~', '.', '.', '.', '.'],
    ['.', '&', '&', '.', '~', '.', '.', '#', '#', '.'],
    ['.', '&', '.', '.', '.', '.', '.', '.', '~', '.'],
    ['.', '.', '.', '#', '#', '.', '~', '~', '~', '.'],
    ['.', '.', '.', '.', '#', '.', '.', '.', '.', 'G']
]


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def violates_claustrophobia(r, c):
    count = 0
    for dr, dc in MOVES:
        nr, nc = r + dr, c + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS:
            if grid[nr][nc] == '#':
                count += 1
    return count >= 2

def get_cost_and_state(r, c, prev_ink_count, ink_penalty_active):
    cell = grid[r][c]

    if cell == '#':
        return None

    base_cost = 1
    new_ink_count = 0
    new_penalty = ink_penalty_active

    if cell == '.':
        base_cost = 1
        new_ink_count = 0
        new_penalty = False

    elif cell == '~':
        base_cost = 4
        new_ink_count = prev_ink_count + 1
        if new_ink_count > 2:
            new_penalty = True

    elif cell == '&':
        base_cost = 2
        new_ink_count = 0

    elif cell in ['S', 'G']:
        base_cost = 1
        new_ink_count = 0
        new_penalty = False

    if new_penalty:
        base_cost += 2

    return base_cost, new_ink_count, new_penalty


def ucs():
    start = (0, 0)
    goal = (9, 9)

    pq = []
    heapq.heappush(pq, (0, start, 0, False, []))

    visited = set()

    while pq:
        cost, (r, c), ink_count, penalty, path = heapq.heappop(pq)

        state = (r, c, ink_count, penalty)
        if state in visited:
            continue
        visited.add(state)

        path = path + [(r, c)]

        if (r, c) == goal:
            return cost, path

        for dr, dc in MOVES:
            nr, nc = r + dr, c + dc

            if 0 <= nr < ROWS and 0 <= nc < COLS:
                if violates_claustrophobia(nr, nc):
                    continue

                result = get_cost_and_state(nr, nc, ink_count, penalty)
                if result is None:
                    continue

                move_cost, new_ink, new_penalty = result
                heapq.heappush(
                    pq,
                    (cost + move_cost, (nr, nc), new_ink, new_penalty, path)
                )

    return None


def astar():
    start = (0, 0)
    goal = (9, 9)

    pq = []
    heapq.heappush(pq, (0, 0, start, 0, False, []))

    visited = set()

    while pq:
        _, cost, (r, c), ink_count, penalty, path = heapq.heappop(pq)

        state = (r, c, ink_count, penalty)
        if state in visited:
            continue
        visited.add(state)

        path = path + [(r, c)]

        if (r, c) == goal:
            return cost, path

        for dr, dc in MOVES:
            nr, nc = r + dr, c + dc

            if 0 <= nr < ROWS and 0 <= nc < COLS:
                if violates_claustrophobia(nr, nc):
                    continue

                result = get_cost_and_state(nr, nc, ink_count, penalty)
                if result is None:
                    continue

                move_cost, new_ink, new_penalty = result
                g = cost + move_cost
                h = manhattan((nr, nc), goal)

                heapq.heappush(
                    pq,
                    (g + h, g, (nr, nc), new_ink, new_penalty, path)
                )

    return None


def beam_search(W=3):
    start = (0, 0)
    goal = (9, 9)

    beam = [(0, start, 0, False, [])]

    while beam:
        new_beam = []

        for cost, (r, c), ink_count, penalty, path in beam:
            path = path + [(r, c)]

            if (r, c) == goal:
                return cost, path

            for dr, dc in MOVES:
                nr, nc = r + dr, c + dc

                if 0 <= nr < ROWS and 0 <= nc < COLS:
                    if violates_claustrophobia(nr, nc):
                        continue

                    result = get_cost_and_state(nr, nc, ink_count, penalty)
                    if result is None:
                        continue

                    move_cost, new_ink, new_penalty = result
                    new_cost = cost + move_cost

                    new_beam.append(
                        (new_cost, (nr, nc), new_ink, new_penalty, path)
                    )

        new_beam.sort(key=lambda x: x[0] + manhattan(x[1], goal))
        beam = new_beam[:W]

    return None


if __name__ == "__main__":
    results = {
        "Uniform Cost Search": ucs(),
        "A* Search": astar(),
        "Beam Search (W=3)": beam_search(3)
    }

    for name, res in results.items():
        print(f"--- {name} ---")
        if res:
            cost, path = res
            print(f"Total Cost: {cost}")
            print(f"Path: {path}")
        else:
            print("No path found.")
        print()