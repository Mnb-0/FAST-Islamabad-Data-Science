# AeroNet Lite
**Autonomous Drone Delivery Simulation**  
*BS Data Science — AI Semester Project SP-2026*

---

## Project Overview

AeroNet Lite simulates an intelligent drone delivery network operating over a 10×10 city grid. It integrates five AI techniques to demonstrate end-to-end autonomous decision-making: layout validation, genetic optimisation, path planning, simulation with disruption handling, and machine learning.

---

## Modules

| # | Module | Technique | File |
|---|---|---|---|
| 1 | Layout Validation | Constraint Satisfaction (CSP) | `layout_validator.py` |
| 2 | Fleet Selection | Genetic Algorithm (GA) | `fleet_selector.py` |
| 3 | Path Planning | A\* Search | `astar_planner.py` |
| 4 | Simulation + Disruption | Rule-based + A\* rerouting | `delivery_simulator.py` |
| 5 | Demand & Anomaly ML | Regression + Classification | `ml_pipeline.py` |

---

## Directory Structure

```
aeronet_lite/
├── data/
│   ├── raw/                    # Placeholder for any raw external data
│   └── processed/
│       ├── demand_data.csv     # Generated after running main.py
│       └── anomaly_data.csv    # Generated after running main.py
├── src/
│   ├── grid_model.py           # Cell dataclass + 10×10 grid builder
│   ├── layout_validator.py     # CSP rules R1–R4
│   ├── fleet_selector.py       # Genetic Algorithm fleet selector
│   ├── astar_planner.py        # A* path planner
│   ├── delivery_simulator.py   # 20-step simulation engine
│   ├── ml_pipeline.py          # Demand forecasting + anomaly detection
│   ├── visualization.py        # All Matplotlib visualisations
│   └── main.py                 # Entry point — run this
├── notebooks/
│   ├── demand_forecasting.ipynb
│   └── anomaly_classifier.ipynb
├── report/
│   ├── figures/                # All PNG outputs (auto-created on run)
│   └── final_report.docx
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the full simulation
```bash
python src/main.py
```

This will:
- Run the 20-step simulation with console output
- Save 8 figures to `report/figures/`
- Train all ML models and print evaluation reports
- Save processed datasets to `data/processed/`

### 3. Explore notebooks (optional)
```bash
jupyter notebook notebooks/
```

---

## City Grid Design

The 10×10 grid satisfies all four CSP constraints by construction:

```
     0    1    2    3    4    5    6    7    8    9
 0 [ O,   O,   R,   R,   C,   C,   R,   R,   O,   O  ]
 1 [ R,   D,   P,   R,   R,   R,   R,   P,   D,   R  ]
 2 [ R,   R,   R,   C,   C,   C,   C,   R,   R,   R  ]
 3 [ R,   C,   C,   C,   H,   M,   C,   C,   C,   R  ]
 4 [ O,   R,   C,   S,   C,   C,   C,   S,   C,   O  ]
 5 [ O,   R,   R,   P,   D,   C,   D,   P,   R,   O  ]
 6 [ O,   R,   R,   C,   C,   C,   C,   R,   R,   O  ]
 7 [ R,   R,   H,   M,   C,   C,   C,   H,   R,   R  ]
 8 [ I,   D,   P,   O,   O,   O,   O,   P,   D,   I  ]
 9 [ I,   O,   R,   R,   O,   O,   R,   R,   O,   I  ]
```

| Code | Zone | Description |
|---|---|---|
| R | Residential | Delivery destinations, hub coverage required |
| C | Commercial | Air-lane corridors (A\* cost = 0.8) |
| I | Industrial | Isolated at corners, away from H/S |
| H | Hospital | Priority delivery zones |
| M | Medical Pickup | Adjacent to hospitals |
| S | School | Buffered from industrial cells |
| O | Open Field | No demand, low cost |
| D | Hub | Drone launch/land (▲) |
| P | Charging Pad | Battery replenishment (⚡) |

### CSP Rules

| Rule | Description | Status |
|---|---|---|
| R1 | Industrial cells not adjacent to School or Hospital | ✓ PASS |
| R2 | Every Residential cell within 3 Manhattan cells of a Hub | ✓ PASS |
| R3 | Every Hub has a Charging Pad within 2 cells | ✓ PASS |
| R4 | At least one Hospital has a Medical Pickup within 1 cell | ✓ PASS |

---

## Fleet Selection (Genetic Algorithm)

| Parameter | Value |
|---|---|
| Budget | £10,000 |
| Light drone | £1,000 · payload 2 kg · range 12 cells |
| Heavy drone | £1,800 · payload 5 kg · range 20 cells |
| Population | 80 chromosomes |
| Generations | 200 |
| Mutation rate | 25% |
| Fitness | `0.75 × coverage_pct – 0.25 × budget_pct` |

---

## A\* Path Planner

- 4-directional movement on the 10×10 grid
- Admissible heuristic: Manhattan distance
- Step cost: 1.0 (normal) · 0.8 (Commercial corridor)
- No-fly cells are treated as blocked nodes
- Full delivery route: `hub → pickup → drop-off → hub`

---

## Simulation Steps

| Steps | Phase |
|---|---|
| 1–3 | Grid init, CSP validation, GA fleet selection |
| 4–6 | Generate 8 deliveries, assign drones, plan A\* routes |
| 7–10 | Advance drones along planned paths |
| 11 | Activate no-fly cell (4,5) — weather event |
| 12–14 | Detect affected routes, reroute via A\* |
| 15–17 | Demand forecast integration |
| 18 | Inject battery anomaly |
| 19 | Reroute or force drone to return to hub |
| 20 | Final delivery summary |

---

## ML Models

### Demand Forecasting
| Model | Target | Metric |
|---|---|---|
| Linear Regression | Deliveries/hour | MAE, RMSE |
| Random Forest Regressor | Deliveries/hour | MAE, RMSE |

### Anomaly Detection
| Model | Classes | Metric |
|---|---|---|
| Decision Tree (depth=6) | Normal, Battery, Route, Sensor | Accuracy, Confusion Matrix |
| Random Forest (100 trees) | Normal, Battery, Route, Sensor | Accuracy, Confusion Matrix |

---

## Output Figures

| File | Description |
|---|---|
| `zone_map.png` | Coloured city grid with zone legend |
| `route_map.png` | Delivery routes overlaid on grid |
| `demand_heatmap.png` | Per-cell demand intensity |
| `ga_convergence.png` | GA fitness curve across generations |
| `demand_model_comparison.png` | MAE/RMSE bar chart |
| `decision_tree_cm.png` | Decision Tree confusion matrix |
| `random_forest_cm.png` | Random Forest confusion matrix |
| `anomaly_distribution.png` | Anomaly class balance chart |

---

## Author

BS Data Science · AI Semester Project · SP-2026
