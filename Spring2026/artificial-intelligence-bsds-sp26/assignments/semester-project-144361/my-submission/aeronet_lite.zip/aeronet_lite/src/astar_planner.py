"""
astar_planner.py
================
Module 3 – Delivery Path Planning with A* Search.

Plans safe routes through the 10×10 grid avoiding no-fly cells.

A* design choices (per project specification)
─────────────────────────────────────────────
  State       : grid coordinate (row, col)
  Actions     : move up / down / left / right (4-directional)
  Step cost   : 1.0 normal  │  0.8 inside a Commercial corridor
  Blocked     : cells where no_fly = True
  Heuristic   : Manhattan distance  (admissible for 4-direction grids)

Full delivery route
───────────────────
  hub  →  pickup  →  drop-off  →  hub

Each segment is solved independently by A*; the three sub-paths are
concatenated (duplicate waypoints at joints removed) to form the
complete delivery route.
"""

from __future__ import annotations

import heapq
from typing import Dict, List, Optional, Tuple

from grid_model import Cell, COMMERCIAL

Grid  = List[List[Cell]]
Coord = Tuple[int, int]
Path  = List[Coord]

# 4-connected movement directions (Δrow, Δcol)
_DIRECTIONS: List[Coord] = [(-1, 0), (1, 0), (0, -1), (0, 1)]


# ── Cost model ─────────────────────────────────────────────────────────────────
def _step_cost(grid: Grid, _current: Coord, neighbour: Coord) -> float:
    """
    Return the cost of moving into *neighbour*.
    Commercial corridor cells are cheaper (0.8) — they represent
    designated drone air-lanes over busy commercial zones.
    """
    nr, nc = neighbour
    return 0.8 if grid[nr][nc].zone == COMMERCIAL else 1.0


def _heuristic(a: Coord, b: Coord) -> float:
    """Manhattan distance — admissible, consistent heuristic."""
    return float(abs(a[0] - b[0]) + abs(a[1] - b[1]))


# ── Core A* ───────────────────────────────────────────────────────────────────
def astar(
    start: Coord,
    goal:  Coord,
    grid:  Grid,
) -> Tuple[Optional[Path], float, str]:
    """
    Find the least-cost path from *start* to *goal* avoiding no-fly cells.

    Parameters
    ----------
    start, goal : (row, col) tuples
    grid        : 10×10 cell grid (shared model)

    Returns
    -------
    (path, cost, message)
        path    – ordered list of (row, col) from start to goal, or None
        cost    – total path cost (sum of step costs), or inf on failure
        message – human-readable status string
    """
    # Guard: unreachable goals
    if grid[goal[0]][goal[1]].no_fly:
        return None, float("inf"), f"Goal {goal} is a no-fly cell — unreachable."

    if start == goal:
        return [start], 0.0, "Start equals goal — zero-cost trivial path."

    # open_heap entries: (f_cost, tie-breaker, coord)
    counter = 0
    open_heap: List[Tuple[float, int, Coord]] = []
    heapq.heappush(open_heap, (0.0, counter, start))

    g_cost: Dict[Coord, float]           = {start: 0.0}
    parent: Dict[Coord, Optional[Coord]] = {start: None}
    closed: set = set()

    while open_heap:
        _f, _tie, current = heapq.heappop(open_heap)

        if current in closed:
            continue
        closed.add(current)

        if current == goal:
            # Reconstruct path from goal back to start
            path: Path = []
            node: Optional[Coord] = goal
            while node is not None:
                path.append(node)
                node = parent[node]
            path.reverse()
            total = g_cost[goal]
            return path, total, (
                f"Route found: {len(path) - 1} steps, "
                f"cost {total:.2f}."
            )

        r, c = current
        for dr, dc in _DIRECTIONS:
            nr, nc = r + dr, c + dc
            if not (0 <= nr < 10 and 0 <= nc < 10):
                continue
            neighbour = (nr, nc)
            # Block no-fly cells except the goal itself
            if grid[nr][nc].no_fly and neighbour != goal:
                continue
            if neighbour in closed:
                continue

            tentative_g = g_cost[current] + _step_cost(grid, current, neighbour)
            if tentative_g < g_cost.get(neighbour, float("inf")):
                g_cost[neighbour] = tentative_g
                f_val = tentative_g + _heuristic(neighbour, goal)
                counter += 1
                heapq.heappush(open_heap, (f_val, counter, neighbour))
                parent[neighbour] = current

    return None, float("inf"), (
        f"No safe path from {start} to {goal} — all routes blocked by no-fly zones."
    )


# ── Full delivery route ────────────────────────────────────────────────────────
def plan_delivery_route(
    hub:    Coord,
    pickup: Coord,
    dropoff: Coord,
    grid:   Grid,
) -> Tuple[Optional[Path], float, str]:
    """
    Plan the full delivery route:  hub → pickup → drop-off → hub.

    Each segment is solved with A*; the three sub-paths are stitched
    together (joints deduplicated) to form one continuous route.

    Returns
    -------
    (full_path, total_cost, summary_message)
    """
    seg1, c1, m1 = astar(hub,     pickup,  grid)
    seg2, c2, m2 = astar(pickup,  dropoff, grid)
    seg3, c3, m3 = astar(dropoff, hub,     grid)

    failures = []
    if seg1 is None: failures.append(f"Hub→Pickup: {m1}")
    if seg2 is None: failures.append(f"Pickup→Dropoff: {m2}")
    if seg3 is None: failures.append(f"Dropoff→Hub: {m3}")

    if failures:
        return None, float("inf"), "Route planning FAILED — " + " | ".join(failures)

    # Stitch: remove duplicate junction waypoints
    assert seg1 is not None and seg2 is not None and seg3 is not None
    full_path: Path = seg1 + seg2[1:] + seg3[1:]
    total_cost = c1 + c2 + c3
    return (
        full_path,
        total_cost,
        f"Full route: {len(full_path)} waypoints, total cost {total_cost:.2f}  "
        f"[Hub→Pickup {c1:.2f}  |  Pickup→Dropoff {c2:.2f}  |  Dropoff→Hub {c3:.2f}]",
    )
