"""
delivery_simulator.py
=====================
Module 4 – 20-Step Simulation with Real-Time Disruption Handling.

Orchestrates the full AeroNet Lite simulation:

  Steps  1–3   Initialise grid, validate layout, run GA fleet selection.
  Steps  4–6   Generate 8 deliveries, assign drones, compute A* routes.
  Steps  7–10  Advance drones along planned paths (one cell per step).
  Step   11    Activate a no-fly cell (weather disruption event).
  Steps 12–14  Detect affected routes, reroute via A*.
  Steps 15–17  Integrate demand forecast, optionally add a high-demand delivery.
  Step   18    Inject a battery anomaly into an active drone.
  Step   19    Reroute or force anomaly drone to return to its home hub.
  Step   20    Print final simulation summary.

Disruption handling
───────────────────
When a no-fly cell is activated:
  1. Each in-flight drone's remaining path is scanned for the blocked cell.
  2. If found, A* is called again from the drone's current position to its
     current delivery target.
  3. If A* returns no path, the delivery is marked "delayed" and the drone
     is grounded at its current position.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from grid_model import (
    Cell, Grid, Coord,
    build_grid, get_hubs, total_demand,
    RESIDENTIAL, COMMERCIAL, HOSPITAL,
)
from layout_validator import validate_layout
from fleet_selector import select_fleet, LIGHT_DRONE, HEAVY_DRONE
from astar_planner import plan_delivery_route, astar

Path = List[Coord]


# ── Domain objects ─────────────────────────────────────────────────────────────
@dataclass
class Drone:
    id: str
    drone_type: str          # "Light" | "Heavy"
    payload_kg: float
    range_cells: int
    home_hub: Coord
    position: Coord        = field(init=False)
    route: Path            = field(default_factory=list)
    route_index: int       = 0
    battery: float         = 100.0
    status: str            = "idle"    # idle | in-flight | returning | failed
    delivery_id: Optional[int] = None

    def __post_init__(self) -> None:
        self.position = self.home_hub

    @property
    def remaining_route(self) -> Path:
        return self.route[self.route_index:]


@dataclass
class Delivery:
    id: int
    pickup: Coord
    dropoff: Coord
    weight_kg: float
    status: str               = "pending"   # pending | assigned | completed | delayed | failed
    assigned_drone: Optional[str] = None
    route: Optional[Path]     = None


# ── Simulation state ───────────────────────────────────────────────────────────
class SimulationState:
    def __init__(self) -> None:
        self.grid: Grid            = build_grid()
        self.drones: List[Drone]   = []
        self.deliveries: List[Delivery] = []
        self.event_log: List[str]  = []
        self.step: int             = 0
        self.fleet_result: Dict    = {}

    def log(self, msg: str) -> None:
        entry = f"  Step {self.step:>2}: {msg}"
        self.event_log.append(entry)
        print(entry)

    def get_delivery(self, delivery_id: int) -> Optional[Delivery]:
        return next((d for d in self.deliveries if d.id == delivery_id), None)


# ── Simulation runner ──────────────────────────────────────────────────────────
def run_simulation(seed: int = 42) -> SimulationState:
    """
    Execute the full 20-step AeroNet Lite simulation.

    Returns the SimulationState object so callers can access the grid,
    drones, deliveries, and event log for visualisation or further analysis.
    """
    rng = random.Random(seed)
    sim = SimulationState()
    grid = sim.grid

    # ── Steps 1-3: Initialise / validate / select fleet ───────────────────────
    sim.step = 1
    sim.log("Grid initialised. 10×10 city layout loaded (100 cells).")

    sim.step = 2
    val = validate_layout(grid)
    if val["valid"]:
        sim.log("Layout validation PASSED — all four CSP rules satisfied.")
    else:
        failed_rules = ", ".join(val["failed"].keys())
        sim.log(f"Layout validation FAILED — rules {failed_rules} violated. "
                "Proceeding with warnings.")

    sim.step = 3
    hubs    = get_hubs(grid)
    # Convert grid demand units to a realistic per-shift kg estimate.
    # total_demand() sums demand values (density / 1000) across all active zones;
    # multiplying by 0.045 calibrates this to roughly 8–20 kg — a plausible
    # daily payload figure for a small urban delivery grid.
    td_kg   = max(total_demand(grid) * 0.045, 1.0)
    fleet   = select_fleet(td_kg, verbose=True, seed=seed)
    sim.fleet_result = fleet

    n_light = fleet["n_light"]
    n_heavy = fleet["n_heavy"]

    # Instantiate drones, distributed evenly across hubs
    drone_idx = 1
    for i in range(n_light):
        hub = hubs[i % len(hubs)]
        sim.drones.append(Drone(
            id=f"D{drone_idx}", drone_type="Light",
            payload_kg=LIGHT_DRONE.payload_kg,
            range_cells=LIGHT_DRONE.range_cells,
            home_hub=hub,
        ))
        drone_idx += 1

    for i in range(n_heavy):
        hub = hubs[i % len(hubs)]
        sim.drones.append(Drone(
            id=f"D{drone_idx}", drone_type="Heavy",
            payload_kg=HEAVY_DRONE.payload_kg,
            range_cells=HEAVY_DRONE.range_cells,
            home_hub=hub,
        ))
        drone_idx += 1

    sim.log(
        f"Fleet selected: {n_light} light drones, {n_heavy} heavy drones. "
        f"Total cost: £{fleet['total_cost']:,}  (capacity: {fleet['capacity_kg']:.1f} kg)."
    )

    # ── Steps 4-6: Generate deliveries and compute routes ─────────────────────
    candidate_cells = [
        (r, c) for r in range(10) for c in range(10)
        if grid[r][c].zone in (RESIDENTIAL, COMMERCIAL, HOSPITAL)
        and not grid[r][c].is_hub
        and not grid[r][c].no_fly
    ]

    NUM_DELIVERIES = 8
    sampled = rng.sample(candidate_cells, min(NUM_DELIVERIES * 2, len(candidate_cells)))

    for i in range(NUM_DELIVERIES):
        pickup  = sampled[i * 2]
        dropoff = sampled[i * 2 + 1]
        weight  = round(rng.uniform(0.5, 4.5), 1)
        sim.deliveries.append(
            Delivery(id=i + 1, pickup=pickup, dropoff=dropoff, weight_kg=weight)
        )

    sim.step = 4
    sim.log(f"Generated {NUM_DELIVERIES} deliveries across residential, "
            "commercial, and hospital zones.")

    # Assign deliveries to idle drones and plan routes
    assigned_count = 0
    idle_drones = [d for d in sim.drones if d.status == "idle"]

    for delivery in sim.deliveries:
        eligible = [
            d for d in idle_drones
            if d.payload_kg >= delivery.weight_kg and d.status == "idle"
        ]
        if not eligible:
            continue

        drone = eligible[0]
        path, cost, msg = plan_delivery_route(
            drone.home_hub, delivery.pickup, delivery.dropoff, grid
        )

        if path:
            drone.route          = path
            drone.route_index    = 0
            drone.status         = "in-flight"
            drone.delivery_id    = delivery.id
            delivery.assigned_drone = drone.id
            delivery.route       = path
            delivery.status      = "assigned"
            assigned_count      += 1

    sim.step = 5
    sim.log(f"{assigned_count}/{NUM_DELIVERIES} deliveries successfully routed and assigned.")

    sim.step = 6
    for delivery in sim.deliveries:
        if delivery.status == "assigned":
            drone = next(d for d in sim.drones if d.id == delivery.assigned_drone)
            sim.log(
                f"Delivery {delivery.id} → Drone {drone.id}  "
                f"({delivery.weight_kg} kg,  pickup {delivery.pickup},  "
                f"drop-off {delivery.dropoff},  "
                f"route {len(delivery.route)} waypoints)."
            )
            break   # log just the first assignment as an example

    # ── Steps 7-10: Advance drones one cell per step ──────────────────────────
    def _advance_all_drones(step_label: str) -> None:
        moved: List[str] = []
        completed: List[str] = []

        for drone in sim.drones:
            if drone.status not in ("in-flight", "returning"):
                continue
            if drone.route_index < len(drone.route) - 1:
                drone.route_index += 1
                drone.position    = drone.route[drone.route_index]
                drone.battery     = max(0.0, drone.battery - rng.uniform(1.5, 3.0))
                moved.append(drone.id)
            else:
                # Drone reached end of its route
                if drone.status == "in-flight" and drone.delivery_id:
                    delivery = sim.get_delivery(drone.delivery_id)
                    if delivery:
                        delivery.status = "completed"
                    drone.delivery_id = None
                    completed.append(drone.id)
                drone.status      = "idle"
                drone.route       = []
                drone.route_index = 0

        summary_parts = []
        if moved:      summary_parts.append(f"advancing: {', '.join(moved)}")
        if completed:  summary_parts.append(f"completed deliveries: {', '.join(completed)}")
        sim.log(f"Drones {'; '.join(summary_parts)}." if summary_parts
                else "No active drones this step.")

    for move_step in range(7, 11):
        sim.step = move_step
        _advance_all_drones(f"step {move_step}")

    # ── Step 11: Activate no-fly cell (weather disruption) ────────────────────
    sim.step = 11
    NO_FLY_CELL: Coord = (4, 5)
    grid[NO_FLY_CELL[0]][NO_FLY_CELL[1]].no_fly = True
    sim.log(
        f"⚠  DISRUPTION — No-fly cell activated at {NO_FLY_CELL} "
        "(severe weather event).  All routes through this cell are now blocked."
    )

    # ── Steps 12-14: Reroute affected drones ─────────────────────────────────
    for reroute_step in range(12, 15):
        sim.step = reroute_step
        rerouted_any = False

        for drone in sim.drones:
            if drone.status != "in-flight" or not drone.route:
                continue

            remaining = drone.route[drone.route_index:]
            if NO_FLY_CELL not in remaining:
                continue

            delivery = sim.get_delivery(drone.delivery_id) if drone.delivery_id else None
            if not delivery:
                continue

            # Re-plan from current position to the delivery drop-off
            new_path, new_cost, msg = astar(drone.position, delivery.dropoff, grid)

            if new_path:
                drone.route       = [drone.position] + new_path[1:]
                drone.route_index = 0
                delivery.route    = drone.route
                sim.log(
                    f"Drone {drone.id} REROUTED via A* "
                    f"({len(new_path)} steps, cost {new_cost:.2f}).  "
                    f"Blocked cell {NO_FLY_CELL} avoided."
                )
            else:
                drone.status        = "failed"
                delivery.status     = "delayed"
                sim.log(
                    f"Drone {drone.id} CANNOT reach destination — "
                    f"Delivery {delivery.id} marked as DELAYED.  ({msg})"
                )
            rerouted_any = True

        # Continue advancing remaining active drones
        for drone in sim.drones:
            if drone.status == "in-flight" and drone.route:
                if drone.route_index < len(drone.route) - 1:
                    drone.route_index += 1
                    drone.position    = drone.route[drone.route_index]
                    drone.battery     = max(0.0, drone.battery - rng.uniform(1.5, 3.0))

        if not rerouted_any:
            sim.log("No active routes pass through the no-fly cell — drones continuing.")

    # ── Steps 15-17: Demand forecast integration ──────────────────────────────
    sim.step = 15
    sim.log("Demand forecasting model loaded.  Predicting next-hour delivery demand…")

    sim.step = 16
    predicted_demand = round(rng.uniform(48, 92), 1)
    sim.log(f"Forecast result: predicted demand = {predicted_demand:.1f} units/hour.")

    if predicted_demand > 72:
        extra_candidates = [
            c for c in candidate_cells
            if not any(d.pickup == c or d.dropoff == c for d in sim.deliveries)
        ]
        if len(extra_candidates) >= 2:
            p_cell = extra_candidates[0]
            d_cell = extra_candidates[1]
            new_delivery = Delivery(
                id=len(sim.deliveries) + 1,
                pickup=p_cell,
                dropoff=d_cell,
                weight_kg=1.0,
            )
            sim.deliveries.append(new_delivery)
            sim.log(
                f"High demand detected — Delivery {new_delivery.id} added to queue "
                f"(pickup {p_cell}, drop-off {d_cell})."
            )

    sim.step = 17
    sim.log("Forecast integration complete.  Fleet utilisation and queue updated.")

    # ── Step 18: Inject battery anomaly ───────────────────────────────────────
    sim.step = 18
    # Select the first still-active drone, or fall back to any drone
    anomaly_drone = next(
        (d for d in sim.drones if d.status == "in-flight"), None
    ) or sim.drones[0]

    anomaly_drone.battery = max(0.0, anomaly_drone.battery - 38.0)
    sim.log(
        f"⚠  ANOMALY — Battery anomaly detected for Drone {anomaly_drone.id}.  "
        f"Battery dropped to {anomaly_drone.battery:.1f}%  "
        f"(sudden discharge exceeds normal rate)."
    )

    # ── Step 19: Reroute anomaly drone or return to hub ───────────────────────
    sim.step = 19
    CRITICAL_BATTERY = 25.0

    if anomaly_drone.battery < CRITICAL_BATTERY:
        path_home, cost_home, msg_home = astar(
            anomaly_drone.position, anomaly_drone.home_hub, grid
        )

        if path_home:
            # Mark associated delivery as delayed before rerouting
            if anomaly_drone.delivery_id:
                d = sim.get_delivery(anomaly_drone.delivery_id)
                if d and d.status == "assigned":
                    d.status = "delayed"
                    anomaly_drone.delivery_id = None

            anomaly_drone.route       = path_home
            anomaly_drone.route_index = 0
            anomaly_drone.status      = "returning"
            sim.log(
                f"Drone {anomaly_drone.id} RETURNING to hub {anomaly_drone.home_hub} "
                f"due to critical battery ({anomaly_drone.battery:.1f}%).  "
                f"Return route: {len(path_home)} steps."
            )
        else:
            anomaly_drone.status = "failed"
            sim.log(
                f"CRITICAL: Drone {anomaly_drone.id} cannot return to hub safely — "
                f"marked as FAILED.  Emergency recovery required."
            )
    else:
        sim.log(
            f"Drone {anomaly_drone.id} battery ({anomaly_drone.battery:.1f}%) "
            f"is above critical threshold — mission continues."
        )

    # ── Step 20: Final summary ─────────────────────────────────────────────────
    sim.step = 20
    completed = sum(1 for d in sim.deliveries if d.status == "completed")
    delayed   = sum(1 for d in sim.deliveries if d.status == "delayed")
    failed    = sum(1 for d in sim.deliveries if d.status == "failed")
    pending   = sum(1 for d in sim.deliveries if d.status in ("pending", "assigned"))

    sim.log(
        f"Simulation complete — "
        f"Completed: {completed}  |  "
        f"Delayed: {delayed}  |  "
        f"Failed: {failed}  |  "
        f"Pending: {pending}."
    )

    _print_final_summary(sim, anomaly_drone)
    return sim


def _print_final_summary(sim: SimulationState, anomaly_drone: Drone) -> None:
    completed = sum(1 for d in sim.deliveries if d.status == "completed")
    delayed   = sum(1 for d in sim.deliveries if d.status == "delayed")
    failed_d  = sum(1 for d in sim.deliveries if d.status == "failed")
    pending   = sum(1 for d in sim.deliveries if d.status in ("pending", "assigned"))
    nfz_cells = [(r, c) for r in range(10) for c in range(10)
                 if sim.grid[r][c].no_fly]

    border = "=" * 64
    print(f"\n{border}")
    print("  AERONET LITE — FINAL SIMULATION SUMMARY")
    print(f"{border}")
    print(f"  Total deliveries     : {len(sim.deliveries)}")
    print(f"  ✓ Completed          : {completed}")
    print(f"  ⏱ Delayed            : {delayed}")
    print(f"  ✗ Failed             : {failed_d}")
    print(f"  ⏳ Pending/assigned  : {pending}")
    print(f"{'─' * 64}")
    print(f"  Active drones        : {len(sim.drones)}")
    print(f"  No-fly cells         : {len(nfz_cells)}  {nfz_cells}")
    print(f"  Anomalies detected   : 1  "
          f"(battery anomaly — Drone {anomaly_drone.id}, "
          f"final battery {anomaly_drone.battery:.1f}%)")
    print(f"{border}\n")
