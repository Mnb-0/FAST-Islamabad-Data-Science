"""
fleet_selector.py
=================
Module 2 – Fleet Selection via Genetic Algorithm (GA).

Selects the optimal mix of Light and Heavy drones to maximise delivery
coverage while staying within the £10,000 fleet budget.

Drone types
───────────
  Light  │ cost £1,000 │ payload 2 kg  │ range 12 cells
  Heavy  │ cost £1,800 │ payload 5 kg  │ range 20 cells

Chromosome encoding
───────────────────
  [n_light, n_heavy]   – two integer genes

Fitness function  (per project specification)
─────────────────────────────────────────────
  coverage_pct  = min(1.0,  fleet_capacity_kg / total_demand_kg)
  budget_pct    = fleet_cost / BUDGET
  fitness       = 0.75 * coverage_pct  –  0.25 * budget_pct

  Chromosomes whose cost exceeds the budget receive fitness = -1.0
  (infeasible penalty) and are naturally selected out.

GA operators
────────────
  Selection  : tournament selection (k = 3)
  Crossover  : single-point (applied with probability 0.9)
  Mutation   : ±1 perturbation on a randomly chosen gene (rate 0.25)
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List, Tuple

# ── Drone specifications ───────────────────────────────────────────────────────
@dataclass(frozen=True)
class DroneSpec:
    name: str
    cost: int          # £
    payload_kg: float  # maximum cargo weight
    range_cells: int   # maximum route length in grid cells


LIGHT_DRONE = DroneSpec(name="Light", cost=1_000, payload_kg=2.0, range_cells=12)
HEAVY_DRONE = DroneSpec(name="Heavy", cost=1_800, payload_kg=5.0, range_cells=20)

BUDGET: int = 10_000

# ── GA hyper-parameters ────────────────────────────────────────────────────────
POP_SIZE      = 80
GENERATIONS   = 200
MUTATION_RATE = 0.25
CROSSOVER_RATE = 0.90
TOURNAMENT_K  = 3
MAX_LIGHT     = 10   # search bound (not a hard constraint; budget is the real limit)
MAX_HEAVY     = 5

Chromosome = List[int]   # [n_light, n_heavy]


# ── Fitness ────────────────────────────────────────────────────────────────────
def _fitness(chrom: Chromosome, total_demand_kg: float) -> float:
    n_light, n_heavy = chrom
    cost = n_light * LIGHT_DRONE.cost + n_heavy * HEAVY_DRONE.cost

    if cost > BUDGET or (n_light + n_heavy) == 0:
        return -1.0   # infeasible or useless chromosome

    capacity_kg   = n_light * LIGHT_DRONE.payload_kg + n_heavy * HEAVY_DRONE.payload_kg
    coverage_pct  = min(1.0, capacity_kg / max(total_demand_kg, 1.0))
    budget_pct    = cost / BUDGET

    return 0.75 * coverage_pct - 0.25 * budget_pct


# ── GA operators ───────────────────────────────────────────────────────────────
def _random_chrom(rng: random.Random) -> Chromosome:
    return [rng.randint(0, MAX_LIGHT), rng.randint(0, MAX_HEAVY)]


def _crossover(p1: Chromosome, p2: Chromosome,
               rng: random.Random) -> Tuple[Chromosome, Chromosome]:
    """Single-point crossover over a 2-gene chromosome."""
    if rng.random() > CROSSOVER_RATE:
        return p1[:], p2[:]
    # With only 2 genes, point=1 swaps the second gene
    point = rng.randint(1, 1)
    c1 = p1[:point] + p2[point:]
    c2 = p2[:point] + p1[point:]
    return c1, c2


def _mutate(chrom: Chromosome, rng: random.Random) -> Chromosome:
    """Perturb one randomly chosen gene by ±1."""
    chrom = chrom[:]
    gene  = rng.randint(0, 1)
    delta = rng.choice([-1, 1])
    if gene == 0:
        chrom[0] = max(0, min(MAX_LIGHT, chrom[0] + delta))
    else:
        chrom[1] = max(0, min(MAX_HEAVY, chrom[1] + delta))
    return chrom


def _tournament(population: List[Chromosome],
                fitnesses: List[float],
                rng: random.Random) -> Chromosome:
    """Tournament selection: pick k random individuals, return a copy of the best."""
    contestants = rng.sample(range(len(population)), TOURNAMENT_K)
    best_idx    = max(contestants, key=lambda i: fitnesses[i])
    return population[best_idx][:]


# ── Main GA ────────────────────────────────────────────────────────────────────
def select_fleet(total_demand_kg: float,
                 verbose: bool = True,
                 seed: int = 42) -> Dict:
    """
    Run the GA and return the best fleet configuration found.

    Parameters
    ----------
    total_demand_kg : float
        Estimated total delivery demand in kg (from grid demand values).
    verbose : bool
        Print a formatted summary report when True.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    dict with keys:
        n_light      : int   — number of light drones selected
        n_heavy      : int   — number of heavy drones selected
        total_cost   : int   — total fleet cost in £
        fitness      : float — best fitness score achieved
        capacity_kg  : float — total fleet payload capacity
        ga_history   : List[float] — best fitness per generation (for plotting)
    """
    rng = random.Random(seed)

    population: List[Chromosome] = [_random_chrom(rng) for _ in range(POP_SIZE)]
    best_chrom: Chromosome = [0, 0]
    best_fit: float = -999.0
    ga_history: List[float] = []

    for gen in range(GENERATIONS):
        fitnesses = [_fitness(c, total_demand_kg) for c in population]

        gen_best_idx = max(range(len(population)), key=lambda i: fitnesses[i])
        if fitnesses[gen_best_idx] > best_fit:
            best_fit   = fitnesses[gen_best_idx]
            best_chrom = population[gen_best_idx][:]

        ga_history.append(best_fit)

        # ── Elitism: carry the best chromosome forward unchanged ─────────────
        next_gen: List[Chromosome] = [best_chrom[:]]

        while len(next_gen) < POP_SIZE:
            p1 = _tournament(population, fitnesses, rng)
            p2 = _tournament(population, fitnesses, rng)
            c1, c2 = _crossover(p1, p2, rng)

            if rng.random() < MUTATION_RATE:
                c1 = _mutate(c1, rng)
            if rng.random() < MUTATION_RATE:
                c2 = _mutate(c2, rng)

            next_gen.extend([c1, c2])

        population = next_gen[:POP_SIZE]

    n_light, n_heavy = best_chrom
    total_cost   = n_light * LIGHT_DRONE.cost + n_heavy * HEAVY_DRONE.cost
    capacity_kg  = n_light * LIGHT_DRONE.payload_kg + n_heavy * HEAVY_DRONE.payload_kg
    coverage_pct = min(1.0, capacity_kg / max(total_demand_kg, 1.0)) * 100

    if verbose:
        border = "=" * 64
        print(f"\n{border}")
        print("  AERONET LITE — Fleet Selection (Genetic Algorithm)")
        print(f"{border}")
        print(f"  Budget           : £{BUDGET:,}")
        print(f"  Total demand est.: {total_demand_kg:.1f} kg")
        print(f"  GA population    : {POP_SIZE}  │  Generations: {GENERATIONS}")
        print(f"{'─' * 64}")
        print(f"  Best chromosome  : [light={n_light}, heavy={n_heavy}]")
        print(f"  Fleet cost       : £{total_cost:,}  "
              f"(£{BUDGET - total_cost:,} remaining)")
        print(f"  Fleet capacity   : {capacity_kg:.1f} kg")
        print(f"  Demand coverage  : {coverage_pct:.1f}%")
        print(f"  Fitness score    : {best_fit:.4f}")
        print(f"{border}\n")

    return {
        "n_light":     n_light,
        "n_heavy":     n_heavy,
        "total_cost":  total_cost,
        "capacity_kg": capacity_kg,
        "fitness":     best_fit,
        "ga_history":  ga_history,
    }
