"""
grid_model.py
=============
Shared 10×10 city grid for AeroNet Lite.

Every other module imports from here.  The grid is the single source of truth
for zone types, hub locations, no-fly status, and demand values.

Grid design (verified against all four CSP rules R1–R4):
─────────────────────────────────────────────────────────
     0    1    2    3    4    5    6    7    8    9
 0 [ O,   O,   R,   R,   C,   C,   R,   R,   O,   O  ]
 1 [ R,   D,   P,   R,   R,   R,   R,   P,   D,   R  ]
 2 [ R,   R,   R,   C,   C,   C,   C,   R,   R,   R  ]
 3 [ R,   C,   C,   C,   H,   M,   C,   C,   C,   R  ]
 4 [ O,   R,   C,   S,   C,   C,   C,   S,   C,   O  ]
 5 [ O,   R,   R,   P,   D,   C,   D,   P,   R,   O  ]
 6 [ O,   R,   R,   C,   C,   C,   C,   R,   R,   O  ]
 7 [ R,   R,   H,   M,   C,   C,   C,   H,   R,   R  ]
 8 [ I,   D,   P,   O,   O,   O,   O,   P,   D,   I  ]
 9 [ I,   O,   R,   R,   O,   O,   R,   R,   O,   I  ]

Key:  R=Residential  C=Commercial  I=Industrial  H=Hospital
      S=School        O=OpenField   D=Hub         P=ChargingPad
      M=MedicalPickup

CSP rule compliance summary
───────────────────────────
R1  Industrial ↔ School/Hospital adjacency   PASS  (industrials at corners, far from H/S)
R2  Residential within 3 cells of a hub      PASS  (6 hubs cover every residential cell)
R3  Hub has charging pad within 2 cells      PASS  (each hub has a pad 1 cell away)
R4  ≥1 Hospital with Medical Pickup ≤1 cell  PASS  (hospitals at (3,4) and (7,2) each satisfied)
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import List, Tuple

# ── Zone name constants ────────────────────────────────────────────────────────
RESIDENTIAL    = "Residential"
COMMERCIAL     = "Commercial"
INDUSTRIAL     = "Industrial"
HOSPITAL       = "Hospital"
SCHOOL         = "School"
OPEN_FIELD     = "OpenField"
HUB            = "Hub"
CHARGING_PAD   = "ChargingPad"
MEDICAL_PICKUP = "MedicalPickup"

# Zones that generate delivery demand
DEMAND_ZONES = {RESIDENTIAL, COMMERCIAL, HOSPITAL}


# ── Cell dataclass ─────────────────────────────────────────────────────────────
@dataclass
class Cell:
    """Represents one cell (node) in the 10×10 city grid."""
    row: int
    col: int
    zone: str
    density: int          = 0      # population / activity density
    is_hub: bool          = False  # drone launch / land site
    is_charging: bool     = False  # battery replenishment pad
    is_medical_pickup: bool = False # medical supply source
    no_fly: bool          = False  # routing forbidden through this cell
    demand: float         = 0.0   # estimated delivery demand (units)

    def __repr__(self) -> str:
        flags = []
        if self.is_hub:           flags.append("HUB")
        if self.is_charging:      flags.append("CHG")
        if self.is_medical_pickup: flags.append("MED")
        if self.no_fly:           flags.append("NFZ")
        flag_str = f" [{','.join(flags)}]" if flags else ""
        return f"Cell({self.row},{self.col} {self.zone}{flag_str})"


# ── Base density per zone type ─────────────────────────────────────────────────
_BASE_DENSITY: dict[str, int] = {
    RESIDENTIAL:    4_200,
    COMMERCIAL:     9_500,
    INDUSTRIAL:     1_400,
    HOSPITAL:       5_000,
    SCHOOL:         4_000,
    OPEN_FIELD:       500,
    HUB:            2_200,
    CHARGING_PAD:   1_000,
    MEDICAL_PICKUP: 3_000,
}


def _density(zone: str, rng: random.Random) -> int:
    base = _BASE_DENSITY.get(zone, 1_000)
    return base + rng.randint(-300, 300)


# ── Grid construction ──────────────────────────────────────────────────────────
_LAYOUT: List[List[str]] = [
    #  0    1    2    3    4    5    6    7    8    9
    ["O", "O", "R", "R", "C", "C", "R", "R", "O", "O"],  # row 0
    ["R", "D", "P", "R", "R", "R", "R", "P", "D", "R"],  # row 1
    ["R", "R", "R", "C", "C", "C", "C", "R", "R", "R"],  # row 2
    ["R", "C", "C", "C", "H", "M", "C", "C", "C", "R"],  # row 3
    ["O", "R", "C", "S", "C", "C", "C", "S", "C", "O"],  # row 4
    ["O", "R", "R", "P", "D", "C", "D", "P", "R", "O"],  # row 5
    ["O", "R", "R", "C", "C", "C", "C", "R", "R", "O"],  # row 6
    ["R", "R", "H", "M", "C", "C", "C", "H", "R", "R"],  # row 7
    ["I", "D", "P", "O", "O", "O", "O", "P", "D", "I"],  # row 8
    ["I", "O", "R", "R", "O", "O", "R", "R", "O", "I"],  # row 9
]

_CODE_MAP: dict[str, str] = {
    "R": RESIDENTIAL, "C": COMMERCIAL, "I": INDUSTRIAL,
    "H": HOSPITAL,    "S": SCHOOL,     "O": OPEN_FIELD,
    "D": HUB,         "P": CHARGING_PAD, "M": MEDICAL_PICKUP,
}


def build_grid(seed: int = 7) -> List[List[Cell]]:
    """
    Construct and return the 10×10 AeroNet Lite city grid.

    Parameters
    ----------
    seed : int
        Random seed for density jitter (keeps results reproducible).

    Returns
    -------
    List[List[Cell]]
        grid[row][col] for row, col in 0..9
    """
    rng = random.Random(seed)
    grid: List[List[Cell]] = []

    for r, row_codes in enumerate(_LAYOUT):
        grid_row: List[Cell] = []
        for c, code in enumerate(row_codes):
            zone = _CODE_MAP[code]
            dens = _density(zone, rng)
            cell = Cell(
                row=r, col=c,
                zone=zone,
                density=dens,
                is_hub=(code == "D"),
                is_charging=(code == "P"),
                is_medical_pickup=(code == "M"),
                no_fly=False,
                demand=dens / 1_000.0 if zone in DEMAND_ZONES else 0.0,
            )
            grid_row.append(cell)
        grid.append(grid_row)

    return grid


# ── Convenience accessors ──────────────────────────────────────────────────────
Grid = List[List[Cell]]
Coord = Tuple[int, int]


def get_hubs(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].is_hub]


def get_charging_pads(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].is_charging]


def get_hospitals(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].zone == HOSPITAL]


def get_medical_pickups(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].is_medical_pickup]


def get_residentials(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].zone == RESIDENTIAL]


def get_industrials(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].zone == INDUSTRIAL]


def get_schools(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].zone == SCHOOL]


def total_demand(grid: Grid) -> float:
    """Sum of demand values across all demand-generating cells."""
    return sum(
        grid[r][c].demand
        for r in range(10) for c in range(10)
        if grid[r][c].zone in DEMAND_ZONES
    )


def no_fly_cells(grid: Grid) -> List[Coord]:
    return [(r, c) for r in range(10) for c in range(10) if grid[r][c].no_fly]
