"""
layout_validator.py
===================
Module 1 – Layout Validation Using Constraint Satisfaction (CSP).

Implements four hard constraints that any valid city layout must satisfy:

    R1  Industrial cells must NOT be directly adjacent to Schools or Hospitals.
    R2  Every Residential cell must be within 3 Manhattan cells of a Drone Hub.
    R3  Every Drone Hub must have a Charging Pad within 2 Manhattan cells.
    R4  At least ONE Hospital must have a Medical Pickup within 1 Manhattan cell.

This module does NOT auto-generate the city.  It validates an externally
defined grid (built by grid_model.build_grid) and reports violations with
coordinates and suggested fixes, matching the CSP-checker behaviour described
in the project specification.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

from grid_model import (
    Cell, Grid, Coord,
    INDUSTRIAL, HOSPITAL, SCHOOL, RESIDENTIAL,
)


# ── Utility helpers ────────────────────────────────────────────────────────────

def get_neighbors(row: int, col: int) -> List[Coord]:
    """Return the four cardinal neighbours that fall inside the 10×10 grid."""
    candidates = [
        (row - 1, col),   # up
        (row + 1, col),   # down
        (row, col - 1),   # left
        (row, col + 1),   # right
    ]
    return [(r, c) for r, c in candidates if 0 <= r < 10 and 0 <= c < 10]


def manhattan(a: Coord, b: Coord) -> int:
    """Manhattan (taxicab) distance between two grid coordinates."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


# ── Individual rule checkers ───────────────────────────────────────────────────

def check_industrial_safety(grid: Grid) -> List[str]:
    """
    R1: Industrial cells must not be directly adjacent (4-connected) to
        School or Hospital cells.

    Checks every industrial cell's four cardinal neighbours.
    Returns a list of violation strings (empty → rule passes).
    """
    errors: List[str] = []
    for r in range(10):
        for c in range(10):
            if grid[r][c].zone == INDUSTRIAL:
                for nr, nc in get_neighbors(r, c):
                    neighbour_zone = grid[nr][nc].zone
                    if neighbour_zone in (SCHOOL, HOSPITAL):
                        errors.append(
                            f"    R1 ✗  Industrial ({r},{c}) is adjacent to "
                            f"{neighbour_zone} ({nr},{nc})."
                            f"  Fix: add a buffer Open-Field cell between them."
                        )
    return errors


def check_residential_coverage(grid: Grid) -> List[str]:
    """
    R2: Every Residential cell must be within Manhattan distance 3 of at
        least one Drone Hub.

    Returns violation strings with nearest-hub distance and a suggested fix.
    """
    errors: List[str] = []
    hubs = [(r, c) for r in range(10) for c in range(10) if grid[r][c].is_hub]

    for r in range(10):
        for c in range(10):
            if grid[r][c].zone == RESIDENTIAL:
                distances = [manhattan((r, c), h) for h in hubs]
                if not distances or min(distances) > 3:
                    nearest_hub = hubs[distances.index(min(distances))] if hubs else None
                    dist_str = str(min(distances)) if distances else "∞"
                    fix_row = max(0, r - 1)
                    fix_col = c
                    errors.append(
                        f"    R2 ✗  Residential ({r},{c}) is {dist_str} cells from nearest "
                        f"hub {nearest_hub}.  "
                        f"Fix: add a hub near ({fix_row},{fix_col}) or convert cell to OpenField."
                    )
    return errors


def check_hub_charging(grid: Grid) -> List[str]:
    """
    R3: Every Drone Hub must have at least one Charging Pad within
        Manhattan distance 2.
    """
    errors: List[str] = []
    pads = [(r, c) for r in range(10) for c in range(10) if grid[r][c].is_charging]

    for r in range(10):
        for c in range(10):
            if grid[r][c].is_hub:
                if not any(manhattan((r, c), p) <= 2 for p in pads):
                    errors.append(
                        f"    R3 ✗  Hub ({r},{c}) has no Charging Pad within 2 cells.  "
                        f"Fix: add a ChargingPad at ({r},{c+1}) or ({r+1},{c})."
                    )
    return errors


def check_medical_access(grid: Grid) -> List[str]:
    """
    R4: At least ONE Hospital must have a Medical Pickup within 1 Manhattan cell.

    Only one hospital needs to satisfy this (it is an existential constraint,
    not a universal one).
    """
    hospitals = [(r, c) for r in range(10) for c in range(10)
                 if grid[r][c].zone == HOSPITAL]
    pickups   = [(r, c) for r in range(10) for c in range(10)
                 if grid[r][c].is_medical_pickup]

    for h in hospitals:
        if any(manhattan(h, p) <= 1 for p in pickups):
            return []   # at least one hospital satisfied → rule passes

    return [
        f"    R4 ✗  No Hospital has a Medical Pickup within 1 cell.  "
        f"Hospitals: {hospitals}.  Medical pickups: {pickups}.  "
        f"Fix: add a MedicalPickup adjacent to any hospital."
    ]


# ── Master validator ───────────────────────────────────────────────────────────

_RULE_DESCRIPTIONS: Dict[str, str] = {
    "R1": "Industrial Safety       — no adjacency to School / Hospital",
    "R2": "Residential Hub Coverage — every residential cell within 3 cells of a hub",
    "R3": "Hub Charging Access      — every hub has a charging pad within 2 cells",
    "R4": "Medical Emergency Access — ≥1 hospital with medical pickup within 1 cell",
}

_CHECKERS = {
    "R1": check_industrial_safety,
    "R2": check_residential_coverage,
    "R3": check_hub_charging,
    "R4": check_medical_access,
}


def validate_layout(grid: Grid) -> Dict:
    """
    Run all four CSP rule checkers and print a structured validation report.

    Returns
    -------
    dict with keys:
        valid   : bool   — True only if ALL rules pass
        passed  : list[str]           — rule IDs that passed
        failed  : dict[str, list[str]]— rule IDs → error messages for failures
    """
    results: Dict[str, List[str]] = {
        rule: checker(grid) for rule, checker in _CHECKERS.items()
    }

    passed = [r for r, errs in results.items() if not errs]
    failed = {r: errs for r, errs in results.items() if errs}
    is_valid = len(failed) == 0

    # ── Print report ─────────────────────────────────────────────────────────
    border = "=" * 64
    print(f"\n{border}")
    print("  AERONET LITE — CSP Layout Validation Report")
    print(f"{border}")

    for rule in ["R1", "R2", "R3", "R4"]:
        if rule in passed:
            print(f"  ✓  {rule} PASSED  │  {_RULE_DESCRIPTIONS[rule]}")
        else:
            print(f"  ✗  {rule} FAILED  │  {_RULE_DESCRIPTIONS[rule]}")
            for err in failed[rule]:
                print(err)

    print(f"{'─' * 64}")
    print(f"  Layout validity = {is_valid}")
    if not is_valid:
        print(f"  Failed rules    : {', '.join(failed.keys())}")
    else:
        print("  All constraints satisfied — layout is valid for deployment.")
    print(f"{border}\n")

    return {"valid": is_valid, "passed": passed, "failed": failed}
