"""
main.py
=======
AeroNet Lite — Main Entry Point
Prepared for BS Data Science AI Semester Project SP-2026

Run this file to execute the complete AeroNet Lite pipeline:

    python src/main.py

What it does
────────────
  1.  Runs the full 20-step drone delivery simulation.
  2.  Generates and saves all six visualisation figures to report/figures/.
  3.  Trains and evaluates both ML models (demand regression + anomaly classifier).
  4.  Saves processed datasets to data/processed/.
  5.  Prints the full 20-step event log at the end.

Output files
────────────
  report/figures/zone_map.png
  report/figures/route_map.png
  report/figures/demand_heatmap.png
  report/figures/ga_convergence.png
  report/figures/demand_model_comparison.png
  report/figures/decision_tree_cm.png
  report/figures/random_forest_cm.png
  report/figures/anomaly_distribution.png
  data/processed/demand_data.csv
  data/processed/anomaly_data.csv
"""

from __future__ import annotations

import os
import sys

# ── Ensure src/ is importable regardless of working directory ─────────────────
_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix

from delivery_simulator import run_simulation
from fleet_selector import select_fleet
from grid_model import build_grid, total_demand, no_fly_cells
from ml_pipeline import (
    ANOMALY_LABELS,
    generate_anomaly_dataset,
    generate_demand_dataset,
    train_anomaly_classifiers,
    train_demand_models,
)
from visualization import (
    plot_anomaly_class_distribution,
    plot_confusion_matrix,
    plot_demand_heatmap,
    plot_ga_convergence,
    plot_ml_comparison,
    plot_route_map,
    plot_zone_map,
)

# ── Directory paths ────────────────────────────────────────────────────────────
_PROJECT_ROOT = os.path.abspath(os.path.join(_SRC_DIR, ".."))
FIGURES_DIR   = os.path.join(_PROJECT_ROOT, "report", "figures")
DATA_DIR      = os.path.join(_PROJECT_ROOT, "data", "processed")

os.makedirs(FIGURES_DIR, exist_ok=True)
os.makedirs(DATA_DIR,    exist_ok=True)


def _fig(filename: str) -> str:
    return os.path.join(FIGURES_DIR, filename)


def _data(filename: str) -> str:
    return os.path.join(DATA_DIR, filename)


# ── Banner ─────────────────────────────────────────────────────────────────────
def _banner() -> None:
    border = "=" * 64
    print(f"\n{border}")
    print("  AERONET LITE")
    print("  Autonomous Drone Delivery Simulation")
    print("  BS Data Science — AI Semester Project SP-2026")
    print(f"{border}\n")


# ── Main pipeline ──────────────────────────────────────────────────────────────
def main() -> None:
    _banner()

    # ── 1.  Run 20-step simulation ─────────────────────────────────────────────
    print("─" * 64)
    print("  PHASE 1 — Running 20-Step Simulation")
    print("─" * 64 + "\n")

    sim = run_simulation(seed=42)
    grid = sim.grid

    # ── 2.  Visualisations ─────────────────────────────────────────────────────
    print("\n" + "─" * 64)
    print("  PHASE 2 — Generating Visualisations")
    print("─" * 64 + "\n")

    # 2a. Zone map
    plot_zone_map(grid, save_path=_fig("zone_map.png"))

    # 2b. Route map (show up to 5 drone routes + no-fly cells)
    nfz = no_fly_cells(grid)
    routes = [
        (d.id, d.route)
        for d in sim.drones
        if d.route and len(d.route) > 1
    ][:5]
    plot_route_map(grid, routes, no_fly_cells=nfz,
                   save_path=_fig("route_map.png"))

    # 2c. Demand heatmap
    plot_demand_heatmap(grid, save_path=_fig("demand_heatmap.png"))

    # 2d. GA convergence (re-run fleet selector silently for the history)
    td_kg = max(total_demand(grid) * 0.045, 1.0)
    fleet_res = select_fleet(td_kg, verbose=False, seed=42)
    plot_ga_convergence(fleet_res["ga_history"],
                        save_path=_fig("ga_convergence.png"))

    # ── 3.  ML pipeline — Demand Forecasting ──────────────────────────────────
    print("\n" + "─" * 64)
    print("  PHASE 3A — ML Pipeline: Demand Forecasting")
    print("─" * 64)

    demand_df  = generate_demand_dataset(n=2_000, seed=42)
    demand_df.to_csv(_data("demand_data.csv"), index=False)
    print(f"  Dataset saved  → {_data('demand_data.csv')}  ({len(demand_df)} rows)\n")

    demand_res = train_demand_models(demand_df, verbose=True)

    plot_ml_comparison(
        demand_res["lr_metrics"], demand_res["rfr_metrics"],
        save_path=_fig("demand_model_comparison.png"),
    )

    # ── 4.  ML pipeline — Anomaly Detection ───────────────────────────────────
    print("\n" + "─" * 64)
    print("  PHASE 3B — ML Pipeline: Anomaly Detection")
    print("─" * 64)

    anomaly_df  = generate_anomaly_dataset(n=3_000, seed=42)
    anomaly_df.to_csv(_data("anomaly_data.csv"), index=False)
    print(f"  Dataset saved  → {_data('anomaly_data.csv')}  ({len(anomaly_df)} rows)\n")

    anomaly_res = train_anomaly_classifiers(anomaly_df, verbose=True)

    class_names = anomaly_res["class_names"]

    plot_anomaly_class_distribution(
        anomaly_df, ANOMALY_LABELS,
        save_path=_fig("anomaly_distribution.png"),
    )

    for model_name, preds_key in [
        ("Decision Tree",  "dt_preds"),
        ("Random Forest",  "rfc_preds"),
    ]:
        cm  = confusion_matrix(anomaly_res["y_test"], anomaly_res[preds_key])
        acc = accuracy_score(anomaly_res["y_test"],   anomaly_res[preds_key])
        fname = model_name.lower().replace(" ", "_") + "_cm.png"
        plot_confusion_matrix(
            cm, class_names,
            title=f"Anomaly Detection — {model_name}  (acc = {acc:.3f})",
            save_path=_fig(fname),
        )

    # ── 5.  Print full event log ───────────────────────────────────────────────
    print("\n" + "=" * 64)
    print("  FULL 20-STEP SIMULATION EVENT LOG")
    print("=" * 64)
    for entry in sim.event_log:
        print(entry)

    # ── Summary ────────────────────────────────────────────────────────────────
    print("\n" + "=" * 64)
    print("  PIPELINE COMPLETE")
    print("=" * 64)
    print(f"  Figures  → {FIGURES_DIR}")
    print(f"  Datasets → {DATA_DIR}")
    print("=" * 64 + "\n")


if __name__ == "__main__":
    main()
