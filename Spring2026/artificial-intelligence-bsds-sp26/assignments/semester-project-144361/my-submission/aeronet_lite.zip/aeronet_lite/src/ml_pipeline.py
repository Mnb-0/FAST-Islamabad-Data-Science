"""
ml_pipeline.py
==============
Module 5 – Demand Forecasting and Anomaly Detection.

─── PART A: Demand Forecasting (Regression) ──────────────────────────────────
Generates a synthetic dataset that mimics the structure and temporal patterns
of the Bike Sharing Demand dataset (Kaggle).  Two models are compared:

    •  Linear Regression       – interpretable, fast baseline
    •  Random Forest Regressor – non-linear, typically lower error

Features:  hour, day_of_week, temperature, weather_code, zone_density
Target:    demand  (integer deliveries per hour)
Metrics:   MAE, RMSE

The synthetic demand follows realistic patterns:
    - Morning peak  ≈ 08:00–09:00
    - Evening peak  ≈ 17:00–19:00
    - Weekdays > weekends
    - Demand drops in rain (weather_code ≥ 3)

─── PART B: Anomaly Detection (Classification) ────────────────────────────────
Generates synthetic drone telemetry with four labelled anomaly classes.
Logic is explicit and explainable during viva:

    Class 0  Normal          battery_drop ∈ [0.5, 3.0],  deviation < 1.5
    Class 1  Battery Anomaly battery_drop > 8   (sudden discharge)
    Class 2  Route Anomaly   route_deviation > 4 (far off planned path)
    Class 3  Sensor Spike    altitude_change > 8  OR  speed_change > 15

Models compared:
    •  Decision Tree Classifier  – interpretable, directly visualisable
    •  Random Forest Classifier  – ensemble, higher accuracy
Metrics: accuracy, confusion matrix, classification report
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    mean_absolute_error,
    mean_squared_error,
)
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

# ── Anomaly label mapping ──────────────────────────────────────────────────────
ANOMALY_LABELS: Dict[int, str] = {
    0: "Normal",
    1: "Battery Anomaly",
    2: "Route Anomaly",
    3: "Sensor Spike",
}


# ══════════════════════════════════════════════════════════════════════════════
#  PART A  —  DEMAND FORECASTING
# ══════════════════════════════════════════════════════════════════════════════

def generate_demand_dataset(n: int = 2_000, seed: int = 42) -> pd.DataFrame:
    """
    Generate a synthetic hourly delivery-demand dataset.

    Designed to mimic the statistical structure of the Bike Sharing Demand
    dataset (Kaggle) while remaining self-contained (no external download).

    Parameters
    ----------
    n    : number of records
    seed : NumPy random seed

    Returns
    -------
    pd.DataFrame with columns:
        hour, day_of_week, temperature, weather_code, zone_density, demand
    """
    rng = np.random.default_rng(seed)

    hours        = rng.integers(0,     24,    n)
    days         = rng.integers(0,     7,     n)   # 0=Mon … 6=Sun
    temperature  = rng.uniform(5.0,   38.0,  n)   # Celsius
    weather_code = rng.integers(1,     5,     n)   # 1=clear 2=cloudy 3=light rain 4=heavy rain
    zone_density = rng.uniform(1_000, 10_000, n)

    # Demand model
    morning_peak = 20 * np.sin(np.pi * np.clip(hours - 6,  0, 12) / 12)
    evening_bump = 12 * np.sin(np.pi * np.clip(hours - 14, 0,  8) /  8)
    weekday_bonus = 5.0 * (days < 5).astype(float)
    density_bonus = 0.002 * zone_density
    rain_penalty  = 6.0  * (weather_code >= 3).astype(float)
    noise         = rng.normal(0.0, 4.0, n)

    base_demand = (
        28 + morning_peak + evening_bump
        + weekday_bonus + density_bonus - rain_penalty + noise
    )
    demand = np.clip(base_demand, 0, None).round().astype(int)

    return pd.DataFrame({
        "hour":         hours,
        "day_of_week":  days,
        "temperature":  np.round(temperature, 1),
        "weather_code": weather_code,
        "zone_density": np.round(zone_density, 0).astype(int),
        "demand":       demand,
    })


def train_demand_models(
    df: pd.DataFrame,
    verbose: bool = True,
) -> Dict:
    """
    Train and evaluate Linear Regression and Random Forest Regressor.

    Returns
    -------
    dict with keys:
        lr_model, rfr_model,
        lr_metrics, rfr_metrics   (each: {'model': str, 'MAE': float, 'RMSE': float})
        X_test, y_test, lr_preds, rfr_preds
    """
    FEATURES = ["hour", "day_of_week", "temperature", "weather_code", "zone_density"]
    X = df[FEATURES]
    y = df["demand"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    lr  = LinearRegression()
    rfr = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)

    lr.fit(X_train,  y_train)
    rfr.fit(X_train, y_train)

    lr_preds  = lr.predict(X_test)
    rfr_preds = rfr.predict(X_test)

    def _metrics(name: str, preds: np.ndarray) -> Dict:
        mae  = float(mean_absolute_error(y_test, preds))
        rmse = float(np.sqrt(mean_squared_error(y_test, preds)))
        return {"model": name, "MAE": round(mae, 3), "RMSE": round(rmse, 3)}

    lr_m  = _metrics("Linear Regression",      lr_preds)
    rfr_m = _metrics("Random Forest Regressor", rfr_preds)

    if verbose:
        border = "=" * 64
        print(f"\n{border}")
        print("  ML PIPELINE — Demand Forecasting (Regression)")
        print(f"{border}")
        print(f"  Training samples : {len(X_train)}   Test samples : {len(X_test)}")
        print(f"  Features         : {FEATURES}")
        print(f"{'─' * 64}")
        print(f"  {'Model':<30} {'MAE':>8}  {'RMSE':>8}")
        print(f"  {'─'*28}  {'─'*7}  {'─'*7}")
        for m in [lr_m, rfr_m]:
            print(f"  {m['model']:<30} {m['MAE']:>8.3f}  {m['RMSE']:>8.3f}")
        print(f"{'─' * 64}")
        winner = "Random Forest" if rfr_m["MAE"] < lr_m["MAE"] else "Linear Regression"
        print(f"  Lower MAE model  : {winner}")
        print(f"{border}\n")

    return {
        "lr_model":   lr,
        "rfr_model":  rfr,
        "lr_metrics": lr_m,
        "rfr_metrics": rfr_m,
        "X_test":     X_test,
        "y_test":     y_test,
        "lr_preds":   lr_preds,
        "rfr_preds":  rfr_preds,
        "feature_names": FEATURES,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  PART B  —  ANOMALY DETECTION
# ══════════════════════════════════════════════════════════════════════════════

def generate_anomaly_dataset(n: int = 3_000, seed: int = 42) -> pd.DataFrame:
    """
    Generate synthetic drone telemetry with four labelled anomaly classes.

    Class distribution
    ──────────────────
        0  Normal           60%   (regular operation)
        1  Battery Anomaly  15%   (sudden battery discharge)
        2  Route Anomaly    15%   (drone deviates from planned path)
        3  Sensor Spike     10%   (altitude or speed sensor spike)

    Feature semantics
    ─────────────────
        battery_drop      % battery consumed per 10-second window
        speed             horizontal speed in m/s
        route_deviation   lateral distance from planned path (grid units)
        altitude_change   absolute change in altitude (metres)
        speed_change      change in horizontal speed (m/s between windows)
    """
    rng = np.random.default_rng(seed)

    n_normal  = int(n * 0.60)
    n_battery = int(n * 0.15)
    n_route   = int(n * 0.15)
    n_sensor  = n - n_normal - n_battery - n_route

    def _block(
        k: int, label: int,
        batt_range:  Tuple[float, float] = (0.5,  3.0),
        speed_range: Tuple[float, float] = (10.0, 20.0),
        dev_range:   Tuple[float, float] = (0.0,  1.5),
        alt_range:   Tuple[float, float] = (0.0,  2.0),
        spd_chg:     Tuple[float, float] = (0.0,  3.0),
    ) -> Dict[str, np.ndarray]:
        return {
            "battery_drop":    rng.uniform(*batt_range,  k),
            "speed":           rng.uniform(*speed_range, k),
            "route_deviation": rng.uniform(*dev_range,   k),
            "altitude_change": rng.uniform(*alt_range,   k),
            "speed_change":    rng.uniform(*spd_chg,     k),
            "label":           np.full(k, label, dtype=int),
        }

    normal  = _block(n_normal,  0)
    battery = _block(n_battery, 1,
                     batt_range=(8.0, 22.0), speed_range=(4.0, 18.0),
                     dev_range=(0.0, 2.0),   alt_range=(0.0, 3.0),
                     spd_chg=(0.0, 4.0))
    route   = _block(n_route,   2,
                     batt_range=(0.5, 4.0),  speed_range=(12.0, 24.0),
                     dev_range=(4.0, 12.0),  alt_range=(0.0, 3.0),
                     spd_chg=(0.0, 5.0))
    sensor  = _block(n_sensor,  3,
                     batt_range=(0.5, 4.0),  speed_range=(10.0, 38.0),
                     dev_range=(0.0, 3.0),   alt_range=(8.0, 30.0),
                     spd_chg=(15.0, 35.0))

    combined = {
        col: np.concatenate([b[col] for b in [normal, battery, route, sensor]])
        for col in ["battery_drop", "speed", "route_deviation",
                    "altitude_change", "speed_change", "label"]
    }

    df = pd.DataFrame(combined)
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)
    df[["battery_drop", "speed", "route_deviation",
        "altitude_change", "speed_change"]] = (
        df[["battery_drop", "speed", "route_deviation",
            "altitude_change", "speed_change"]].round(3)
    )
    return df


def train_anomaly_classifiers(
    df: pd.DataFrame,
    verbose: bool = True,
) -> Dict:
    """
    Train Decision Tree and Random Forest classifiers for anomaly detection.

    Returns
    -------
    dict with keys:
        dt_model, rfc_model,
        X_test, y_test, dt_preds, rfc_preds,
        feature_names
    """
    FEATURES = [
        "battery_drop", "speed", "route_deviation",
        "altitude_change", "speed_change",
    ]
    X = df[FEATURES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    dt  = DecisionTreeClassifier(max_depth=6, min_samples_leaf=5, random_state=42)
    rfc = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)

    dt.fit(X_train,  y_train)
    rfc.fit(X_train, y_train)

    dt_preds  = dt.predict(X_test)
    rfc_preds = rfc.predict(X_test)

    class_names = [ANOMALY_LABELS[i] for i in sorted(ANOMALY_LABELS)]

    if verbose:
        border = "=" * 64
        print(f"\n{border}")
        print("  ML PIPELINE — Anomaly Detection (Classification)")
        print(f"{border}")
        print(f"  Training samples : {len(X_train)}   Test samples : {len(X_test)}")
        print(f"  Features         : {FEATURES}")
        print(f"  Classes          : {class_names}")
        print(f"{'─' * 64}")

        for model_name, preds in [
            ("Decision Tree (depth=6)", dt_preds),
            ("Random Forest (100 trees)", rfc_preds),
        ]:
            acc = accuracy_score(y_test, preds)
            cm  = confusion_matrix(y_test, preds)
            print(f"\n  ── {model_name}  (accuracy = {acc:.4f}) ──")
            print("  Confusion Matrix:")
            for row_lbl, row in zip(class_names, cm):
                print(f"    {row_lbl:<20}: {list(row)}")
            print("\n  Classification Report:")
            report = classification_report(
                y_test, preds,
                target_names=class_names,
                digits=3
            )
            for line in report.splitlines():
                print(f"    {line}")

        print(f"\n{border}\n")

    return {
        "dt_model":      dt,
        "rfc_model":     rfc,
        "X_test":        X_test,
        "y_test":        y_test,
        "dt_preds":      dt_preds,
        "rfc_preds":     rfc_preds,
        "feature_names": FEATURES,
        "class_names":   class_names,
    }


# ── Quick single-sample prediction (used by simulator) ────────────────────────
def predict_demand(model, hour: int, day: int, temp: float,
                   weather: int, density: float) -> float:
    """Return a single demand forecast from a fitted regression model."""
    X = pd.DataFrame([{
        "hour": hour, "day_of_week": day, "temperature": temp,
        "weather_code": weather, "zone_density": density,
    }])
    return float(model.predict(X)[0])


def predict_anomaly(model, battery_drop: float, speed: float,
                    deviation: float, alt_change: float,
                    spd_change: float) -> Tuple[int, str]:
    """Return (class_id, label_name) for a single telemetry reading."""
    X = pd.DataFrame([{
        "battery_drop":    battery_drop,
        "speed":           speed,
        "route_deviation": deviation,
        "altitude_change": alt_change,
        "speed_change":    spd_change,
    }])
    class_id = int(model.predict(X)[0])
    return class_id, ANOMALY_LABELS[class_id]
