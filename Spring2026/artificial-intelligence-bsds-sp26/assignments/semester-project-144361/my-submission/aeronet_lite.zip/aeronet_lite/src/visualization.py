"""
visualization.py
================
All AeroNet Lite visualisations using Matplotlib.

Views provided (per specification):
    plot_zone_map          — coloured 10×10 zone grid with legend
    plot_route_map         — drone paths overlaid on zone grid, no-fly markers
    plot_demand_heatmap    — demand intensity per cell (YlOrRd colormap)
    plot_ga_convergence    — GA best-fitness history across generations
    plot_ml_comparison     — MAE / RMSE bar chart for regression models
    plot_confusion_matrix  — annotated confusion matrix for classifier
    plot_anomaly_bar       — class distribution bar chart for anomaly dataset
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np

# ── Colour palette ─────────────────────────────────────────────────────────────
ZONE_COLORS: Dict[str, str] = {
    "Residential":   "#90CAF9",   # light blue
    "Commercial":    "#FFD54F",   # amber
    "Industrial":    "#B0BEC5",   # blue-grey
    "Hospital":      "#EF9A9A",   # rose
    "School":        "#A5D6A7",   # light green
    "OpenField":     "#F5F5F5",   # near-white
    "Hub":           "#1565C0",   # deep blue
    "ChargingPad":   "#7B1FA2",   # purple
    "MedicalPickup": "#C62828",   # deep red
}

LEGEND_LABELS: Dict[str, str] = {
    "Residential":   "Residential",
    "Commercial":    "Commercial",
    "Industrial":    "Industrial",
    "Hospital":      "Hospital",
    "School":        "School",
    "OpenField":     "Open Field",
    "Hub":           "Drone Hub ▲",
    "ChargingPad":   "Charging Pad ⚡",
    "MedicalPickup": "Medical Pickup ✚",
}

_ROUTE_PALETTE = [
    "#E53935", "#8E24AA", "#1E88E5", "#00897B",
    "#F4511E", "#039BE5", "#43A047", "#D81B60",
]


# ── Internal helpers ───────────────────────────────────────────────────────────
def _draw_grid_base(
    ax: plt.Axes,
    grid,
    title: str,
    no_fly_cells: Optional[List[Tuple[int, int]]] = None,
) -> None:
    """Draw the coloured 10×10 grid background with coordinate labels."""
    nfz_set = set(no_fly_cells or [])

    for r in range(10):
        for c in range(10):
            cell  = grid[r][c]
            color = ZONE_COLORS.get(cell.zone, "#FFFFFF")

            rect = plt.Rectangle(
                (c, 9 - r), 1, 1,
                facecolor=color, edgecolor="#555555", linewidth=0.5,
                zorder=1,
            )
            ax.add_patch(rect)

            ax.text(
                c + 0.5, 9 - r + 0.15,
                f"{r},{c}", ha="center", va="bottom",
                fontsize=4.5, color="#333333", zorder=2,
            )

            # Special icons for hub / charging / medical
            if cell.is_hub:
                ax.text(c + 0.5, 9 - r + 0.55, "▲",
                        ha="center", va="center",
                        fontsize=9, color="white", fontweight="bold", zorder=3)
            elif cell.is_charging:
                ax.text(c + 0.5, 9 - r + 0.55, "⚡",
                        ha="center", va="center", fontsize=8, zorder=3)
            elif cell.is_medical_pickup:
                ax.text(c + 0.5, 9 - r + 0.55, "✚",
                        ha="center", va="center",
                        fontsize=9, color="white", fontweight="bold", zorder=3)

    # No-fly overlays
    for (r, c) in nfz_set:
        rect = plt.Rectangle(
            (c, 9 - r), 1, 1,
            facecolor="none", edgecolor="#FF1744",
            linewidth=2.5, linestyle="--", zorder=4,
        )
        ax.add_patch(rect)
        ax.text(c + 0.5, 9 - r + 0.55, "✕",
                ha="center", va="center",
                fontsize=14, color="#FF1744", fontweight="bold", zorder=5)

    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.set_xticks(range(11))
    ax.set_yticks(range(11))
    ax.set_xticklabels(list(range(10)) + [""], fontsize=7)
    ax.set_yticklabels([""] + list(range(9, -1, -1)), fontsize=7)
    ax.set_xlabel("Column", fontsize=8)
    ax.set_ylabel("Row",    fontsize=8)
    ax.set_title(title, fontsize=12, fontweight="bold", pad=10)
    ax.set_aspect("equal")
    ax.grid(False)


def _add_zone_legend(ax: plt.Axes) -> None:
    patches = [
        mpatches.Patch(facecolor=ZONE_COLORS[z], edgecolor="#555555",
                       linewidth=0.5, label=LEGEND_LABELS[z])
        for z in ZONE_COLORS
    ]
    ax.legend(
        handles=patches, loc="upper left",
        bbox_to_anchor=(1.01, 1.0),
        fontsize=7, title="Zone Types", title_fontsize=8,
        framealpha=0.9, edgecolor="#AAAAAA",
    )


def _save_or_show(fig: plt.Figure, save_path: Optional[str]) -> None:
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  ✓ Saved → {save_path}")
    else:
        plt.show()
    plt.close(fig)


# ── Public plot functions ──────────────────────────────────────────────────────

def plot_zone_map(grid, save_path: Optional[str] = None) -> None:
    """Coloured zone map with icon overlays and legend."""
    fig, ax = plt.subplots(figsize=(9, 8))
    _draw_grid_base(ax, grid, "AeroNet Lite — City Zone Map")
    _add_zone_legend(ax)
    _save_or_show(fig, save_path)


def plot_route_map(
    grid,
    routes: List[Tuple[str, List[Tuple[int, int]]]],
    no_fly_cells: Optional[List[Tuple[int, int]]] = None,
    save_path: Optional[str] = None,
) -> None:
    """
    Zone map with drone delivery paths overlaid.

    Parameters
    ----------
    routes : list of (drone_id, path) where path is a list of (row, col)
    """
    fig, ax = plt.subplots(figsize=(9, 8))
    _draw_grid_base(ax, grid, "AeroNet Lite — Delivery Route Map", no_fly_cells)

    route_patches = []
    for idx, (drone_id, path) in enumerate(routes):
        if not path or len(path) < 2:
            continue
        color = _ROUTE_PALETTE[idx % len(_ROUTE_PALETTE)]
        xs = [c + 0.5 for _, c in path]
        ys = [9 - r + 0.5 for r, _ in path]

        ax.plot(xs, ys, "-", color=color, linewidth=2.0, zorder=8, alpha=0.85)
        ax.plot(xs[0],  ys[0],  "^", color=color, markersize=9, zorder=9)   # start
        ax.plot(xs[-1], ys[-1], "s", color=color, markersize=9, zorder=9)   # end

        route_patches.append(
            mpatches.Patch(color=color, label=f"{drone_id} route")
        )

    _add_zone_legend(ax)
    if route_patches:
        ax.legend(
            handles=route_patches, loc="lower left",
            bbox_to_anchor=(1.01, 0.0),
            fontsize=7, title="Drone Routes", title_fontsize=8,
            framealpha=0.9, edgecolor="#AAAAAA",
        )
    _save_or_show(fig, save_path)


def plot_demand_heatmap(grid, save_path: Optional[str] = None) -> None:
    """Demand intensity heatmap (YlOrRd colourmap)."""
    matrix = np.array([
        [grid[r][c].demand for c in range(10)]
        for r in range(10)
    ])

    fig, ax = plt.subplots(figsize=(7.5, 6.5))
    im = ax.imshow(matrix, cmap="YlOrRd", aspect="equal",
                   origin="upper", interpolation="nearest")
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Demand (units)", fontsize=9)

    ax.set_title("AeroNet Lite — Demand Heatmap", fontsize=12, fontweight="bold")
    ax.set_xlabel("Column", fontsize=9)
    ax.set_ylabel("Row",    fontsize=9)
    ax.set_xticks(range(10))
    ax.set_yticks(range(10))

    for r in range(10):
        for c in range(10):
            val = matrix[r, c]
            text_color = "white" if val > matrix.max() * 0.65 else "black"
            ax.text(c, r, f"{val:.1f}", ha="center", va="center",
                    fontsize=6, color=text_color)

    _save_or_show(fig, save_path)


def plot_ga_convergence(
    history: List[float],
    save_path: Optional[str] = None,
) -> None:
    """Best-fitness-per-generation curve for the GA fleet selector."""
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(history, color="#1565C0", linewidth=1.8, label="Best fitness")
    ax.fill_between(range(len(history)), history,
                    alpha=0.15, color="#1565C0")
    ax.axhline(y=max(history), color="#E53935", linewidth=1.0,
               linestyle="--", label=f"Max = {max(history):.4f}")
    ax.set_title("Fleet Selector — GA Fitness Convergence",
                 fontsize=12, fontweight="bold")
    ax.set_xlabel("Generation", fontsize=9)
    ax.set_ylabel("Best Fitness Score", fontsize=9)
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    _save_or_show(fig, save_path)


def plot_ml_comparison(
    lr_metrics: Dict,
    rfr_metrics: Dict,
    save_path: Optional[str] = None,
) -> None:
    """Side-by-side MAE / RMSE bar chart comparing the two regression models."""
    models = ["Linear\nRegression", "Random Forest\nRegressor"]
    maes   = [lr_metrics["MAE"],  rfr_metrics["MAE"]]
    rmses  = [lr_metrics["RMSE"], rfr_metrics["RMSE"]]
    x      = np.arange(len(models))
    w      = 0.32

    fig, ax = plt.subplots(figsize=(7, 5))
    b1 = ax.bar(x - w / 2, maes,  w, label="MAE",  color="#42A5F5", zorder=3)
    b2 = ax.bar(x + w / 2, rmses, w, label="RMSE", color="#EF5350", zorder=3)

    ax.bar_label(b1, fmt="%.3f", fontsize=8, padding=2)
    ax.bar_label(b2, fmt="%.3f", fontsize=8, padding=2)
    ax.set_title("Demand Forecasting — Model Comparison",
                 fontsize=12, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(models, fontsize=9)
    ax.set_ylabel("Prediction Error (delivery units)", fontsize=9)
    ax.legend(fontsize=9)
    ax.grid(axis="y", alpha=0.3, zorder=0)
    ax.set_ylim(0, max(max(maes), max(rmses)) * 1.25)
    _save_or_show(fig, save_path)


def plot_confusion_matrix(
    cm: np.ndarray,
    class_names: List[str],
    title: str,
    save_path: Optional[str] = None,
) -> None:
    """Annotated confusion matrix heatmap."""
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=28, ha="right", fontsize=8)
    ax.set_yticklabels(class_names, fontsize=8)
    ax.set_xlabel("Predicted Label", fontsize=9)
    ax.set_ylabel("True Label", fontsize=9)
    ax.set_title(title, fontsize=11, fontweight="bold")

    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]),
                    ha="center", va="center", fontsize=11,
                    color="white" if cm[i, j] > thresh else "black")

    _save_or_show(fig, save_path)


def plot_anomaly_class_distribution(
    df,
    label_map: Dict[int, str],
    save_path: Optional[str] = None,
) -> None:
    """Bar chart showing the class balance of the anomaly dataset."""
    counts = df["label"].value_counts().sort_index()
    labels = [label_map[i] for i in counts.index]
    colors = ["#43A047", "#E53935", "#FB8C00", "#8E24AA"]

    fig, ax = plt.subplots(figsize=(7, 4))
    bars = ax.bar(labels, counts.values, color=colors[:len(labels)], zorder=3)
    ax.bar_label(bars, fmt="%d", fontsize=9, padding=2)
    ax.set_title("Anomaly Dataset — Class Distribution",
                 fontsize=12, fontweight="bold")
    ax.set_xlabel("Anomaly Class", fontsize=9)
    ax.set_ylabel("Sample Count",  fontsize=9)
    ax.grid(axis="y", alpha=0.3, zorder=0)
    _save_or_show(fig, save_path)
