import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
import json

# ── Load model & artefacts ────────────────────────────────────────────────
model         = joblib.load("model.pkl")
scaler        = joblib.load("scaler.pkl")
train_cols_df = pd.read_csv("train_columns.csv")

CONT_COLS = ["age", "trestbps", "chol", "thalach", "oldpeak", "ca"]
CAT_COLS  = ["cp", "restecg", "slope", "thal"]

# ── Pre-populated test patient (real row from dataset) ───────────────────
DEFAULT = {
    "age": 63, "sex": 1, "cp": 3, "trestbps": 145, "chol": 233,
    "fbs": 1, "restecg": 0, "thalach": 150, "exang": 0,
    "oldpeak": 2.3, "slope": 0, "ca": 0, "thal": 1
}

st.set_page_config(page_title="CardioAI — Heart Disease Predictor", page_icon="❤️", layout="wide")

st.markdown("""
<style>
    .main-title { font-size:2rem; font-weight:bold; color:#c0392b; text-align:center; margin-bottom:0.2rem; }
    .sub-title  { text-align:center; color:#7f8c8d; margin-bottom:1.5rem; }
    .risk-high  { background:#fdecea; border-left:6px solid #e74c3c; padding:14px 20px; border-radius:6px; }
    .risk-low   { background:#eafaf1; border-left:6px solid #27ae60; padding:14px 20px; border-radius:6px; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">❤️ CardioAI — Heart Disease Risk Predictor</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">DS-3002 Data Mining · FAST-NUCES · Taha Yasin Shah (23i2624)</div>', unsafe_allow_html=True)
st.markdown("---")

# ── E1: Input Form ────────────────────────────────────────────────────────
st.subheader("🩺 Patient Feature Input")
st.info("Form pre-populated with a real test patient. Click **Predict** to run instantly.")

col1, col2, col3 = st.columns(3)

with col1:
    age      = st.number_input("Age (20–80)",       min_value=20,  max_value=80,  value=DEFAULT["age"])
    sex      = st.selectbox("Sex",                  options=[0,1], index=DEFAULT["sex"], format_func=lambda x: "Male" if x==1 else "Female")
    cp       = st.selectbox("Chest Pain Type (0–3)", [0,1,2,3],   index=DEFAULT["cp"],
                            format_func=lambda x: {0:"Typical Angina",1:"Atypical",2:"Non-anginal",3:"Asymptomatic"}[x])
    trestbps = st.number_input("Resting BP mmHg (94–200)", min_value=94, max_value=200, value=DEFAULT["trestbps"])
    chol     = st.number_input("Cholesterol mg/dl (126–564)", min_value=126, max_value=564, value=DEFAULT["chol"])

with col2:
    fbs     = st.selectbox("Fasting Blood Sugar >120", [0,1], index=DEFAULT["fbs"], format_func=lambda x: "Yes" if x==1 else "No")
    restecg = st.selectbox("Resting ECG (0–2)", [0,1,2], index=DEFAULT["restecg"],
                           format_func=lambda x: {0:"Normal",1:"ST-T Abnormality",2:"LV Hypertrophy"}[x])
    thalach = st.number_input("Max Heart Rate (70–210)", min_value=70, max_value=210, value=DEFAULT["thalach"])
    exang   = st.selectbox("Exercise Angina", [0,1], index=DEFAULT["exang"], format_func=lambda x: "Yes" if x==1 else "No")

with col3:
    oldpeak = st.number_input("ST Depression (0.0–6.2)", min_value=0.0, max_value=6.2, value=float(DEFAULT["oldpeak"]), step=0.1)
    slope   = st.selectbox("ST Slope (0–2)", [0,1,2], index=DEFAULT["slope"],
                           format_func=lambda x: {0:"Upsloping",1:"Flat",2:"Downsloping"}[x])
    ca      = st.number_input("Major Vessels (0–3)", min_value=0, max_value=3, value=DEFAULT["ca"])
    thal    = st.selectbox("Thalassemia (1–3)", [1,2,3], index=DEFAULT["thal"]-1,
                           format_func=lambda x: {1:"Normal",2:"Fixed Defect",3:"Reversible Defect"}[x])

st.markdown("---")
predict_btn = st.button("🔍 Predict", use_container_width=True)

# ── E2: Results Panel ─────────────────────────────────────────────────────
if predict_btn:
    # Build raw input
    raw = pd.DataFrame([{
        "age": age, "sex": sex, "cp": cp, "trestbps": trestbps, "chol": chol,
        "fbs": fbs, "restecg": restecg, "thalach": thalach, "exang": exang,
        "oldpeak": oldpeak, "slope": slope, "ca": ca, "thal": thal
    }])

    # Encode & scale
    enc = pd.get_dummies(raw, columns=CAT_COLS)
    enc = enc.reindex(columns=train_cols_df.columns, fill_value=0)
    enc[CONT_COLS] = scaler.transform(enc[CONT_COLS])
    X_input = enc.values

    pred_class = model.predict(X_input)[0]
    pred_prob  = model.predict_proba(X_input)[0][1]

    st.subheader("🧬 Prediction Results")

    r1, r2 = st.columns([1, 1])

    with r1:
        if pred_class == 1:
            st.markdown(f"""
            <div class="risk-high">
              <h2 style="color:#e74c3c;">🔴 Heart Disease: PRESENT</h2>
              <h3>Confidence: {pred_prob*100:.1f}%</h3>
            </div>""", unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div class="risk-low">
              <h2 style="color:#27ae60;">🟢 Heart Disease: ABSENT</h2>
              <h3>Confidence: {(1-pred_prob)*100:.1f}%</h3>
            </div>""", unsafe_allow_html=True)

        # Plain-English explanation
        st.markdown("---")
        st.subheader("📋 Plain-English Clinical Note")
        if pred_class == 1:
            st.warning(
                f"This patient presents with significant risk indicators: a maximum heart rate of {thalach} bpm "
                f"(lower than expected for age) and an ST depression (oldpeak) of {oldpeak}, both hallmarks "
                f"of reduced myocardial perfusion. Immediate cardiology referral is recommended."
            )
        else:
            st.success(
                f"This patient's clinical profile — max heart rate {thalach} bpm and minimal ST changes — "
                f"suggests low cardiac risk at this time. Routine follow-up and lifestyle monitoring are advised."
            )

    with r2:
        # Top-3 feature importances bar chart
        feat_imp  = model.feature_importances_
        fi_df = pd.DataFrame({"Feature": train_cols_df.columns, "Importance": feat_imp})
        top3_fi = fi_df.nlargest(3, "Importance")

        st.subheader("📊 Top 3 Driving Features")
        fig, ax = plt.subplots(figsize=(5, 3))
        colors = ["#e74c3c", "#e67e22", "#3498db"]
        ax.barh(top3_fi["Feature"], top3_fi["Importance"], color=colors)
        ax.set_xlabel("Importance (Mean Decrease Impurity)")
        ax.set_title("Top 3 Features Driving Prediction")
        plt.tight_layout()
        st.pyplot(fig)

