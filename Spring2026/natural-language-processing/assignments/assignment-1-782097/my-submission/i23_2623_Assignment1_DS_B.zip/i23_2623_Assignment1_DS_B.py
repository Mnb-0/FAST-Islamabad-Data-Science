import os
import re
import json
import requests
import numpy as np
import matplotlib.pyplot as plt
import streamlit as st
from bs4 import BeautifulSoup
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

# CONFIG

BASE_URL = "https://www.bbc.com/urdu"
HEADERS = {"User-Agent": "Mozilla/5.0"}
ARTICLE_COUNT = 300

# SCRAPER
def fetch_article(url):
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(r.text, "html.parser")
        title_tag = soup.find("h1")
        if not title_tag: return None
        title = title_tag.text.strip()
        paragraphs = soup.find_all("p")
        body = " ".join(p.text.strip() for p in paragraphs)
        if len(body) < 100: return None
        date_tag = soup.find("time")
        publish_date = date_tag.text.strip() if date_tag else "Unknown"
        return title, publish_date, body
    except:
        return None

def scrape_bbc_urdu_articles(target_count=ARTICLE_COUNT):
    r = requests.get(f"{BASE_URL}/urdu", headers=HEADERS)
    soup = BeautifulSoup(r.text, "html.parser")
    links = set()
    for a in soup.find_all("a", href=True):
        link = a["href"]
        if "/urdu/articles/" in link:
            if not link.startswith("http"): link = BASE_URL + link
            links.add(link)

    metadata = {}
    raw_text = ""
    print("Fetching articles...")

    with ThreadPoolExecutor(max_workers=12) as executor:
        futures = {executor.submit(fetch_article, url): url for url in list(links)[:target_count]}
        count = 1
        for future in as_completed(futures):
            result = future.result()
            if not result: continue
            title, publish_date, body = result
            metadata[str(count)] = {"title": title, "publish_date": publish_date}
            raw_text += f"[{count}]\n{body}\n\n"
            print(f"Scraped {count}")
            count += 1

    with open("Metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=4)
    with open("raw.txt", "w", encoding="utf-8") as f:
        f.write(raw_text)
    return metadata, raw_text

# PREPROCESSING
def preprocess_urdu_corpus(raw_data):
    processed_output = ""
    articles = re.split(r'\[\d+\]', raw_data)
    idx = 1
    for content in articles:
        if not content.strip(): continue
        text = re.sub(r'http\S+|www\S+', '', content)
        text = re.sub(r'[a-zA-Z0-9]', '', text)
        text = re.sub(r'[\u064B-\u0652\u0670]', '', text)
        text = re.sub(r'[^\u0600-\u06FF\s۔؟!]', '', text)
        sentences = re.split(r'([۔؟!])', text)
        segmented = ""
        for i in range(0, len(sentences)-1, 2):
            s = (sentences[i] + sentences[i+1]).strip()
            if s: segmented += s + "\n"
        processed_output += f"[{idx}]\n{segmented}\n"
        idx += 1
    with open("cleaned.txt", "w", encoding="utf-8") as f:
        f.write(processed_output)
    return processed_output

# URDU NLP TOOLS
class UrduLinguisticTools:
    SUFFIXES = ['وں','یں','ات','ہ','گی','نے','سے','کا','کی','کے']
    LEMMATIZE_MAP = {
        'لڑکیاں':'لڑکی','کتابوں':'کتاب','کتابیں':'کتاب',
        'اچھی':'اچھا','بڑی':'بڑا','نیوز':'خبر'
    }

    def tokenize(self, text):
        text = re.sub(r'[\u0660-\u0669\u06F0-\u06F90-9]+', '<NUM>', text)
        tokens = re.findall(r'<NUM>|[\u0600-\u06FF]+|[۔؟!]', text)
        tokens = ["<s>", "<s>"] + tokens + ["</s>"]
        return tokens

    def stem(self, word):
        for suf in self.SUFFIXES:
            if word.endswith(suf) and len(word) > 3: return word[:-len(suf)]
        return word

    def lemmatize(self, word):
        return self.LEMMATIZE_MAP.get(word, word)

# N-GRAM LANGUAGE MODEL
class NgramLanguageModel:
    def __init__(self, corpus_text, ngram='trigram'):
        self.tools = UrduLinguisticTools()
        self.ngram_type = ngram
        sentences = re.split(r'[۔؟!]\s+', corpus_text)
        tokens = []
        for s in sentences:
            s = s.strip()
            if not s: continue
            toks = [self.tools.lemmatize(self.tools.stem(t)) for t in self.tools.tokenize(s)]
            tokens += ["<s>", "<s>"] + toks + ["</s>"]
        self.tokens = tokens
        self.unigrams = Counter(tokens)
        self.bigrams = Counter(zip(tokens, tokens[1:]))
        self.trigrams = Counter(zip(tokens, tokens[1:], tokens[2:]))
        self.V = len(self.unigrams)

    def get_trigram_prob(self, w1, w2, w3):
        tri = self.trigrams.get((w1, w2, w3), 0)
        bi = self.bigrams.get((w1, w2), 0)
        return (tri + 1) / (bi + self.V)

    def get_bigram_prob(self, w1, w2):
        bi = self.bigrams.get((w1, w2), 0)
        uni = self.unigrams.get(w1, 0)
        return (bi + 1) / (uni + self.V)

    def weighted_choice(self, counter, temp=0.7):
        words, counts = zip(*counter.items())
        probs = np.array(counts, dtype=float) ** (1/temp)
        probs /= probs.sum()
        return np.random.choice(words, p=probs)

    def generate_article(self, seed_text, max_words=220):
        seed_tokens = [self.tools.lemmatize(self.tools.stem(t)) for t in self.tools.tokenize(seed_text)]
        result = ["<s>", "<s>"] + seed_tokens[-2:]

        for _ in range(max_words):
            w1, w2 = result[-2], result[-1]

            if self.ngram_type == 'trigram':
                tri_candidates = Counter({w3: c for (a,b,w3), c in self.trigrams.items() if a==w1 and b==w2})
                if tri_candidates:
                    next_word = self.weighted_choice(tri_candidates)
                else:
                    bi_candidates = Counter({b: c for (a,b), c in self.bigrams.items() if a==w2})
                    next_word = self.weighted_choice(bi_candidates) if bi_candidates else self.weighted_choice(self.unigrams)
            else:
                bi_candidates = Counter({b: c for (a,b), c in self.bigrams.items() if a==w2})
                next_word = self.weighted_choice(bi_candidates) if bi_candidates else self.weighted_choice(self.unigrams)

            result.append(next_word)
            if next_word == "</s>" and len(result) > 120: break

        output = [w for w in result if w not in ("<s>", "</s>")]
        text = " ".join(output)
        text = re.sub(r'\s+([۔؟!])', r'\1', text)
        return text

# PERPLEXITY
def calculate_perplexity(model):
    log_prob = 0
    N = len(model.tokens)
    for i in range(2,N):
        if model.ngram_type=='trigram':
            p = model.get_trigram_prob(model.tokens[i-2], model.tokens[i-1], model.tokens[i])
        else:
            p = model.get_bigram_prob(model.tokens[i-1], model.tokens[i])
        log_prob += np.log2(p)
    return 2 ** (-(1/N) * log_prob)

# STREAMLIT UI + Live Charts
def run_ui(model, corpus_text):
    st.set_page_config(layout="wide")
    st.markdown("<h1 style='text-align:center;'>BBC Urdu News Generator</h1>", unsafe_allow_html=True)
    st.markdown("<style>.stTextInput,.stTextArea{direction:RTL;text-align:right;}</style>", unsafe_allow_html=True)

    seed = st.text_input("Seed Text","پاکستان میں مہنگائی کی شرح میں")
    ngram_type = st.selectbox("Select Language Model", ["Trigram","Bigram"])
    num_articles = st.slider("Number of Articles", 1, 3, 3)

    # --- Calculate Perplexities and show bar chart
    trigram_model = NgramLanguageModel(corpus_text, ngram='trigram')
    bigram_model = NgramLanguageModel(corpus_text, ngram='bigram')
    perplexities = {
        'Trigram': round(calculate_perplexity(trigram_model),2),
        'Bigram': round(calculate_perplexity(bigram_model),2)
    }

    st.sidebar.write("Model Perplexities:")
    st.sidebar.write(perplexities)

    fig, ax = plt.subplots()
    ax.bar(perplexities.keys(), perplexities.values(), color=['skyblue','orange'])
    ax.set_ylabel('Perplexity')
    ax.set_title('Bigram vs Trigram Model Comparison')
    st.sidebar.pyplot(fig)

    # --- Generate Articles
    if st.button("Generate"):
        articles=[]
        for _ in range(num_articles):
            model.ngram_type = ngram_type.lower()
            text = model.generate_article(seed)
            articles.append(text)
        for i, art in enumerate(articles,1):
            st.subheader(f"Article {i}")
            st.write(art)

# MAIN
if __name__=="__main__":
    if os.path.exists("cleaned.txt"):
        with open("cleaned.txt", encoding="utf-8") as f:
            cleaned_corpus = f.read()
    else:
        metadata_db, raw_corpus = scrape_bbc_urdu_articles()
        cleaned_corpus = preprocess_urdu_corpus(raw_corpus)

    model = NgramLanguageModel(cleaned_corpus)
    run_ui(model, cleaned_corpus)
