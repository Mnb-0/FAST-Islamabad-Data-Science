# NLP Assignment 2 - File by File Solution

This project implements the full **Neural NLP Pipeline** in PyTorch from scratch, following the assignment requirements: TF-IDF, PPMI, Skip-gram Word2Vec, BiLSTM POS/NER, CRF, and a custom Transformer encoder.

## Folder Structure

- `settings.py` - paths, constants, tags, hyperparameters
- `utils/io_helpers.py` - reading data, tokenization, vocab building, helpers
- `utils/evaluation_metrics.py` - accuracy, macro-F1, confusion matrix, NER entity scoring, MRR
- `utils/plot_helpers.py` - plots for curves, confusion matrix, attention heatmaps
- `models/skipgram_model.py` - Skip-gram with negative sampling
- `models/crf_layer.py` - CRF layer + Viterbi decoding
- `models/bilstm_sequence_tagger.py` - BiLSTM sequence labeling model for POS/NER
- `models/transformer_classifier.py` - custom Transformer encoder modules
- `build_tfidf_ppmi.py` - TF-IDF, PPMI, t-SNE, top words, PPMI neighbours
- `train_word2vec.py` - train Skip-gram Word2Vec and save embeddings
- `evaluate_embeddings.py` - nearest neighbours, analogies, MRR summary
- `prepare_sequence_data.py` - build POS/NER annotations and CoNLL files
- `train_pos_tagger.py` - train/evaluate POS BiLSTM (frozen + fine-tuned embeddings)
- `train_ner_tagger.py` - train/evaluate NER BiLSTM with and without CRF
- `run_ablation_study.py` - run A1-A4 ablations
- `prepare_classification_data.py` - build 5-class topic classification split
- `train_transformer_classifier.py` - train/evaluate Transformer classifier and save heatmaps
- `run_pipeline.py` - run every step in sequence

## Required Input Files
Put these files inside the `data/` folder:
- `cleaned.txt`
- `raw.txt`
- `Metadata.json`

## Run

```bash
pip install -r requirements.txt
python run_pipeline.py
```

## Important Notes

1. This code assumes **one article per line** in `cleaned.txt` and `raw.txt`.
2. `Metadata.json` can be a list of dictionaries. The loader is intentionally flexible, but you may need to map keys like `text`, `title`, `content`, `topic`, or `category` to your exact format.
3. For full marks, expand the **POS lexicon** and **NER gazetteers** in `prepare_sequence_data.py` to match the assignment minimum counts.
4. Replace the placeholder manually labelled word-pair list in `evaluate_embeddings.py` with your actual 20 labelled pairs for MRR.
5. The report and notebook are not included here; this package focuses on the code files.
