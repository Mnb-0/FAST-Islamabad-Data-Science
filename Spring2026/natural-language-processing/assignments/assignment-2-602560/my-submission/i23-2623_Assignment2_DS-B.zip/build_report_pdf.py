import argparse
import json
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

ROOT = Path(__file__).resolve().parent
OUTPUTS_DIR = ROOT / "outputs"
PLOTS_DIR = ROOT / "plots"


def load_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def fmt(value: Any, ndigits: int = 4) -> str:
    if isinstance(value, float):
        return f"{value:.{ndigits}f}"
    return str(value)


def style_sheet():
    base = getSampleStyleSheet()
    base.add(
        ParagraphStyle(
            name="TitleMain",
            parent=base["Title"],
            fontName="Times-Bold",
            fontSize=18,
            leading=22,
            spaceAfter=10,
        )
    )
    base.add(
        ParagraphStyle(
            name="Body15",
            parent=base["BodyText"],
            fontName="Times-Roman",
            fontSize=12,
            leading=18,
            spaceAfter=8,
        )
    )
    base.add(
        ParagraphStyle(
            name="HeadingReq",
            parent=base["Heading2"],
            fontName="Times-Bold",
            fontSize=14,
            leading=18,
            spaceBefore=6,
            spaceAfter=6,
        )
    )
    return base


def add_heading(story: List[Any], text: str, styles):
    story.append(Paragraph(text, styles["HeadingReq"]))


def add_body(story: List[Any], text: str, styles):
    story.append(Paragraph(text, styles["Body15"]))


def safe_table(data: List[List[Any]], col_widths: Optional[List[float]] = None) -> Table:
    tbl = Table(data, colWidths=col_widths, hAlign="LEFT")
    tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("FONTNAME", (0, 0), (-1, 0), "Times-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Times-Roman"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    return tbl


def add_image_if_exists(
    story: List[Any],
    styles,
    image_path: Path,
    caption: str,
    max_width: float = 6.0 * inch,
    max_height: float = 3.8 * inch,
):
    if not image_path.exists():
        return

    # Preserve aspect ratio and avoid upscaling so plots are not visually stretched.
    orig_w, orig_h = ImageReader(str(image_path)).getSize()
    scale = min(max_width / orig_w, max_height / orig_h, 1.0)
    draw_w = orig_w * scale
    draw_h = orig_h * scale

    img = Image(str(image_path))
    img.drawWidth = draw_w
    img.drawHeight = draw_h
    story.append(img)
    story.append(Paragraph(caption, styles["Body15"]))


def add_all_images(story: List[Any], styles, image_paths: List[Path], max_width: float = 5.5 * inch):
    for image_path in image_paths:
        add_image_if_exists(story, styles, image_path, f"Figure: {image_path.name}", max_width=max_width)


def top_items(d: Dict[str, Any], n: int = 5) -> List[Tuple[str, Any]]:
    items = list(d.items())
    return items[:n]


def section_overview(story: List[Any], styles, args):
    add_heading(story, "Overview", styles)
    add_body(
        story,
        (
            "This report summarizes implementation and results for CS-4063 Assignment 2 "
            "(Neural NLP Pipeline) in PyTorch, following the required sections and rubric. "
            "All figures referenced are generated from the codebase outputs."
        ),
        styles,
    )
    add_body(
        story,
        f"Date: {date.today().isoformat()}",
        styles,
    )


def section_part1(story: List[Any], styles, include_figures: bool = False):
    add_heading(story, "Part 1 Results", styles)

    tfidf_words = load_json(OUTPUTS_DIR / "top_tfidf_words_per_topic.json") or {}
    nn_ppmi = load_json(OUTPUTS_DIR / "ppmi_nearest_neighbors.json") or {}
    w2v_nn = load_json(OUTPUTS_DIR / "w2v_neighbors.json") or {}
    w2v_analogies = load_json(OUTPUTS_DIR / "w2v_analogies.json") or {}
    emb_eval = load_json(OUTPUTS_DIR / "embedding_eval_summary.json") or {}

    add_body(
        story,
        "TF-IDF and PPMI matrices were generated and saved. The table below lists sample top words per topic category from TF-IDF.",
        styles,
    )
    if tfidf_words:
        rows = [["Topic", "Top Words (sample)"]]
        for topic, words in tfidf_words.items():
            rows.append([str(topic), ", ".join(words)])
        story.append(safe_table(rows, col_widths=[1.4 * inch, 5.1 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if nn_ppmi:
        add_body(story, "PPMI nearest neighbours:", styles)
        rows = [["Query", "Top-5 Neighbours"]]
        for q, vals in nn_ppmi.items():
            rows.append([q, ", ".join(vals[:5])])
        story.append(safe_table(rows, col_widths=[1.5 * inch, 5.0 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if include_figures:
        part1_images = [
            PLOTS_DIR / "ppmi_tsne.png",
            PLOTS_DIR / "word2vec_loss.png",
        ]
        add_all_images(story, styles, [p for p in part1_images if p.exists()], max_width=5.3 * inch)

    if w2v_nn:
        add_body(story, "Word2Vec nearest-neighbour evaluation:", styles)
        rows = [["Query", "Top-10 Neighbours"]]
        for q, vals in w2v_nn.items():
            rows.append([q, ", ".join(vals[:10])])
        story.append(safe_table(rows, col_widths=[1.5 * inch, 5.0 * inch]))
        story.append(Spacer(1, 0.12 * inch))
    if w2v_analogies:
        rows = [["Analogy", "Top-3 Predictions"]]
        for expr, vals in w2v_analogies.items():
            rows.append([expr, ", ".join(vals[:3])])
        story.append(safe_table(rows, col_widths=[2.4 * inch, 4.1 * inch]))
        story.append(Spacer(1, 0.12 * inch))
    if emb_eval:
        add_body(story, f"MRR (reported): {fmt(emb_eval.get('mrr', 'N/A'))}", styles)


def section_part2(story: List[Any], styles, include_figures: bool = False):
    add_heading(story, "Part 2 Results", styles)

    seq_dist = load_json(OUTPUTS_DIR / "sequence_label_distributions.json") or {}
    pos_res = load_json(OUTPUTS_DIR / "pos_results.json") or {}
    ner_res = load_json(OUTPUTS_DIR / "ner_results.json") or {}
    ablation_res = load_json(OUTPUTS_DIR / "ablation_results.json") or {}

    add_body(
        story,
        "Sequence-labeling datasets (POS/NER) were prepared with train/validation/test splits and class-distribution summaries.",
        styles,
    )

    if seq_dist:
        rows = [["Split", "Labels (counts)"]]
        for split_name, labels in seq_dist.items():
            label_pairs = list(labels.items())
            rows.append([split_name, ", ".join(f"{k}:{v}" for k, v in label_pairs)])
        story.append(safe_table(rows, col_widths=[1.8 * inch, 4.7 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if pos_res:
        rows = [["Mode", "Accuracy", "Macro-F1"]]
        for mode, vals in pos_res.items():
            rows.append([mode, fmt(vals.get("accuracy", "N/A")), fmt(vals.get("macro_f1", "N/A"))])
        story.append(safe_table(rows, col_widths=[2.0 * inch, 2.2 * inch, 2.2 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if ner_res:
        rows = [["Model", "Overall Precision", "Overall Recall", "Overall F1"]]
        for model_name, rep in ner_res.items():
            overall = rep.get("overall", {})
            rows.append(
                [
                    model_name,
                    fmt(overall.get("precision", "N/A")),
                    fmt(overall.get("recall", "N/A")),
                    fmt(overall.get("f1", "N/A")),
                ]
            )
        story.append(safe_table(rows, col_widths=[1.8 * inch, 1.6 * inch, 1.6 * inch, 1.5 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if ablation_res:
        rows = [["Ablation", "Precision", "Recall", "F1"]]
        for name, vals in ablation_res.items():
            rows.append([name, fmt(vals.get("precision", "N/A")), fmt(vals.get("recall", "N/A")), fmt(vals.get("f1", "N/A"))])
        story.append(safe_table(rows, col_widths=[2.2 * inch, 1.5 * inch, 1.5 * inch, 1.4 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if include_figures:
        part2_images = [
            PLOTS_DIR / "pos_loss_frozen.png",
            PLOTS_DIR / "pos_loss_finetuned.png",
            PLOTS_DIR / "pos_confmat_frozen.png",
            PLOTS_DIR / "pos_confmat_finetuned.png",
            PLOTS_DIR / "ner_loss_crf.png",
            PLOTS_DIR / "ner_loss_softmax.png",
        ]
        add_all_images(story, styles, [p for p in part2_images if p.exists()], max_width=5.3 * inch)


def section_part3(story: List[Any], styles, include_figures: bool = False):
    add_heading(story, "Part 3 Results", styles)

    cls_dist = load_json(OUTPUTS_DIR / "topic_class_distribution.json") or {}
    transformer_res = load_json(OUTPUTS_DIR / "transformer_results.json") or {}

    add_body(
        story,
        "A 5-class topic classification dataset was created and used to train a custom Transformer encoder with CLS-based classification.",
        styles,
    )

    if cls_dist:
        rows = [["Split", "Category Counts"]]
        for split_name, counts in cls_dist.items():
            rows.append([split_name, ", ".join(f"{k}:{v}" for k, v in counts.items())])
        story.append(safe_table(rows, col_widths=[1.7 * inch, 4.8 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if transformer_res:
        rows = [["Metric", "Value"], ["Accuracy", fmt(transformer_res.get("accuracy", "N/A"))], ["Macro-F1", fmt(transformer_res.get("macro_f1", "N/A"))]]
        story.append(safe_table(rows, col_widths=[2.5 * inch, 2.5 * inch]))
        story.append(Spacer(1, 0.12 * inch))

    if include_figures:
        part3_images = [
            PLOTS_DIR / "transformer_loss.png",
            PLOTS_DIR / "transformer_accuracy.png",
            PLOTS_DIR / "transformer_confmat.png",
            PLOTS_DIR / "attn_article1_head1.png",
            PLOTS_DIR / "attn_article1_head2.png",
            PLOTS_DIR / "attn_article2_head1.png",
            PLOTS_DIR / "attn_article2_head2.png",
            PLOTS_DIR / "attn_article3_head1.png",
            PLOTS_DIR / "attn_article3_head2.png",
        ]
        add_all_images(story, styles, [p for p in part3_images if p.exists()], max_width=5.2 * inch)


def section_conclusion(story: List[Any], styles):
    add_heading(story, "Conclusion", styles)
    add_body(
        story,
        (
            "The end-to-end pipeline produces all major artifacts required by the assignment: "
            "embedding matrices, sequence-labeling models, transformer classifier outputs, "
            "and evaluation plots. The included tables summarize key quantitative outcomes "
            "for Parts 1-3."
        ),
        styles,
    )
    


def build_report(output_pdf: Path, github_url: Optional[str], include_figures: bool = True):
    output_pdf.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(output_pdf),
        pagesize=A4,
        leftMargin=0.95 * inch,
        rightMargin=0.95 * inch,
        topMargin=0.85 * inch,
        bottomMargin=0.85 * inch,
        title="CS-4063 Assignment 2 Report",
        author="Auto-generated by build_report_pdf.py",
    )

    global styles
    styles = style_sheet()

    story: List[Any] = []
    story.append(Paragraph("CS-4063 Assignment 2 Report", styles["TitleMain"]))
    story.append(Paragraph("Neural NLP Pipeline (PyTorch from scratch)", styles["Body15"]))
    story.append(Spacer(1, 0.08 * inch))

    args_obj = argparse.Namespace(github_url=github_url)
    section_overview(story, styles, args_obj)
    section_part1(story, styles, include_figures=include_figures)
    section_part2(story, styles, include_figures=include_figures)
    section_part3(story, styles, include_figures=include_figures)
    section_conclusion(story, styles)

    doc.build(story)


def parse_args():
    parser = argparse.ArgumentParser(description="Generate Assignment 2 PDF report from project outputs.")
    parser.add_argument("--output", type=str, default="report.pdf", help="Output PDF path (default: report.pdf)")
    parser.add_argument("--github-url", type=str, default="", help="Repository URL to include in report")
    parser.add_argument("--include-figures", action="store_true", default=True, help="Embed all available figures (enabled by default)")
    parser.add_argument("--no-figures", action="store_false", dest="include_figures", help="Skip embedding figures")
    return parser.parse_args()


def main():
    args = parse_args()
    output_pdf = (ROOT / args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output)
    build_report(output_pdf, args.github_url.strip() or None, include_figures=args.include_figures)
    print(f"Report generated: {output_pdf}")


if __name__ == "__main__":
    main()
