import json

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from settings import EMB_DIR, OUTPUT_DIR
from utils.evaluation_metrics import mean_reciprocal_rank


QUERIES = ['Pakistan', 'Hukumat', 'Adalat', 'Maeeshat', 'Fauj', 'Sehat', 'Taleem', 'Aabadi']
ANALOGIES = [
    ('mard', 'badshah', 'aurat'),
    ('lahore', 'punjab', 'karachi'),
    ('doctor', 'hospital', 'talibilm'),
    ('cricket', 'player', 'hukumat'),
    ('school', 'taleem', 'hospital'),
    ('fauj', 'sipahi', 'adalat'),
    ('vote', 'intikhab', 'qanoon'),
    ('bank', 'maeeshat', 'hospital'),
    ('pakistan', 'islamabad', 'sindh'),
    ('teacher', 'class', 'doctor'),
]


def load_vectors():
    with open(EMB_DIR / 'word2idx.json', 'r', encoding='utf-8') as f:
        word2idx = json.load(f)
    idx2word = {i: w for w, i in word2idx.items()}
    w2v = np.load(EMB_DIR / 'embeddings_w2v.npy')
    ppmi = np.load(EMB_DIR / 'ppmi_matrix.npy')
    return word2idx, idx2word, w2v, ppmi


def resolve_token(query, word2idx):
    if query in word2idx:
        return query
    lowered = query.lower()
    if lowered in word2idx:
        return lowered
    titled = query.title()
    if titled in word2idx:
        return titled
    return None


def nearest_neighbors(vectors, word2idx, idx2word, query, top_k=10):
    resolved = resolve_token(query, word2idx)
    if resolved is None:
        return []
    q_idx = word2idx[resolved]
    sims = cosine_similarity(vectors[q_idx:q_idx+1], vectors)[0]
    order = np.argsort(-sims)
    return [idx2word[i] for i in order if i != q_idx][:top_k]


def run_analogies(vectors, word2idx, idx2word):
    results = {}
    norm = vectors / (np.linalg.norm(vectors, axis=1, keepdims=True) + 1e-12)
    for a, b, c in ANALOGIES:
        resolved = [resolve_token(w, word2idx) for w in [a, b, c]]
        if any(w is None for w in resolved):
            results[f'{a}:{b}::{c}:?'] = []
            continue
        a_r, b_r, c_r = resolved
        vec = norm[word2idx[b_r]] - norm[word2idx[a_r]] + norm[word2idx[c_r]]
        sims = norm @ vec
        for w in [a_r, b_r, c_r]:
            sims[word2idx[w]] = -1e9
        best = np.argsort(-sims)[:3]
        results[f'{a}:{b}::{c}:?'] = [idx2word[i] for i in best]
    return results


def main():
    word2idx, idx2word, w2v, ppmi = load_vectors()
    nn_out = {q: nearest_neighbors(w2v, word2idx, idx2word, q, top_k=10) for q in QUERIES}
    analogy_out = run_analogies(w2v, word2idx, idx2word)

    # Placeholder labelled pairs for MRR. Replace with manually labelled pairs from your notebook.
    labelled_tokens = [('Pakistan', 'Islamabad'), ('Cricket', 'Match'), ('Hospital', 'Doctor')]
    pairs = []
    for a, b in labelled_tokens:
        a_r = resolve_token(a, word2idx)
        b_r = resolve_token(b, word2idx)
        if a_r is not None and b_r is not None:
            pairs.append((word2idx[a_r], word2idx[b_r]))
    sim = cosine_similarity(w2v)
    mrr = mean_reciprocal_rank(sim, pairs)

    with open(OUTPUT_DIR / 'w2v_neighbors.json', 'w', encoding='utf-8') as f:
        json.dump(nn_out, f, ensure_ascii=False, indent=2)
    with open(OUTPUT_DIR / 'w2v_analogies.json', 'w', encoding='utf-8') as f:
        json.dump(analogy_out, f, ensure_ascii=False, indent=2)
    with open(OUTPUT_DIR / 'embedding_eval_summary.json', 'w', encoding='utf-8') as f:
        json.dump({'mrr': mrr}, f, indent=2)

    print('Saved nearest neighbors, analogies, and MRR summary.')


if __name__ == '__main__':
    main()
