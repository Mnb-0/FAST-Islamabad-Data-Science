import json
import random
import string
from collections import Counter, defaultdict
from pathlib import Path

from sklearn.model_selection import train_test_split

from settings import CLEANED_PATH, METADATA_PATH, DATA_DIR, OUTPUT_DIR, POS_TAGS, NER_TAGS, SEED
from utils.io_helpers import read_lines, sentence_split, load_metadata, set_seed

# Extend these lexicons/gazetteers in your final submission to meet the assignment counts.
PRONOUNS = {'میں','ہم','آپ','وہ','یہ','تم','اس','ان'}
DETERMINERS = {'ایک','یہ','وہ','اس','ان','تمام','ہر'}
CONJUNCTIONS = {'اور','یا','لیکن','مگر','کہ'}
POSTPOSITIONS = {'میں','پر','سے','کو','کا','کی','کے','تک'}
ADVERBS = {'بہت','کم','زیادہ','جلد','آج','کل'}
ADJECTIVES = {'اچھا','بری','بڑا','چھوٹا','اہم','قومی','بین','عالمی'}
VERB_SUFFIXES = ('نا','تا','تی','تے','گا','گی','گے')
ORG_GAZ = {'اقوام','متحدہ','پی','سی','بی','سپریم','کورٹ','پارلیمنٹ','حکومت'}
LOC_GAZ = {'پاکستان','لاہور','کراچی','اسلام','آباد','پشاور','کوئٹہ','سندھ','پنجاب','بلوچستان'}
PER_GAZ = {'عمران','شہباز','نواز','بلاول','بابر','رضوان','افریدی'}
MISC_GAZ = {'رمضان','عید','ورلڈ','کپ','ایشیا'}
PUNCS = set(string.punctuation) | {'،', '۔', '؛', '؟', '!', ':'}


def infer_topic(meta_item):
    if isinstance(meta_item, dict):
        for key in ['topic', 'category', 'label', 'class']:
            if key in meta_item:
                return str(meta_item[key])
    return 'unknown'


def pos_tag_token(tok: str) -> str:
    if tok in PUNCS:
        return 'PUNC'
    if tok.isdigit():
        return 'NUM'
    if tok in PRONOUNS:
        return 'PRON'
    if tok in DETERMINERS:
        return 'DET'
    if tok in CONJUNCTIONS:
        return 'CONJ'
    if tok in POSTPOSITIONS:
        return 'POST'
    if tok in ADVERBS:
        return 'ADV'
    if tok in ADJECTIVES:
        return 'ADJ'
    if tok.endswith(VERB_SUFFIXES):
        return 'VERB'
    if len(tok) == 1 and tok not in {'و'}:
        return 'UNK'
    return 'NOUN'


def ner_tags(tokens):
    tags = ['O'] * len(tokens)
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in PER_GAZ:
            tags[i] = 'B-PER'
        elif tok in LOC_GAZ:
            tags[i] = 'B-LOC'
        elif tok in ORG_GAZ:
            tags[i] = 'B-ORG'
        elif tok in MISC_GAZ:
            tags[i] = 'B-MISC'
        i += 1
    return tags


def write_conll(samples, path: Path, task: str):
    with open(path, 'w', encoding='utf-8') as f:
        for sample in samples:
            for tok, label in zip(sample['tokens'], sample[task]):
                f.write(f'{tok}\t{label}\n')
            f.write('\n')


def label_distribution(samples, key):
    c = Counter()
    for s in samples:
        c.update(s[key])
    return dict(c)


def main():
    set_seed()
    docs = read_lines(CLEANED_PATH)
    meta = load_metadata(METADATA_PATH) if METADATA_PATH.exists() else [{'topic': 'unknown'} for _ in docs]

    sentences_by_topic = defaultdict(list)
    for doc, m in zip(docs, meta):
        topic = infer_topic(m)
        for sent in sentence_split(doc):
            if len(sent) >= 3:
                sentences_by_topic[topic].append(sent)

    topics = list(sentences_by_topic.keys())
    chosen_topics = topics[:3] if len(topics) >= 3 else topics
    samples = []
    for topic in chosen_topics:
        picks = random.sample(sentences_by_topic[topic], min(100, len(sentences_by_topic[topic])))
        for sent in picks:
            samples.append({
                'tokens': sent,
                'pos': [pos_tag_token(t) for t in sent],
                'ner': ner_tags(sent),
                'topic': topic,
            })

    remaining = 500 - len(samples)
    pool = [s for topic_sents in sentences_by_topic.values() for s in topic_sents]
    for sent in random.sample(pool, min(remaining, len(pool))):
        samples.append({
            'tokens': sent,
            'pos': [pos_tag_token(t) for t in sent],
            'ner': ner_tags(sent),
            'topic': 'mixed',
        })

    if not samples:
        raise ValueError('No sentence samples were generated. Check cleaned data format and sentence splitting rules.')

    topic_labels = [s['topic'] for s in samples]
    topic_counts = Counter(topic_labels)
    can_stratify = len(topic_counts) > 1 and min(topic_counts.values()) >= 2
    train_samples, temp_samples = train_test_split(
        samples,
        test_size=0.30,
        random_state=SEED,
        stratify=topic_labels if can_stratify else None,
    )
    temp_labels = [s['topic'] for s in temp_samples]
    temp_counts = Counter(temp_labels)
    can_stratify_temp = len(temp_counts) > 1 and min(temp_counts.values()) >= 2
    val_samples, test_samples = train_test_split(
        temp_samples,
        test_size=0.50,
        random_state=SEED,
        stratify=temp_labels if can_stratify_temp else None,
    )

    write_conll(train_samples, DATA_DIR / 'pos_train.conll', 'pos')
    write_conll(val_samples, DATA_DIR / 'pos_val.conll', 'pos')
    write_conll(test_samples, DATA_DIR / 'pos_test.conll', 'pos')
    write_conll(train_samples, DATA_DIR / 'ner_train.conll', 'ner')
    write_conll(val_samples, DATA_DIR / 'ner_val.conll', 'ner')
    write_conll(test_samples, DATA_DIR / 'ner_test.conll', 'ner')

    with open(OUTPUT_DIR / 'sequence_label_distributions.json', 'w', encoding='utf-8') as f:
        json.dump({
            'pos_train': label_distribution(train_samples, 'pos'),
            'pos_val': label_distribution(val_samples, 'pos'),
            'pos_test': label_distribution(test_samples, 'pos'),
            'ner_train': label_distribution(train_samples, 'ner'),
            'ner_val': label_distribution(val_samples, 'ner'),
            'ner_test': label_distribution(test_samples, 'ner'),
        }, f, ensure_ascii=False, indent=2)
    print('Saved POS/NER conll splits and label distributions.')


if __name__ == '__main__':
    main()
