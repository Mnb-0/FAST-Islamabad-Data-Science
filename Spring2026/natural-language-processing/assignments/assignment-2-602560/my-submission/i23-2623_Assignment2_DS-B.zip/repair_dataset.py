import os

def fix_data():
    # Define the file path
    file_path = os.path.join('data', 'cleaned.txt')
    
    # Read the entire file content
    with open(file_path, 'r', encoding='utf-8') as f:
        text = f.read()

    # Replace tags like [1] to [50] with a unique delimiter for splitting
    for i in range(1, 55):
        tag = f"[{i}]"
        text = text.replace(tag, "|||SPLIT|||")

    # Split the entire text into separate articles using the delimiter
    docs = text.split("|||SPLIT|||")
    
    articles = []
    for doc in docs:
        # Remove extra spaces and newlines, compressing the article into a single line
        clean_doc = " ".join(doc.split())
        if clean_doc:
            articles.append(clean_doc)

    # Overwrite the file with the compressed articles
    with open(file_path, 'w', encoding='utf-8') as f:
        for article in articles:
            f.write(article + '\n')

    print(f"Data reformatted: Compressed into {len(articles)} documents.")

if __name__ == '__main__':
    fix_data()