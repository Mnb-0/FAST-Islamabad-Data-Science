import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = [
    'build_tfidf_ppmi.py',
    'train_word2vec.py',
    'evaluate_embeddings.py',
    'prepare_sequence_data.py',
    'train_pos_tagger.py',
    'train_ner_tagger.py',
    'run_ablation_study.py',
    'prepare_classification_data.py',
    'train_transformer_classifier.py',
]

for script in SCRIPTS:
    print(f'Running {script}')
    subprocess.run([sys.executable, str(ROOT / script)], check=True)
