import json

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from settings import DATA_DIR, EMB_DIR, MODEL_DIR, OUTPUT_DIR, PLOT_DIR, NER_TAGS, DEVICE
from models.bilstm_sequence_tagger import BiLSTMTagger
from utils.io_helpers import set_seed
from utils.evaluation_metrics import ner_entity_report
from utils.plot_helpers import plot_curve


class ConllDataset(Dataset):
    def __init__(self, path, word2idx, label2idx):
        self.samples = []
        with open(path, 'r', encoding='utf-8') as f:
            tokens, labels = [], []
            for line in f:
                line = line.strip()
                if not line:
                    if tokens:
                        self.samples.append((tokens, labels))
                    tokens, labels = [], []
                    continue
                tok, lab = line.split('\t')
                tokens.append(word2idx.get(tok, word2idx['<UNK>']))
                labels.append(label2idx[lab])
        if tokens:
            self.samples.append((tokens, labels))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]


def collate(batch):
    lengths = torch.tensor([len(x[0]) for x in batch], dtype=torch.long)
    max_len = max(lengths).item()
    inputs = torch.zeros(len(batch), max_len, dtype=torch.long)
    labels = torch.full((len(batch), max_len), 0, dtype=torch.long)
    for i, (tokens, labs) in enumerate(batch):
        inputs[i, :len(tokens)] = torch.tensor(tokens)
        labels[i, :len(labs)] = torch.tensor(labs)
    return inputs, labels, lengths


def evaluate(model, loader, device, idx2label):
    model.eval()
    gold_sequences, pred_sequences = [], []
    with torch.no_grad():
        for inputs, labels, lengths in loader:
            inputs, labels, lengths = inputs.to(device), labels.to(device), lengths.to(device)
            preds = model.decode(inputs, lengths)
            for i, seq in enumerate(preds):
                gold_sequences.append([idx2label[x] for x in labels[i, :len(seq)].tolist()])
                pred_sequences.append([idx2label[x] for x in seq])
    return ner_entity_report(gold_sequences, pred_sequences)


def train_mode(use_crf=True):
    set_seed()
    device = 'cuda' if torch.cuda.is_available() and DEVICE == 'cuda' else 'cpu'
    with open(EMB_DIR / 'word2idx.json', 'r', encoding='utf-8') as f:
        word2idx = json.load(f)
    embeddings = np.load(EMB_DIR / 'embeddings_w2v.npy')
    label2idx = {t: i for i, t in enumerate(NER_TAGS)}
    idx2label = {i: t for t, i in label2idx.items()}

    train_ds = ConllDataset(DATA_DIR / 'ner_train.conll', word2idx, label2idx)
    val_ds = ConllDataset(DATA_DIR / 'ner_val.conll', word2idx, label2idx)
    test_ds = ConllDataset(DATA_DIR / 'ner_test.conll', word2idx, label2idx)
    train_loader = DataLoader(train_ds, batch_size=32, shuffle=True, collate_fn=collate)
    val_loader = DataLoader(val_ds, batch_size=32, shuffle=False, collate_fn=collate)
    test_loader = DataLoader(test_ds, batch_size=32, shuffle=False, collate_fn=collate)

    model = BiLSTMTagger(len(word2idx), embeddings.shape[1], 128, len(NER_TAGS), embeddings=embeddings,
                         freeze_embeddings=False, use_crf=use_crf).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)

    best_f1, patience, wait = -1, 5, 0
    train_losses, val_losses = [], []
    name = 'crf' if use_crf else 'softmax'
    for epoch in range(20):
        model.train()
        total = 0.0
        for inputs, labels, lengths in train_loader:
            inputs, labels, lengths = inputs.to(device), labels.to(device), lengths.to(device)
            opt.zero_grad()
            loss = model(inputs, lengths, labels)
            loss.backward()
            opt.step()
            total += loss.item()
        train_losses.append(total / max(len(train_loader), 1))

        model.eval()
        vloss = 0.0
        with torch.no_grad():
            for inputs, labels, lengths in val_loader:
                inputs, labels, lengths = inputs.to(device), labels.to(device), lengths.to(device)
                vloss += model(inputs, lengths, labels).item()
        val_losses.append(vloss / max(len(val_loader), 1))
        val_report = evaluate(model, val_loader, device, idx2label)
        val_f1 = val_report['overall']['f1']
        if val_f1 > best_f1:
            best_f1 = val_f1
            wait = 0
            torch.save(model.state_dict(), MODEL_DIR / f'bilstm_ner_{name}.pt')
        else:
            wait += 1
            if wait >= patience:
                break

    plot_curve(train_losses, f'NER Loss ({name})', 'Loss', PLOT_DIR / f'ner_loss_{name}.png', val_losses)
    model.load_state_dict(torch.load(MODEL_DIR / f'bilstm_ner_{name}.pt', map_location=device))
    return evaluate(model, test_loader, device, idx2label)


def main():
    crf_report = train_mode(True)
    softmax_report = train_mode(False)
    with open(OUTPUT_DIR / 'ner_results.json', 'w', encoding='utf-8') as f:
        json.dump({'with_crf': crf_report, 'without_crf': softmax_report}, f, indent=2)
    print('Saved NER models, curves, and reports.')


if __name__ == '__main__':
    main()
