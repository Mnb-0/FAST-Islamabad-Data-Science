"""
visualize_benchmark.py
======================
Publication-quality figures for the Transformer Inference Benchmarking study.
Covers all 5 research objectives:
  1. FP32 baseline across P100, T4, CPU
  2. FP32 vs INT8 quantization comparison
  3. Latency / Throughput / Memory / Accuracy
  4. Batch size scaling + CPU threading + GPU multi-card (T4x1 vs T4x2)
  5. Cross-hardware summary tables

Usage:
    python visualize_benchmark.py
    python visualize_benchmark.py --csv path/to/your.csv

Outputs:  figures/fig_*.pdf  +  figures/fig_*.png  (300 dpi, paper-ready)
"""

import argparse
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch, Patch
from matplotlib.lines  import Line2D

warnings.filterwarnings("ignore")

# ── Output directory ──────────────────────────────────────────────────────────
os.makedirs("figures", exist_ok=True)

# =============================================================================
# STYLE  —  IEEE / ACM conference aesthetic
# =============================================================================
FONT_FAMILY = "DejaVu Sans"   # universally available; swap for "Times New Roman" if installed

mpl.rcParams.update({
    "font.family"        : "serif",
    "font.serif"         : [FONT_FAMILY],
    "axes.titlesize"     : 11,
    "axes.labelsize"     : 10,
    "xtick.labelsize"    : 9,
    "ytick.labelsize"    : 9,
    "legend.fontsize"    : 8.5,
    "figure.dpi"         : 150,
    "savefig.dpi"        : 300,
    "savefig.bbox"       : "tight",
    "savefig.pad_inches" : 0.05,
    "axes.spines.top"    : False,
    "axes.spines.right"  : False,
    "axes.grid"          : True,
    "grid.alpha"         : 0.25,
    "grid.linewidth"     : 0.6,
    "lines.linewidth"    : 1.8,
    "lines.markersize"   : 6,
    "patch.linewidth"    : 0.8,
})

# ── Colour palette ────────────────────────────────────────────────────────────
C = {
    "fp32"   : "#2166AC",   # blue
    "int8"   : "#D6604D",   # red-orange
    "bert"   : "#1A1A2E",   # near-black
    "distil" : "#4A90D9",   # sky blue
    "p100"   : "#6A0572",   # purple
    "t4x1"   : "#008B45",   # green
    "t4x2"   : "#FFA500",   # amber
    "cpu1"   : "#BBBBBB",   # light grey
    "cpu6"   : "#777777",   # mid grey
    "cpu12"  : "#333333",   # dark grey
}

HW_COLOR = {
    "P100"        : C["p100"],
    "T4x1"        : C["t4x1"],
    "T4x2"        : C["t4x2"],
    "CPU-1T"      : C["cpu1"],
    "CPU-6T"      : C["cpu6"],
    "CPU-12T"     : C["cpu12"],
}

HW_MARKER = {
    "P100"   : "D",
    "T4x1"   : "o",
    "T4x2"   : "s",
    "CPU-1T" : "^",
    "CPU-6T" : "v",
    "CPU-12T": "P",
}

BATCH_SIZES = [1, 8, 16, 32, 64]

MODEL_SHORT = {
    "textattack/bert-base-uncased-SST-2"              : "BERT-base",
    "distilbert-base-uncased-finetuned-sst-2-english" : "DistilBERT",
}

# =============================================================================
# DATA LOADING & CLEANING
# =============================================================================

def load_data(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)

    # Normalise column types
    df["Latency_ms"]           = pd.to_numeric(df["Latency_ms"],           errors="coerce")
    df["Throughput_seq_per_s"] = pd.to_numeric(df["Throughput_seq_per_s"], errors="coerce")
    df["Peak_Memory_MB"]       = pd.to_numeric(df["Peak_Memory_MB"],       errors="coerce")
    df["Accuracy_%"]           = pd.to_numeric(df["Accuracy_%"],           errors="coerce")
    df["CPU_Threads"]          = pd.to_numeric(df["CPU_Threads"],          errors="coerce")

    # Build a clean Environment label used throughout all plots
    def hw_label(row):
        if row["Hardware_Type"] == "GPU":
            env = str(row.get("Environment", "")).strip()
            if "P100" in env or "P100" in str(row["Hardware"]):
                return "P100"
            if "T4x2" in env or "x2" in str(row["Hardware"]):
                return "T4x2"
            return "T4x1"
        else:
            t = int(row["CPU_Threads"]) if not np.isnan(row["CPU_Threads"]) else 1
            return f"CPU-{t}T"

    df["HW_Label"] = df.apply(hw_label, axis=1)
    df["Model_Short"] = df["Model"].map(MODEL_SHORT).fillna(df["Model"])

    # Remove rows with implausible negative memory (RAM delta artefacts)
    df.loc[df["Peak_Memory_MB"] < 0, "Peak_Memory_MB"] = np.nan

    return df


def subset(df, hw=None, model=None, precision=None, batch=None):
    mask = pd.Series(True, index=df.index)
    if hw        is not None: mask &= df["HW_Label"]    == hw
    if model     is not None: mask &= df["Model_Short"] == model
    if precision is not None: mask &= df["Precision"]   == precision
    if batch     is not None: mask &= df["Batch_Size"]  == batch
    return df[mask].copy()


def save(fig, name):
    fig.savefig(f"figures/{name}.pdf")
    fig.savefig(f"figures/{name}.png")
    plt.close(fig)
    print(f"  ✓  figures/{name}.pdf / .png")


# =============================================================================
# FIGURE 1 — Latency vs Batch Size  (2×2 grid: model × hw-type)
# Objective 1, 3, 4
# =============================================================================

def fig_latency_vs_batch(df):
    fig, axes = plt.subplots(2, 2, figsize=(8.5, 6.5), sharey="row")
    fig.suptitle("Fig. 1 — Inference Latency vs. Batch Size", fontweight="bold", fontsize=12, y=1.01)

    gpu_hws = ["P100", "T4x1", "T4x2"]
    cpu_hws = ["CPU-1T", "CPU-6T", "CPU-12T"]
    models  = ["BERT-base", "DistilBERT"]
    col_groups = [gpu_hws, cpu_hws]
    col_titles = ["GPU Hardware", "CPU (Ryzen 5 5600)"]

    for r, model in enumerate(models):
        for c, (hws, col_title) in enumerate(zip(col_groups, col_titles)):
            ax = axes[r][c]
            for hw in hws:
                for prec, ls in [("FP32", "-"), ("INT8", "--")]:
                    d = subset(df, hw=hw, model=model, precision=prec).sort_values("Batch_Size")
                    if d.empty: continue
                    col = HW_COLOR[hw]
                    alpha = 1.0 if prec == "FP32" else 0.65
                    ax.plot(d["Batch_Size"], d["Latency_ms"],
                            color=col, ls=ls, marker=HW_MARKER[hw],
                            alpha=alpha, label=f"{hw} {prec}")

            ax.set_xticks(BATCH_SIZES)
            ax.set_xscale("log", base=2)
            ax.xaxis.set_major_formatter(mticker.ScalarFormatter())
            ax.set_xlabel("Batch Size")
            if c == 0:
                ax.set_ylabel(f"{model}\nLatency (ms)")
            if r == 0:
                ax.set_title(col_title, fontsize=10)

    # Single shared legend below
    handles = []
    for hw in gpu_hws + cpu_hws:
        handles.append(Line2D([0],[0], color=HW_COLOR[hw], marker=HW_MARKER[hw],
                               label=hw, linewidth=1.5))
    handles += [Line2D([0],[0], color="k", ls="-",  label="FP32"),
                Line2D([0],[0], color="k", ls="--", label="INT8")]
    fig.legend(handles=handles, loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.06),
               frameon=True, edgecolor="#cccccc")
    fig.tight_layout()
    save(fig, "fig1_latency_vs_batch")


# =============================================================================
# FIGURE 2 — Throughput vs Batch Size
# Objective 3, 4
# =============================================================================

def fig_throughput_vs_batch(df):
    fig, axes = plt.subplots(2, 2, figsize=(8.5, 6.5), sharey="row")
    fig.suptitle("Fig. 2 — Throughput vs. Batch Size", fontweight="bold", fontsize=12, y=1.01)

    gpu_hws = ["P100", "T4x1", "T4x2"]
    cpu_hws = ["CPU-1T", "CPU-6T", "CPU-12T"]
    models  = ["BERT-base", "DistilBERT"]

    for r, model in enumerate(models):
        for c, (hws, col_title) in enumerate(zip([gpu_hws, cpu_hws],
                                                  ["GPU Hardware", "CPU (Ryzen 5 5600)"])):
            ax = axes[r][c]
            for hw in hws:
                for prec, ls in [("FP32", "-"), ("INT8", "--")]:
                    d = subset(df, hw=hw, model=model, precision=prec).sort_values("Batch_Size")
                    if d.empty: continue
                    ax.plot(d["Batch_Size"], d["Throughput_seq_per_s"],
                            color=HW_COLOR[hw], ls=ls, marker=HW_MARKER[hw],
                            alpha=1.0 if prec=="FP32" else 0.65,
                            label=f"{hw} {prec}")
            ax.set_xticks(BATCH_SIZES)
            ax.set_xscale("log", base=2)
            ax.xaxis.set_major_formatter(mticker.ScalarFormatter())
            ax.set_xlabel("Batch Size")
            if c == 0:
                ax.set_ylabel(f"{model}\nThroughput (seq/s)")
            if r == 0:
                ax.set_title(col_title, fontsize=10)

    handles  = [Line2D([0],[0], color=HW_COLOR[h], marker=HW_MARKER[h], label=h, lw=1.5)
                for h in gpu_hws + cpu_hws]
    handles += [Line2D([0],[0], color="k", ls="-",  label="FP32"),
                Line2D([0],[0], color="k", ls="--", label="INT8")]
    fig.legend(handles=handles, loc="lower center", ncol=5, bbox_to_anchor=(0.5, -0.06),
               frameon=True, edgecolor="#cccccc")
    fig.tight_layout()
    save(fig, "fig2_throughput_vs_batch")


# =============================================================================
# FIGURE 3 — FP32 vs INT8: Speedup & Memory Reduction  (batch=32)
# Objective 2, 3
# =============================================================================

def fig_quantization_impact(df):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.5))
    fig.suptitle("Fig. 3 — Quantization Impact: INT8 vs FP32 (Batch Size = 32)",
                 fontweight="bold", fontsize=12)

    envs   = ["P100", "T4x1", "T4x2", "CPU-1T", "CPU-6T", "CPU-12T"]
    models = ["BERT-base", "DistilBERT"]
    x      = np.arange(len(envs))
    width  = 0.35

    for ax_idx, model in enumerate(models):
        ax = axes[ax_idx]
        speedups = []
        mem_saves = []
        for hw in envs:
            fp  = subset(df, hw=hw, model=model, precision="FP32",  batch=32)
            q   = subset(df, hw=hw, model=model, precision="INT8",  batch=32)
            if fp.empty or q.empty:
                speedups.append(np.nan)
                mem_saves.append(np.nan)
                continue
            lat_fp  = fp["Latency_ms"].values[0]
            lat_q   = q["Latency_ms"].values[0]
            mem_fp  = fp["Peak_Memory_MB"].values[0]
            mem_q   = q["Peak_Memory_MB"].values[0]
            speedups.append(lat_fp / lat_q if lat_q > 0 else np.nan)
            mem_saves.append((1 - mem_q / mem_fp) * 100 if mem_fp > 0 else np.nan)

        bars1 = ax.bar(x - width/2, speedups,  width, color=C["fp32"], label="Latency Speedup (×)",
                       zorder=3, edgecolor="white")
        ax2   = ax.twinx()
        bars2 = ax2.bar(x + width/2, mem_saves, width, color=C["int8"], label="Memory Saved (%)",
                        zorder=3, edgecolor="white", alpha=0.85)

        ax.axhline(1.0, color="grey", lw=0.9, ls="--", zorder=2)
        ax.set_xticks(x)
        ax.set_xticklabels(envs, rotation=30, ha="right")
        ax.set_ylabel("Latency Speedup (×)")
        ax2.set_ylabel("Memory Reduction (%)")
        ax.set_title(model, fontsize=10)
        ax.spines["right"].set_visible(False)
        ax2.spines["top"].set_visible(False)
        ax2.grid(False)

        # Bar labels
        for bar in bars1:
            v = bar.get_height()
            if not np.isnan(v):
                ax.text(bar.get_x() + bar.get_width()/2, v + 0.02,
                        f"{v:.2f}×", ha="center", va="bottom", fontsize=7.5)
        for bar in bars2:
            v = bar.get_height()
            if not np.isnan(v):
                ax2.text(bar.get_x() + bar.get_width()/2, v + 0.5,
                         f"{v:.1f}%", ha="center", va="bottom", fontsize=7.5)

        handles = [Patch(color=C["fp32"], label="Latency Speedup (×)"),
                   Patch(color=C["int8"], label="Memory Saved (%)")]
        ax.legend(handles=handles, fontsize=8, loc="upper right")

    fig.tight_layout()
    save(fig, "fig3_quantization_impact")


# =============================================================================
# FIGURE 4 — CPU Threading Scaling (Objective 4)
# =============================================================================

def fig_cpu_threading(df):
    cpu_df = df[df["Hardware_Type"] == "CPU"].copy()
    if cpu_df.empty:
        print("  ⚠  No CPU data — skipping fig4")
        return

    threads = [1, 6, 12]
    models  = ["BERT-base", "DistilBERT"]
    precs   = ["FP32", "INT8"]

    fig, axes = plt.subplots(2, 2, figsize=(9, 6.5), sharey="row")
    fig.suptitle("Fig. 4 — CPU Multi-threading Scaling (Batch Size = 32)",
                 fontweight="bold", fontsize=12, y=1.01)

    for r, metric, ylabel in [(0, "Throughput_seq_per_s", "Throughput (seq/s)"),
                               (1, "Latency_ms",           "Latency (ms)")]:
        for c, model in enumerate(models):
            ax = axes[r][c]
            for prec, ls in [("FP32", "-"), ("INT8", "--")]:
                vals = []
                for t in threads:
                    hw = f"CPU-{t}T"
                    d  = subset(cpu_df, hw=hw, model=model, precision=prec, batch=32)
                    vals.append(d[metric].values[0] if not d.empty else np.nan)
                color = C["fp32"] if prec == "FP32" else C["int8"]
                ax.plot(threads, vals, color=color, ls=ls, marker="o",
                        label=prec, linewidth=2)
                for t, v in zip(threads, vals):
                    if not np.isnan(v):
                        ax.annotate(f"{v:.1f}", (t, v),
                                    textcoords="offset points", xytext=(4, 4),
                                    fontsize=7.5, color=color)

            ax.set_xticks(threads)
            ax.set_xticklabels(["1 thread\n(single)", "6 threads\n(physical)", "12 threads\n(SMT)"])
            ax.set_xlabel("CPU Threads (intra-op)")
            if c == 0: ax.set_ylabel(ylabel)
            if r == 0: ax.set_title(model, fontsize=10)
            if r == 0 and c == 1:
                ax.legend(frameon=True, edgecolor="#ccc")

    fig.tight_layout()
    save(fig, "fig4_cpu_threading")


# =============================================================================
# FIGURE 5 — T4 Multi-GPU Scaling: T4x1 vs T4x2  (Objective 4)
# =============================================================================

def fig_multigpu_scaling(df):
    gpu_df = df[df["Hardware_Type"] == "GPU"].copy()
    t4_df  = gpu_df[gpu_df["HW_Label"].isin(["T4x1", "T4x2"])]
    if t4_df.empty:
        print("  ⚠  No T4 data — skipping fig5")
        return

    models  = ["BERT-base", "DistilBERT"]
    precs   = ["FP32", "INT8"]

    fig, axes = plt.subplots(2, 2, figsize=(9, 6.5))
    fig.suptitle("Fig. 5 — Multi-GPU Scaling: T4×1 vs T4×2",
                 fontweight="bold", fontsize=12, y=1.01)

    metrics = [("Throughput_seq_per_s", "Throughput (seq/s)"),
               ("Latency_ms",           "Latency (ms)")]

    for r, (metric, ylabel) in enumerate(metrics):
        for c, model in enumerate(models):
            ax = axes[r][c]
            for prec, ls in [("FP32", "-"), ("INT8", "--")]:
                for hw, col in [("T4x1", C["t4x1"]), ("T4x2", C["t4x2"])]:
                    d = subset(t4_df, hw=hw, model=model, precision=prec).sort_values("Batch_Size")
                    if d.empty: continue
                    lbl = f"{hw} {prec}"
                    ax.plot(d["Batch_Size"], d[metric],
                            color=col, ls=ls, marker=HW_MARKER[hw],
                            label=lbl, alpha=1.0 if prec=="FP32" else 0.7)

            ax.set_xticks(BATCH_SIZES)
            ax.set_xscale("log", base=2)
            ax.xaxis.set_major_formatter(mticker.ScalarFormatter())
            ax.set_xlabel("Batch Size")
            if c == 0: ax.set_ylabel(ylabel)
            if r == 0: ax.set_title(model, fontsize=10)

    handles  = [Line2D([0],[0], color=C["t4x1"], marker="o", label="T4×1", lw=1.5),
                Line2D([0],[0], color=C["t4x2"], marker="s", label="T4×2", lw=1.5),
                Line2D([0],[0], color="k", ls="-",  label="FP32"),
                Line2D([0],[0], color="k", ls="--", label="INT8")]
    fig.legend(handles=handles, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.04),
               frameon=True, edgecolor="#cccccc")
    fig.tight_layout()
    save(fig, "fig5_multigpu_scaling")


# =============================================================================
# FIGURE 6 — Peak Memory Heatmap across all configs  (Objective 3)
# =============================================================================

def fig_memory_heatmap(df):
    # Build pivot: rows = HW+Precision, cols = Model+Batch
    batch_b = 32   # pick one representative batch for a clean heatmap

    rows, data = [], []
    order = ["P100", "T4x1", "T4x2", "CPU-1T", "CPU-6T", "CPU-12T"]
    models = ["BERT-base", "DistilBERT"]

    for hw in order:
        for prec in ["FP32", "INT8"]:
            row_label = f"{hw} {prec}"
            row_vals  = []
            for model in models:
                for b in BATCH_SIZES:
                    d = subset(df, hw=hw, model=model, precision=prec, batch=b)
                    v = d["Peak_Memory_MB"].values[0] if not d.empty else np.nan
                    row_vals.append(v)
            rows.append(row_label)
            data.append(row_vals)

    col_labels = [f"{m}\nB={b}" for m in ["BERT", "DistilBERT"] for b in BATCH_SIZES]
    Z = np.array(data, dtype=float)

    fig, ax = plt.subplots(figsize=(12, 5))
    fig.suptitle("Fig. 6 — Peak Memory (MB) Across All Configurations",
                 fontweight="bold", fontsize=12)

    im = ax.imshow(Z, aspect="auto", cmap="YlOrRd", interpolation="nearest")
    ax.set_xticks(range(len(col_labels)))
    ax.set_xticklabels(col_labels, fontsize=8, rotation=45, ha="right")
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels(rows, fontsize=9)

    # Annotate cells
    for i in range(Z.shape[0]):
        for j in range(Z.shape[1]):
            v = Z[i, j]
            if not np.isnan(v):
                brightness = v / np.nanmax(Z)
                tc = "white" if brightness > 0.6 else "black"
                ax.text(j, i, f"{v:.0f}", ha="center", va="center",
                        fontsize=7, color=tc, fontweight="bold")

    # Separator line between GPU and CPU rows
    ax.axhline(5.5, color="white", lw=2.5)
    ax.text(-0.6, 2.5, "GPU", ha="center", va="center", fontsize=9,
            fontweight="bold", rotation=90, color=C["t4x1"])
    ax.text(-0.6, 8.5, "CPU", ha="center", va="center", fontsize=9,
            fontweight="bold", rotation=90, color=C["cpu12"])

    # Separator between models
    ax.axvline(4.5, color="white", lw=2)

    plt.colorbar(im, ax=ax, label="Peak Memory (MB)", shrink=0.85)
    fig.tight_layout()
    save(fig, "fig6_memory_heatmap")


# =============================================================================
# FIGURE 7 — Accuracy vs Precision Summary  (Objective 3)
# =============================================================================

def fig_accuracy(df):
    fig, ax = plt.subplots(figsize=(7, 4))
    fig.suptitle("Fig. 7 — Accuracy on GLUE SST-2 (FP32 vs INT8)",
                 fontweight="bold", fontsize=12)

    # Accuracy is hardware-independent; take first occurrence per model+precision
    acc = (df.groupby(["Model_Short", "Precision"])["Accuracy_%"]
             .first().reset_index())

    models = ["BERT-base", "DistilBERT"]
    x      = np.arange(len(models))
    width  = 0.3

    for i, prec in enumerate(["FP32", "INT8"]):
        vals = [acc[(acc["Model_Short"] == m) & (acc["Precision"] == prec)]["Accuracy_%"].values
                for m in models]
        vals = [v[0] if len(v) else np.nan for v in vals]
        col  = C["fp32"] if prec == "FP32" else C["int8"]
        bars = ax.bar(x + (i - 0.5) * width, vals, width, color=col,
                      label=prec, edgecolor="white", zorder=3)
        for bar, v in zip(bars, vals):
            if not np.isnan(v):
                ax.text(bar.get_x() + bar.get_width()/2, v - 1.2,
                        f"{v:.1f}%", ha="center", va="top",
                        fontsize=9, color="white", fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(models)
    ax.set_ylabel("Accuracy (%)")
    ax.set_ylim(88, 95)
    ax.yaxis.set_minor_locator(mticker.MultipleLocator(0.5))
    ax.legend()

    # Annotate accuracy drop
    for i, model in enumerate(models):
        fp_val = acc[(acc["Model_Short"] == model) & (acc["Precision"] == "FP32")]["Accuracy_%"].values
        q_val  = acc[(acc["Model_Short"] == model) & (acc["Precision"] == "INT8")]["Accuracy_%"].values
        if len(fp_val) and len(q_val):
            drop = fp_val[0] - q_val[0]
            ax.annotate(f"Δ = {drop:+.1f}pp", xy=(i, min(fp_val[0], q_val[0]) - 0.5),
                        ha="center", fontsize=8.5, color="grey",
                        xytext=(0, -18), textcoords="offset points",
                        arrowprops=dict(arrowstyle="-", color="grey", lw=0.7))

    fig.tight_layout()
    save(fig, "fig7_accuracy")


# =============================================================================
# FIGURE 8 — Cross-Hardware Summary Table  (Objective 5 — reproducibility)
# =============================================================================

def fig_summary_table(df):
    """Publication-ready summary table at batch=32."""
    rows = []
    for hw in ["P100", "T4x1", "T4x2", "CPU-1T", "CPU-6T", "CPU-12T"]:
        for model in ["BERT-base", "DistilBERT"]:
            for prec in ["FP32", "INT8"]:
                d = subset(df, hw=hw, model=model, precision=prec, batch=32)
                if d.empty: continue
                acc = df[(df["HW_Label"]==hw) & (df["Model_Short"]==model) &
                         (df["Precision"]==prec)]["Accuracy_%"].dropna()
                rows.append({
                    "Hardware"    : hw,
                    "Model"       : model,
                    "Precision"   : prec,
                    "Latency (ms)": f"{d['Latency_ms'].values[0]:.1f}",
                    "Throughput"  : f"{d['Throughput_seq_per_s'].values[0]:.1f}",
                    "Memory (MB)" : f"{d['Peak_Memory_MB'].values[0]:.0f}" if not np.isnan(d['Peak_Memory_MB'].values[0]) else "N/A",
                    "Accuracy (%)" : f"{acc.values[0]:.1f}" if len(acc) else "N/A",
                })

    tbl = pd.DataFrame(rows)
    n_rows = len(tbl)
    fig_h  = max(3.5, 0.32 * n_rows + 1.2)
    fig, ax = plt.subplots(figsize=(12, fig_h))
    fig.suptitle("Fig. 8 — Summary Table: Batch Size 32, All Configurations",
                 fontweight="bold", fontsize=11)
    ax.axis("off")

    col_labels = list(tbl.columns)
    cell_data  = tbl.values.tolist()

    table = ax.table(
        cellText   = cell_data,
        colLabels  = col_labels,
        loc        = "center",
        cellLoc    = "center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8.5)
    table.scale(1, 1.45)

    # Header styling
    for j in range(len(col_labels)):
        table[(0, j)].set_facecolor("#1A1A2E")
        table[(0, j)].set_text_props(color="white", fontweight="bold")

    # Row banding + precision colour
    for i, row in enumerate(cell_data, start=1):
        prec = row[2]
        for j in range(len(col_labels)):
            cell = table[(i, j)]
            if prec == "INT8":
                cell.set_facecolor("#FFF0EE")
            elif i % 2 == 0:
                cell.set_facecolor("#F7F9FC")

    # Bold the Hardware column
    for i in range(1, n_rows + 1):
        table[(i, 0)].set_text_props(fontweight="bold")

    fig.tight_layout()
    save(fig, "fig8_summary_table")

    # Also save as CSV for LaTeX import
    tbl.to_csv("figures/summary_table_batch32.csv", index=False)
    print("  ✓  figures/summary_table_batch32.csv")


# =============================================================================
# FIGURE 9 — GPU vs Best-CPU Throughput Comparison  (Objective 1 + 5)
# =============================================================================

def fig_gpu_vs_cpu(df):
    fig, axes = plt.subplots(1, 2, figsize=(9, 4.5), sharey=False)
    fig.suptitle("Fig. 9 — Best GPU vs. Best CPU Throughput (FP32, All Batch Sizes)",
                 fontweight="bold", fontsize=12)

    models = ["BERT-base", "DistilBERT"]

    for ax, model in zip(axes, models):
        configs = {
            "P100"    : ("P100",    C["p100"], "D"),
            "T4×1"    : ("T4x1",   C["t4x1"], "o"),
            "T4×2"    : ("T4x2",   C["t4x2"], "s"),
            "CPU-12T" : ("CPU-12T", C["cpu12"], "P"),
        }
        for label, (hw, col, mk) in configs.items():
            d = subset(df, hw=hw, model=model, precision="FP32").sort_values("Batch_Size")
            if d.empty: continue
            ax.plot(d["Batch_Size"], d["Throughput_seq_per_s"],
                    color=col, marker=mk, label=label, linewidth=2)

        ax.set_xticks(BATCH_SIZES)
        ax.set_xscale("log", base=2)
        ax.xaxis.set_major_formatter(mticker.ScalarFormatter())
        ax.set_xlabel("Batch Size")
        ax.set_ylabel("Throughput (seq/s)")
        ax.set_title(model, fontsize=10)
        ax.legend(frameon=True, edgecolor="#ccc")

    fig.tight_layout()
    save(fig, "fig9_gpu_vs_cpu")


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="Generate benchmark figures")
    parser.add_argument("--csv", default="/mnt/user-data/uploads/MASTER_aggregated_data.csv",
                        help="Path to the aggregated benchmark CSV")
    args = parser.parse_args()

    print(f"\nLoading data from: {args.csv}")
    df = load_data(args.csv)
    print(f"Loaded {len(df)} rows | Hardware configs: {sorted(df['HW_Label'].unique())}\n")
    print("Generating figures...\n")

    fig_latency_vs_batch(df)      # Fig 1
    fig_throughput_vs_batch(df)   # Fig 2
    fig_quantization_impact(df)   # Fig 3
    fig_cpu_threading(df)         # Fig 4
    fig_multigpu_scaling(df)      # Fig 5
    fig_memory_heatmap(df)        # Fig 6
    fig_accuracy(df)              # Fig 7
    fig_summary_table(df)         # Fig 8
    fig_gpu_vs_cpu(df)            # Fig 9

    print(f"\nDone. All outputs in ./figures/")
    print("PDF = vector (embed in LaTeX).  PNG = 300 dpi (embed in Word/Google Docs).")


if __name__ == "__main__":
    main()
