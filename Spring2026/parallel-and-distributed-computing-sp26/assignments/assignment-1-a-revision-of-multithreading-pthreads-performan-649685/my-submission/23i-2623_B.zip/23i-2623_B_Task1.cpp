/*
 * Name: Muneeb Lone
 * Student-ID: 2623
 * Assignment: #1
 */
#include <iostream>
#include <vector>
#include <chrono>
using namespace std;

#define N 120000
#define ALPHA 0.0016
#define INITIAL_W0 0.2
#define INITIAL_B0 0.3
#define EPOCHS 120
#define D1 2
#define D2 6

struct DataPoint
{
    double x;
    double y;
};

// Function to generate dataset 
void generateDataset(vector<DataPoint>& dataset)
{
    for (int i = 0; i < N; ++i)
    {
        dataset[i].x = i + 1;
        dataset[i].y = (2 + 0.01 * D1) * dataset[i].x + (1 + 0.05 * D2);
    }

    double x_min = 1.0;
    double x_max = static_cast<double>(N);

    for (int i = 0; i < N; ++i)
    {
        dataset[i].x = (dataset[i].x - x_min) / (x_max - x_min);
    }
}

// Function to compute gradients for a single epoch
void computeGradients(const vector<DataPoint>& dataset, double w, double b, double& grad_w, double& grad_b)
{
    grad_w = 0.0;
    grad_b = 0.0;

    for (int i = 0; i < N; ++i)
    {
        double prediction = w * dataset[i].x + b;
        double error = dataset[i].y - prediction;

        grad_w += -2.0 * dataset[i].x * error;
        grad_b += -2.0 * error;
    }

    grad_w /= N;
    grad_b /= N;
}

// Main training loop implementing Gradient Descent Update Rule
void trainModel(vector<DataPoint>& dataset, double& w, double& b)
{
    for (int e = 0; e < EPOCHS; ++e)
    {
        double grad_w, grad_b;
        computeGradients(dataset, w, b, grad_w, grad_b);

        w = w - ALPHA * grad_w;
        b = b - ALPHA * grad_b;

        if ((e + 1) % 10 == 0)
        {
            cout << "Epoch " << (e + 1) << ": w = " << w << ", b = " << b << endl;
        }
    }
}

int main()
{
    vector<DataPoint> dataset(N);
    double w = INITIAL_W0;
    double b = INITIAL_B0;

    generateDataset(dataset);

    cout << "Starting Sequential Gradient Descent..." << endl;

    auto start_time = chrono::high_resolution_clock::now();

    trainModel(dataset, w, b);

    auto end_time = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end_time - start_time;

    cout << "\n--- Performance Results ---" << endl;
    cout << "Final w: " << w << endl;
    cout << "Final b: " << b << endl;
    cout << "T_seq: " << elapsed.count() << " seconds" << endl;

    return 0;
}