/*
 * Name: Muneeb Lone
 * Student-ID: 2623
 * Assignment: #1
 */

#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <mutex>
#include <algorithm>
using namespace std;

#define N 120000
#define ALPHA 0.0016
#define INITIAL_W0 0.2
#define INITIAL_B0 0.3
#define EPOCHS 120
#define NUM_THREADS 12
#define D1 2
#define D2 6

struct DataPoint
{
    double x;
    double y;
};

mutex mtx;

void generateDataset(vector<DataPoint>& dataset)
{
    for (int i = 0; i < N; ++i)
    {
        dataset[i].x = i + 1;
        dataset[i].y = (2 + 0.01 * D1) * dataset[i].x + (1 + 0.05 * D2); 
    }
    double x_min = 1.0;
    double x_max = static_cast<double>(N);

    for (int i = 0; i < N; ++i)
    {
        dataset[i].x = (dataset[i].x - x_min) / (x_max - x_min);
    }
}

void computePartialGradients(const vector<DataPoint>& dataset, int start, int end,
    double w, double b, double& total_grad_w, double& total_grad_b)
{
    double local_grad_w = 0.0;
    double local_grad_b = 0.0;

    for (int i = start; i < end; ++i)
    {
        double prediction = w * dataset[i].x + b;
        double error = dataset[i].y - prediction;

        local_grad_w += -2.0 * dataset[i].x * error;
        local_grad_b += -2.0 * error; 
    }

    lock_guard<mutex> lock(mtx); 
    total_grad_w += local_grad_w;
    total_grad_b += local_grad_b;
}

void trainModelParallel(vector<DataPoint>& dataset, double& w, double& b)
{
    for (int e = 0; e < EPOCHS; ++e)
    {
        double grad_w = 0.0;
        double grad_b = 0.0;
        vector<thread> threads;
        int chunk_size = N / NUM_THREADS;

        for (int t = 0; t < NUM_THREADS; ++t)
        {
            int start = t * chunk_size;
            int end = (t == NUM_THREADS - 1) ? N : (t + 1) * chunk_size;

            // Manual thread creation as required 
            threads.emplace_back(computePartialGradients, cref(dataset), start, end,
                w, b, ref(grad_w), ref(grad_b));
        }

        for (auto& th : threads) th.join();

        grad_w /= N;
        grad_b /= N; 

        w = w - ALPHA * grad_w; 
        b = b - ALPHA * grad_b;

        if ((e + 1) % 10 == 0)
        {
            cout << "Epoch " << (e + 1) << ": w = " << w << ", b = " << b << endl;
        }
    }
}

int main()
{
    vector<DataPoint> dataset(N);
    double w = INITIAL_W0;
    double b = INITIAL_B0;

    generateDataset(dataset);

    cout << "Starting Parallel Gradient Descent (Threads: " << NUM_THREADS << ")..." << endl;

    auto start_time = chrono::high_resolution_clock::now();
    trainModelParallel(dataset, w, b);
    auto end_time = chrono::high_resolution_clock::now();

    chrono::duration<double> elapsed = end_time - start_time;

    cout << "\n--- Performance Results ---" << endl;
    cout << "T_par: " << elapsed.count() << " seconds" << endl;

    return 0;
}