// MUNEEB LONE | 23I-2623 | B
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

// Hyperparameters
#define WINDOW_SIZE 20
#define K_PAIRS 500
#define ALPHA 0.6f
#define BETA 0.4f
#define TOP_N 10

typedef struct
{
    int sensor_id;
    float *ts;
    int len;
} Sensor;

typedef struct
{
    int sensor_id;
    float *fv;
    int fv_len;
} FeatRec;

typedef struct
{
    int sensor_id;
    float score;
} AnomalyEntry;

// Monotonic clock for benchmarking
static double now_sec(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}

// Dumps the whole CSV into RAM
static int load_dataset(const char *path, Sensor **out_sensors, int *out_num_sensors, int *out_num_timesteps)
{
    FILE *fp = fopen(path, "r");
    if (!fp)
        return -1;

    char line[128];
    if (!fgets(line, sizeof(line), fp))
    {
        fclose(fp);
        return -1;
    }

    int max_s = -1, max_t = -1;
    long data_start = ftell(fp);
    while (fgets(line, sizeof(line), fp))
    {
        int s, t;
        float v;
        if (sscanf(line, "%d,%d,%f", &s, &t, &v) == 3)
        {
            if (s > max_s)
                max_s = s;
            if (t > max_t)
                max_t = t;
        }
    }
    int ns = max_s + 1, nt = max_t + 1;

    Sensor *sensors = (Sensor *)calloc(ns, sizeof(Sensor));
    for (int i = 0; i < ns; i++)
    {
        sensors[i].sensor_id = i;
        sensors[i].len = nt;
        sensors[i].ts = (float *)calloc(nt, sizeof(float));
    }

    fseek(fp, data_start, SEEK_SET);
    while (fgets(line, sizeof(line), fp))
    {
        int s, t;
        float v;
        if (sscanf(line, "%d,%d,%f", &s, &t, &v) == 3)
            sensors[s].ts[t] = v;
    }
    fclose(fp);

    *out_sensors = sensors;
    *out_num_sensors = ns;
    *out_num_timesteps = nt;
    return 0;
}

// Tumbling windows, Extracts Mean, Variance, Energy, Magnitude
static void extract_features(const Sensor *s, float **fv_out, int *fv_len_out)
{
    int n = WINDOW_SIZE;
    int nw = s->len / n;
    if (nw == 0)
        nw = 1;

    int fvl = 4 * nw;
    float *fv = (float *)malloc(fvl * sizeof(float));

    for (int w = 0; w < nw; w++)
    {
        int start = w * n;
        int end = start + n;
        if (end > s->len)
            end = s->len;
        int cnt = end - start;

        double sum = 0.0;
        for (int i = start; i < end; i++)
            sum += s->ts[i];
        double mean = sum / cnt;

        double var = 0.0;
        for (int i = start; i < end; i++)
        {
            double d = s->ts[i] - mean;
            var += d * d;
        }
        var /= cnt;

        double energy = 0.0;
        for (int i = start; i < end; i++)
            energy += (double)s->ts[i] * s->ts[i];

        fv[w * 4 + 0] = (float)mean;
        fv[w * 4 + 1] = (float)var;
        fv[w * 4 + 2] = (float)energy;
        fv[w * 4 + 3] = (float)sqrt(energy);
    }
    *fv_out = fv;
    *fv_len_out = fvl;
}

// Standard cosine similarity math
static float cosine_similarity(const float *a, const float *b, int len)
{
    double dot = 0, na = 0, nb = 0;
    for (int i = 0; i < len; i++)
    {
        dot += (double)a[i] * b[i];
        na += (double)a[i] * a[i];
        nb += (double)b[i] * b[i];
    }
    double denom = sqrt(na) * sqrt(nb);
    return (denom < 1e-12) ? 0.0f : (float)(dot / denom);
}

// Plugs the features into the arbitrary alpha/beta scoring formula
static void compute_anomaly_scores(FeatRec *recs, int ns, float *scores)
{
    int fvl = recs[0].fv_len;
    double *mu = (double *)calloc(fvl, sizeof(double));

    for (int i = 0; i < ns; i++)
        for (int j = 0; j < fvl; j++)
            mu[j] += recs[i].fv[j];

    for (int j = 0; j < fvl; j++)
        mu[j] /= ns;

    for (int i = 0; i < ns; i++)
    {
        double dev = 0.0;
        for (int j = 0; j < fvl; j++)
            dev += fabs(recs[i].fv[j] - mu[j]);
        dev /= fvl;

        // Arbitrary neighbor comparison (wrap-around at the end)
        int nb = (i + 1) % ns;
        float sim = cosine_similarity(recs[i].fv, recs[nb].fv, fvl);

        scores[i] = ALPHA * (float)dev + BETA * (1.0f - sim);
    }
    free(mu);
}

static int cmp_desc(const void *a, const void *b)
{
    float d = ((AnomalyEntry *)b)->score - ((AnomalyEntry *)a)->score;
    return (d > 0) - (d < 0);
}

int main(int argc, char *argv[])
{
    const char *csv = (argc > 1) ? argv[1] : "Dataset.csv";
    double t_wall = now_sec();

    Sensor *sensors;
    int ns, nt;
    if (load_dataset(csv, &sensors, &ns, &nt) < 0)
        return 1;

    FeatRec *recs = (FeatRec *)malloc(ns * sizeof(FeatRec));
    for (int i = 0; i < ns; i++)
    {
        recs[i].sensor_id = i;
        extract_features(&sensors[i], &recs[i].fv, &recs[i].fv_len);
    }

    srand(42);
    double avg_sim = 0.0;
    int fvl = recs[0].fv_len;
    for (int k = 0; k < K_PAIRS; k++)
    {
        int a = rand() % ns;
        int b = rand() % ns;
        if (a == b)
            b = (b + 1) % ns;
        avg_sim += cosine_similarity(recs[a].fv, recs[b].fv, fvl);
    }

    float *scores = (float *)malloc(ns * sizeof(float));
    compute_anomaly_scores(recs, ns, scores);

    AnomalyEntry *e = (AnomalyEntry *)malloc(ns * sizeof(AnomalyEntry));
    for (int i = 0; i < ns; i++)
    {
        e[i].sensor_id = i;
        e[i].score = scores[i];
    }

    qsort(e, ns, sizeof(AnomalyEntry), cmp_desc);
    int k = (ns < TOP_N) ? ns : TOP_N;

    printf("\n╔══════════════════════════════════════╗\n");
    printf("║     Top-%d Anomalous Sensors          ║\n", k);
    printf("╠══════════════════════════════════════╣\n");
    for (int i = 0; i < k; i++)
        printf("║  %-10d  %-20.6f║\n", e[i].sensor_id, e[i].score);
    printf("╚══════════════════════════════════════╝\n");

    printf("\n[Timing] Sequential total: %.4f s\n\n", now_sec() - t_wall);

    for (int i = 0; i < ns; i++)
    {
        free(sensors[i].ts);
        free(recs[i].fv);
    }
    free(sensors);
    free(recs);
    free(scores);
    free(e);
    return 0;
}