// MUNEEB LONE | 23I-2623 | B
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define WINDOW_SIZE 20
#define K_PAIRS 500
#define ALPHA 0.6f
#define BETA 0.4f
#define TOP_N 10

// Master reads the entire dataset into memory
static int load_dataset(const char *path, float **ts_flat, int *ns, int *nt)
{
    FILE *fp = fopen(path, "r");
    if (!fp)
        return -1;

    char line[128];
    if (!fgets(line, sizeof(line), fp))
    {
        fclose(fp);
        return -1;
    }

    int max_s = -1, max_t = -1;
    long data_start = ftell(fp);
    while (fgets(line, sizeof(line), fp))
    {
        int s, t;
        float v;
        if (sscanf(line, "%d,%d,%f", &s, &t, &v) == 3)
        {
            if (s > max_s)
                max_s = s;
            if (t > max_t)
                max_t = t;
        }
    }
    *ns = max_s + 1;
    *nt = max_t + 1;

    float *buf = (float *)calloc((long)(*ns) * (*nt), sizeof(float));
    fseek(fp, data_start, SEEK_SET);
    while (fgets(line, sizeof(line), fp))
    {
        int s, t;
        float v;
        if (sscanf(line, "%d,%d,%f", &s, &t, &v) == 3)
            buf[(long)s * (*nt) + t] = v;
    }
    fclose(fp);
    *ts_flat = buf;
    return 0;
}

static void extract_features(const float *ts, int ls, int nt, float **fv_out, int *fvl_out)
{
    int nw = (nt / WINDOW_SIZE > 0) ? nt / WINDOW_SIZE : 1;
    int fvl = 4 * nw;
    float *fv = (float *)malloc((long)ls * fvl * sizeof(float));

    for (int s = 0; s < ls; s++)
    {
        const float *row = ts + (long)s * nt;
        float *fvs = fv + (long)s * fvl;
        for (int w = 0; w < nw; w++)
        {
            int start = w * WINDOW_SIZE;
            int end = start + WINDOW_SIZE;
            if (end > nt)
                end = nt;
            int cnt = end - start;

            double sum = 0.0;
            for (int i = start; i < end; i++)
                sum += row[i];
            double mean = sum / cnt;

            double var = 0.0;
            for (int i = start; i < end; i++)
            {
                double d = row[i] - mean;
                var += d * d;
            }
            var /= cnt;

            double energy = 0.0;
            for (int i = start; i < end; i++)
                energy += (double)row[i] * row[i];

            fvs[w * 4 + 0] = (float)mean;
            fvs[w * 4 + 1] = (float)var;
            fvs[w * 4 + 2] = (float)energy;
            fvs[w * 4 + 3] = (float)sqrt(energy);
        }
    }
    *fv_out = fv;
    *fvl_out = fvl;
}

static float cosine_sim(const float *a, const float *b, int len)
{
    double dot = 0, na = 0, nb = 0;
    for (int i = 0; i < len; i++)
    {
        dot += (double)a[i] * b[i];
        na += (double)a[i] * a[i];
        nb += (double)b[i] * b[i];
    }
    double d = sqrt(na) * sqrt(nb);
    return (d < 1e-12) ? 0.0f : (float)(dot / d);
}

// Calculate scores using ONLY local partition data
static void compute_local_scores(const float *fv, int ls, int fvl, float *scores)
{
    double *mu = (double *)calloc(fvl, sizeof(double));
    for (int i = 0; i < ls; i++)
        for (int j = 0; j < fvl; j++)
            mu[j] += fv[(long)i * fvl + j];

    for (int j = 0; j < fvl; j++)
        mu[j] /= ls;

    for (int i = 0; i < ls; i++)
    {
        const float *fi = fv + (long)i * fvl;
        double dev = 0.0;
        for (int j = 0; j < fvl; j++)
            dev += fabs(fi[j] - mu[j]);
        dev /= fvl;

        int nb = (i + 1) % ls;
        float sim = cosine_sim(fi, fv + (long)nb * fvl, fvl);
        scores[i] = ALPHA * (float)dev + BETA * (1.0f - sim);
    }
    free(mu);
}

typedef struct
{
    int id;
    float score;
} Entry;

static int cmp_desc(const void *a, const void *b)
{
    float d = ((Entry *)b)->score - ((Entry *)a)->score;
    return (d > 0) - (d < 0);
}

int main(int argc, char *argv[])
{
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double t_start = MPI_Wtime();
    const char *path = (argc > 1) ? argv[1] : "Dataset.csv";

    float *all_ts = NULL;
    int ns = 0, nt = 0;

    if (rank == 0)
    {
        if (load_dataset(path, &all_ts, &ns, &nt) < 0)
            MPI_Abort(MPI_COMM_WORLD, 1);
    }

    int meta[2] = {ns, nt};
    MPI_Bcast(meta, 2, MPI_INT, 0, MPI_COMM_WORLD);
    ns = meta[0];
    nt = meta[1];

    // Calculate array offsets so we don't accidentally drop data or overlap boundaries
    int *sendcounts = (int *)malloc(size * sizeof(int));
    int *displs = (int *)malloc(size * sizeof(int));
    int base = ns / size, extra = ns % size, off = 0;

    for (int r = 0; r < size; r++)
    {
        sendcounts[r] = (base + (r < extra ? 1 : 0)) * nt;
        displs[r] = off;
        off += sendcounts[r];
    }

    int local_sensors = sendcounts[rank] / nt;
    float *local_ts = (float *)malloc((long)local_sensors * nt * sizeof(float));

    MPI_Scatterv(all_ts, sendcounts, displs, MPI_FLOAT, local_ts, sendcounts[rank], MPI_FLOAT, 0, MPI_COMM_WORLD);

    float *local_fv;
    int fvl;
    extract_features(local_ts, local_sensors, nt, &local_fv, &fvl);

    srand(42 + rank);
    int local_k = K_PAIRS / size;
    if (local_sensors >= 2)
    {
        for (int k = 0; k < local_k; k++)
        {
            int a = rand() % local_sensors;
            int b = rand() % local_sensors;
            if (a == b)
                b = (b + 1) % local_sensors;
            cosine_sim(local_fv + (long)a * fvl, local_fv + (long)b * fvl, fvl);
        }
    }

    float *local_scores = (float *)malloc(local_sensors * sizeof(float));
    compute_local_scores(local_fv, local_sensors, fvl, local_scores);

    // Master collects the isolated local scores to build the final ranking
    int *rcounts = NULL, *rdispls = NULL;
    float *all_scores = NULL;

    if (rank == 0)
    {
        rcounts = (int *)malloc(size * sizeof(int));
        rdispls = (int *)malloc(size * sizeof(int));
        all_scores = (float *)malloc(ns * sizeof(float));
    }

    MPI_Gather(&local_sensors, 1, MPI_INT, rcounts, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        rdispls[0] = 0;
        for (int r = 1; r < size; r++)
            rdispls[r] = rdispls[r - 1] + rcounts[r - 1];
    }

    MPI_Gatherv(local_scores, local_sensors, MPI_FLOAT, all_scores, rcounts, rdispls, MPI_FLOAT, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        Entry *entries = (Entry *)malloc(ns * sizeof(Entry));
        int idx = 0;
        for (int r = 0; r < size; r++)
        {
            int roff = displs[r] / nt;
            for (int s = 0; s < rcounts[r]; s++, idx++)
            {
                entries[idx].id = roff + s;
                entries[idx].score = all_scores[idx];
            }
        }

        qsort(entries, ns, sizeof(Entry), cmp_desc);
        int k = (ns < TOP_N) ? ns : TOP_N;
        printf("\n╔══════════════════════════════════════════════╗\n");
        for (int i = 0; i < k; i++)
            printf("║  %-10d  %-26.6f║\n", entries[i].id, entries[i].score);
        printf("╚══════════════════════════════════════════════╝\n");
        printf("\n[Timing] Basic Parallel total time [P=%d]: %.4f s\n", size, MPI_Wtime() - t_start);

        free(entries);
        free(rcounts);
        free(rdispls);
        free(all_scores);
        free(all_ts);
    }

    free(sendcounts);
    free(displs);
    free(local_ts);
    free(local_fv);
    free(local_scores);
    MPI_Finalize();
    return 0;
}