// MUNEEB LONE | 23I-2623 | B
#include <stdio.h>
#include <stdlib.h>

float generate_normal_value(void)
{
    return (rand() % 100) + (rand() % 100) / 100.0f;
}

float generate_anomaly_value(void)
{
    return 200 + (rand() % 100);
}

int main(void)
{
    int studentID = 2623;
    int sensors = 1000 + (studentID % 500);
    int timesteps = 500 + (studentID % 500);
    srand(studentID);

    printf("Student ID : %d  |  Sensors: %d  |  TimeSteps: %d\n",
           studentID, sensors, timesteps);

    FILE *fp = fopen("Dataset.csv", "w");
    if (!fp)
    {
        fprintf(stderr, "Cannot create Dataset.csv\n");
        return 1;
    }

    fprintf(fp, "sensor_id,timestep,value\n");
    for (int s = 0; s < sensors; s++)
    {
        for (int t = 0; t < timesteps; t++)
        {
            float value;
            if (rand() % 1000 < 5)
                value = generate_anomaly_value();
            else
                value = generate_normal_value();
            fprintf(fp, "%d,%d,%.2f\n", s, t, value);
        }
    }
    fclose(fp);
    printf("Saved: Dataset.csv  (%d sensors x %d timesteps)\n", sensors, timesteps);
    return 0;
}