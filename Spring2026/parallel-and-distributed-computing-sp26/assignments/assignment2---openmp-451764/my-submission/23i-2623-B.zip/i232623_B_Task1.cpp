/* Name: Muhammad Muneeb Lone
   Student ID: 2623
   Assignment: 2
*/
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <cmath>
#include <thread>
#include <mutex>
#include <algorithm>
#include <chrono>

using namespace std;

struct Review
{
    int id;
    string text;
    vector<string> tokens;
    vector<double> tf_idf_vector; // Dense vector for fast math
    int cluster_id = -1;
};

// Global Shared Data
vector<Review> dataset;
vector<string> vocab_list;
map<string, int> vocab_index;
map<string, int> global_word_counts;
map<string, int> doc_frequencies;
mutex global_mutex;

bool isStopWord(string word)
{
    static set<string> stopwords = {"the", "is", "at", "which", "on", "and", "a", "to"};
    return stopwords.count(word);
}

// Phase 1: Tokenization, Stopwords, Vocab, and Word Frequencies
void processNLP_Phase1(int start, int end)
{
    map<string, int> local_counts;
    map<string, int> local_df;

    for (int i = start; i < end; ++i)
    {
        stringstream ss(dataset[i].text);
        string word;
        set<string> unique_in_doc;

        while (ss >> word)
        {
            if (!isStopWord(word))
            {
                dataset[i].tokens.push_back(word);
                local_counts[word]++;
                unique_in_doc.insert(word);
            }
        }
        for (const auto &w : unique_in_doc)
        {
            local_df[w]++;
        }
    }

    // Orchestration: Merge local results safely
    lock_guard<mutex> lock(global_mutex);
    for (const auto &pair : local_counts)
        global_word_counts[pair.first] += pair.second;
    for (const auto &pair : local_df)
        doc_frequencies[pair.first] += pair.second;
}

// Phase 2: TF-IDF & Vectorization
void processNLP_Phase2(int start, int end, int N)
{
    int V = vocab_list.size();
    for (int i = start; i < end; ++i)
    {
        dataset[i].tf_idf_vector.assign(V, 0.0);
        map<string, int> term_counts;
        for (const string &w : dataset[i].tokens)
            term_counts[w]++;

        int total_terms = dataset[i].tokens.size();
        if (total_terms == 0)
            continue;

        for (const auto &tc : term_counts)
        {
            double tf = (double)tc.second / total_terms;
            double idf = log((double)N / (1 + doc_frequencies[tc.first]));
            dataset[i].tf_idf_vector[vocab_index[tc.first]] = tf * idf;
        }
    }
}

// K-Means Helper: Euclidean Distance
double getDistance(const vector<double> &a, const vector<double> &b)
{
    double sum = 0;
    for (size_t i = 0; i < a.size(); ++i)
    {
        sum += (a[i] - b[i]) * (a[i] - b[i]);
    }
    return sum; // Omitting sqrt for speed, relative distance is same
}

void assignClusters(int start, int end, const vector<vector<double>> &centroids)
{
    int K = centroids.size();
    for (int i = start; i < end; ++i)
    {
        double minDist = 1e9;
        int bestCluster = 0;
        for (int k = 0; k < K; ++k)
        {
            double dist = getDistance(dataset[i].tf_idf_vector, centroids[k]);
            if (dist < minDist)
            {
                minDist = dist;
                bestCluster = k;
            }
        }
        dataset[i].cluster_id = bestCluster;
    }
}

// Cosine Similarity
void computeCosineSim(int start, int end, const vector<pair<int, int>> &pairs, vector<double> &results)
{
    for (int i = start; i < end; ++i)
    {
        const auto &vecA = dataset[pairs[i].first].tf_idf_vector;
        const auto &vecB = dataset[pairs[i].second].tf_idf_vector;
        double dotProduct = 0, normA = 0, normB = 0;
        for (size_t j = 0; j < vecA.size(); ++j)
        {
            dotProduct += vecA[j] * vecB[j];
            normA += vecA[j] * vecA[j];
            normB += vecB[j] * vecB[j];
        }
        results[i] = (normA == 0 || normB == 0) ? 0 : dotProduct / (sqrt(normA) * sqrt(normB));
    }
}

template <typename Function>
void executeParallel(int num_threads, Function function)
{
    vector<thread> threads;
    int chunkSize = dataset.size() / num_threads;
    for (int i = 0; i < num_threads; ++i)
    {
        int s = i * chunkSize;
        int e = (i == num_threads - 1) ? dataset.size() : (i + 1) * chunkSize;
        threads.emplace_back(function, s, e);
    }
    for (auto &th : threads)
        th.join();
}

int main()
{
    ifstream file("dataset.csv");
    if (!file.is_open())
        return 1;
    string line;
    getline(file, line);
    while (getline(file, line))
    {
        stringstream ss(line);
        string id_str, text;
        if (getline(ss, id_str, ',') && getline(ss, text))
        {
            dataset.push_back({stoi(id_str), text, {}, {}, -1});
        }
    }
    file.close();

    int num_threads = thread::hardware_concurrency();
    if (num_threads == 0)
        num_threads = 4;
    auto start_time = chrono::high_resolution_clock::now();

    // Pipeline Execution
    executeParallel(num_threads, processNLP_Phase1);

    // Build indexing
    for (const auto &pair : global_word_counts)
    {
        vocab_index[pair.first] = vocab_list.size();
        vocab_list.push_back(pair.first);
    }

    auto tf_idf_lambda = [N = dataset.size()](int s, int e)
    { processNLP_Phase2(s, e, N); };
    executeParallel(num_threads, tf_idf_lambda);

    // Top 10 Words
    vector<pair<int, string>> sorted_words;
    for (const auto &p : global_word_counts)
        sorted_words.push_back({p.second, p.first});
    sort(sorted_words.rbegin(), sorted_words.rend());

    // K-Means Clustering
    int K = 5;
    vector<vector<double>> centroids(K, vector<double>(vocab_list.size(), 0.0));
    for (int k = 0; k < K; ++k)
        centroids[k] = dataset[k].tf_idf_vector; // Naive init

    for (int iter = 0; iter < 10; ++iter)
    { // 10 iterations
        auto kmeans_lambda = [&centroids](int s, int e)
        { assignClusters(s, e, centroids); };
        executeParallel(num_threads, kmeans_lambda);

        // Centroid Recomputation (Sequential due to size, K=5 is too small to thread efficiently)
        vector<vector<double>> new_centroids(K, vector<double>(vocab_list.size(), 0.0));
        vector<int> counts(K, 0);
        for (const auto &doc : dataset)
        {
            int c = doc.cluster_id;
            counts[c]++;
            for (size_t v = 0; v < vocab_list.size(); ++v)
                new_centroids[c][v] += doc.tf_idf_vector[v];
        }
        for (int k = 0; k < K; ++k)
        {
            if (counts[k] > 0)
            {
                for (size_t v = 0; v < vocab_list.size(); ++v)
                    centroids[k][v] = new_centroids[k][v] / counts[k];
            }
        }
    }

    // Similarity
    vector<pair<int, int>> random_pairs(100);
    for (int i = 0; i < 100; ++i)
        random_pairs[i] = {rand() % dataset.size(), rand() % dataset.size()};
    vector<double> sim_scores(100);

    vector<thread> sim_threads;
    int simChunk = 100 / num_threads;
    for (int i = 0; i < num_threads; ++i)
    {
        int s = i * simChunk;
        int e = (i == num_threads - 1) ? 100 : (i + 1) * simChunk;
        sim_threads.emplace_back(computeCosineSim, s, e, ref(random_pairs), ref(sim_scores));
    }
    for (auto &th : sim_threads)
        th.join();

    auto end_time = chrono::high_resolution_clock::now();

    // Outputs
    cout << "Threaded Execution Time: " << chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count() << "ms\n";
    cout << "Top 10 words:\n";
    for (int i = 0; i < min(10, (int)sorted_words.size()); i++)
        cout << sorted_words[i].second << ": " << sorted_words[i].first << "\n";

    vector<int> final_counts(K, 0);
    for (const auto &doc : dataset)
        final_counts[doc.cluster_id]++;
    for (int k = 0; k < K; k++)
        cout << "Cluster " << k + 1 << " " << final_counts[k] << " documents\n";

    return 0;
}