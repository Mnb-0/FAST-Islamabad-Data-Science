/* Name: Muhammad Muneeb Lone
   Student ID: 2623
   Assignment: 2
*/
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <cmath>
#include <omp.h>
#include <algorithm>
#include <chrono>

using namespace std;

struct Review
{
    int id;
    string text;
    vector<string> tokens;
    vector<double> tf_idf_vector;
    int cluster_id = -1;
};

vector<Review> dataset;
vector<string> vocab_list;
map<string, int> vocab_index;
map<string, int> global_word_counts;
map<string, int> doc_frequencies;

bool isStopWord(string word)
{
    static set<string> stopwords = {"the", "is", "at", "which", "on", "and", "a", "to"};
    return stopwords.count(word);
}

int main()
{
    ifstream file("dataset.csv");
    string line;
    getline(file, line);
    while (getline(file, line))
    {
        stringstream ss(line);
        string id_str, text;
        if (getline(ss, id_str, ',') && getline(ss, text))
        {
            dataset.push_back({stoi(id_str), text, {}, {}, -1});
        }
    }

    auto start_time = chrono::high_resolution_clock::now();

// Phase 1: Pipeline
#pragma omp parallel
    {
        map<string, int> local_counts;
        map<string, int> local_df;

#pragma omp for nowait
        for (int i = 0; i < dataset.size(); ++i)
        {
            stringstream ss(dataset[i].text);
            string word;
            set<string> unique_in_doc;
            while (ss >> word)
            {
                if (!isStopWord(word))
                {
                    dataset[i].tokens.push_back(word);
                    local_counts[word]++;
                    unique_in_doc.insert(word);
                }
            }
            for (const auto &w : unique_in_doc)
                local_df[w]++;
        }

#pragma omp critical
        {
            for (const auto &p : local_counts)
                global_word_counts[p.first] += p.second;
            for (const auto &p : local_df)
                doc_frequencies[p.first] += p.second;
        }
    }

    for (const auto &pair : global_word_counts)
    {
        vocab_index[pair.first] = vocab_list.size();
        vocab_list.push_back(pair.first);
    }
    int V = vocab_list.size();
    int N = dataset.size();

// Phase 2: TF-IDF
#pragma omp parallel for
    for (int i = 0; i < N; ++i)
    {
        dataset[i].tf_idf_vector.assign(V, 0.0);
        map<string, int> term_counts;
        for (const string &w : dataset[i].tokens)
            term_counts[w]++;
        int total_terms = dataset[i].tokens.size();
        if (total_terms > 0)
        {
            for (const auto &tc : term_counts)
            {
                double tf = (double)tc.second / total_terms;
                double idf = log((double)N / (1 + doc_frequencies[tc.first]));
                dataset[i].tf_idf_vector[vocab_index[tc.first]] = tf * idf;
            }
        }
    }

    // Phase 3: K-Means
    int K = 5;
    vector<vector<double>> centroids(K, vector<double>(V, 0.0));
    for (int k = 0; k < K; ++k)
        centroids[k] = dataset[k].tf_idf_vector;

    for (int iter = 0; iter < 10; ++iter)
    {
// Assignment
#pragma omp parallel for
        for (int i = 0; i < N; ++i)
        {
            double minDist = 1e9;
            int bestCluster = 0;
            for (int k = 0; k < K; ++k)
            {
                double dist = 0;
                for (size_t v = 0; v < V; ++v)
                {
                    double diff = dataset[i].tf_idf_vector[v] - centroids[k][v];
                    dist += diff * diff;
                }
                if (dist < minDist)
                {
                    minDist = dist;
                    bestCluster = k;
                }
            }
            dataset[i].cluster_id = bestCluster;
        }

        // Recomputation
        vector<vector<double>> new_centroids(K, vector<double>(V, 0.0));
        vector<int> counts(K, 0);

#pragma omp parallel
        {
            vector<vector<double>> loc_centroids(K, vector<double>(V, 0.0));
            vector<int> loc_counts(K, 0);

#pragma omp for nowait
            for (int i = 0; i < N; ++i)
            {
                int c = dataset[i].cluster_id;
                loc_counts[c]++;
                for (size_t v = 0; v < V; ++v)
                    loc_centroids[c][v] += dataset[i].tf_idf_vector[v];
            }

#pragma omp critical
            {
                for (int k = 0; k < K; ++k)
                {
                    counts[k] += loc_counts[k];
                    for (size_t v = 0; v < V; ++v)
                        new_centroids[k][v] += loc_centroids[k][v];
                }
            }
        }
        for (int k = 0; k < K; ++k)
        {
            if (counts[k] > 0)
            {
                for (size_t v = 0; v < V; ++v)
                    centroids[k][v] = new_centroids[k][v] / counts[k];
            }
        }
    }

    // Phase 4: Similarity
    vector<pair<int, int>> random_pairs(100);
    for (int i = 0; i < 100; ++i)
        random_pairs[i] = {rand() % N, rand() % N};
    vector<double> sim_scores(100);

#pragma omp parallel for
    for (int i = 0; i < 100; ++i)
    {
        const auto &vecA = dataset[random_pairs[i].first].tf_idf_vector;
        const auto &vecB = dataset[random_pairs[i].second].tf_idf_vector;
        double dotProduct = 0, normA = 0, normB = 0;
        for (size_t j = 0; j < V; ++j)
        {
            dotProduct += vecA[j] * vecB[j];
            normA += vecA[j] * vecA[j];
            normB += vecB[j] * vecB[j];
        }
        sim_scores[i] = (normA == 0 || normB == 0) ? 0 : dotProduct / (sqrt(normA) * sqrt(normB));
    }

    // Top 10 Words sorting and printing
    vector<pair<int, string>> sorted_words;
    for (const auto &p : global_word_counts)
        sorted_words.push_back({p.second, p.first});
    sort(sorted_words.rbegin(), sorted_words.rend());

    cout << "Top 10 words:\n";
    for (int i = 0; i < min(10, (int)sorted_words.size()); i++)
    {
        cout << sorted_words[i].second << ": " << sorted_words[i].first << "\n";
    }

    auto end_time = chrono::high_resolution_clock::now();

    cout << "OpenMP Execution Time: " << chrono::duration_cast<chrono::milliseconds>(end_time - start_time).count() << "ms\n";
    vector<int> final_counts(K, 0);
    for (const auto &doc : dataset)
        final_counts[doc.cluster_id]++;
    for (int k = 0; k < K; k++)
        cout << "Cluster " << k + 1 << " " << final_counts[k] << " documents\n";
    return 0;
}